<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_nakes extends CI_Model {
	//var $table = 'pasien';
    var $coloumn_order = array('noAtr','noRm','nik','nama','alamat');
    var $order = array('noAtr','noRm','nik','nama','alamat');

    private function _get_data_query(){

            $this->db->from("pasien");

            if(isset($_POST['search']['value'])){
                $this->db->like('id',$_POST['search']['value']);
                $this->db->or_like('nama',$_POST['search']['value']);
                $this->db->or_like('umur',$_POST['search']['value']);
            }

            if(isset($_POST['order'])){
                $this->db->order_by($this->order[$_POST['order']['0']['column']],$_POST['order']['0']['dir']);
            } else {
                $this->db->order_by('noAtr', 'DESC');
            }

    }

    public function getPasien(){
        $this->_get_data_query();
        if($_POST['length']!=1){
            $this->db->limit($_POST['length'],$_POST['start']);
        }
        $this->db->get()->result_array();
        //return $query-> 
    }
    
    public function count_filtered_data(){
        $this->_get_data_query();
        $query = $this->db->get();
        return $query->num_rows(); 
    }

    public function count_all_data(){
        $this->db->from('pasien');
        return $this->db->count_all_results();
    }
}
