<!DOCTYPE html>
<html lang="en-US" dir="ltr">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="<?= base_url()?>vendor/assets/img/icon.png" type="image/x-icon"/>


    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
    <title><?= $title['judul_web'];?></title>


    <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <!--<link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">-->
    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link href="<?= base_url()?>home/assets/css/theme.css" rel="stylesheet"/>
    <link href="<?= base_url()?>home/assets/fonts/font.css" rel="stylesheet"/>
    <link href="<?= base_url()?>home/assets/css/animate.min.css" rel="stylesheet"/>
    <!-- ===============================================-->
    <!--    End of Stylesheets-->
    <!-- ===============================================-->

    <style>
      .pageDaftar{
        margin-top: 140px !important;
      }

      .btn-block{
        width: 100%;
      }
    </style>

  </head>


  <body class="bg-primary-gradient">


    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    <main class="main" id="top">


      <!-- ===============================================-->
      <!--    Navbar menu -->
      <!-- ===============================================-->
      <nav class="navbar  navbar-dark fixed-top py-1 navPB">
        <div class="container">
          <a class="navbar-brand text-white d-flex align-items-center fw-bold fs-4" href="#">
          Klinik</a>
        </div>
      </nav>
      <!-- ===============================================-->
      <!--    Akhir navbar -->
      <!-- ===============================================-->


      <!-- ===============================================-->
      <!--    Main -->
      <!-- ===============================================-->
      <section class="py-0  mb-3" style="background-attachment: fixed; height: 725px;" id="jumboPB" >
        
        <div class="bg-holder" style="background-image:url(<?= base_url()?>home/assets/img/illustrations/dot.png);background-position:left;background-size:auto;margin-top:-105px;">
        </div>

        <div class="container position-relative">
          <div class="row align-items-center">
            <div class="col-md-5 col-lg-5 daftar mx-auto">
              <div class="card pageDaftar my-auto  mt-5">
                <div class="card-body">
                  <h3 class="card-title text-center fw-bold pt-2">Daftar</h3>
                  <form action="<?= base_url('auth/daftar')?>" method="post">
                    <div class="form-group pt-4">
                      <div class="container">
                        <div class="row">
                          <div class="col-12">
                            <label>Nama</label>
                            <input type="text" class="form-control mb-3" id="nama" value="" name="nama" autocomplete="off" value="<?= set_value('nama')?>" placeholder="Masukan nama anda!">
                            <?= form_error('nama', '<small class="text-danger pl-3">', '</small>'); ?>
                            <label>Username</label>
                            <input type="text" class="form-control mb-3" id="username" value="" name="username" autocomplete="off" placeholder="Masukan username anda!" value="<?= set_value('username')?>">
                            <?= form_error('username', '<small class="text-danger pl-3">', '</small>'); ?>
                            <label>Password</label>
                            <input type="password" autocomplete="off" class="form-control mb-3" placeholder="Masukan password anda!" id="password" value="" name="password">
                            <?= form_error('password', '<small class="text-danger pl-3">', '</small>'); ?>
                            <label>Konfirmasi password</label>
                            <input type="password" autocomplete="off" class="form-control mb-3" placeholder="Masukan konfirmasi password anda!" id="password" value="" name="conPassword">
                            <?= form_error('conPassword', '<small class="text-danger pl-3">', '</small>'); ?>
                            <label>Level</label>
                            <select name="level" class="form-control" id="">
                              <option value="0">Pilih level</option>
                              <option value="1">Admin</option>
                              <option value="2">Dokter</option>
                              <option value="3">Tenaga kesehatan</option>
                            </select><?= form_error('level', '<small class="text-danger pl-3">', '</small>'); ?>
                            <button class="btn btn-primary border-0 bg-primary-gradient d-flex justify-content-center mt-3 btn-block">Daftar</button>
                            <a href="<?= base_url('auth');?>" class="btn btn-outline-primary border-0 d-flex justify-content-center mt-3 mb-3">Kembali</a>
                          </div>
                        </div>
                      </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="text-center mt-5">
          <p class="mb-0 text-white">&copy; 2024 TUGAS BK 
            <svg class="bi bi-suit-heart-fill" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#f20202" viewBox="0 0 16 16">
            <path d="M4 1c2.21 0 4 1.755 4 3.92C8 2.755 9.79 1 12 1s4 1.755 4 3.92c0 3.263-3.234 4.414-7.608 9.608a.513.513 0 0 1-.784 0C3.234 9.334 0 8.183 0 4.92 0 2.755 1.79 1 4 1z"></path>
            </svg>&nbsp;by&nbsp;<a class="text-black" href="#" target="_blank"><b>Muhammad Nur Fauzi</b></a>
          </p>
        </div>
      </section>
      <!-- ===============================================-->
      <!--    Akhir Main -->
      <!-- ===============================================-->


    </main>
    <!-- ===============================================-->
    <!--    End of Main Content-->
    <!-- ===============================================-->


    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="<?= base_url()?>home/assets/js/jquery-3.6.0.min.js"></script>
    <script src="<?= base_url()?>home/vendors/@popperjs/popper.min.js"></script>
    <script src="<?= base_url()?>home/vendors/bootstrap/bootstrap.min.js"></script>
    <script src="<?= base_url()?>home/vendors/is/is.min.js"></script>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
    <script src="<?= base_url()?>home/assets/js/theme.js"></script>
    <!-- ===============================================-->
    <!--    End of JavaScripts-->
    <!-- ===============================================-->
    <script>
      $(document).ready(function () {
        $(window).scroll(function () { 

          var navScroll = $(this).scrollTop();

          if(navScroll >= 20){
            $('.navPB').addClass('bg-primary-gradient');
          }

          if(navScroll < 20){
            $('.navPB').removeClass('bg-primary-gradient');
          }

        });
      });
    </script>

  </body>

</html>