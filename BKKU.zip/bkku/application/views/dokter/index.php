<div class="main-panel">
    <div class="content">
        <div class="panel-header bg-primary-gradient">
            <div class="page-inner py-5">
                <div class="d-flex align-items-md-center flex-column flex-md-row">
                    <div>
                        <h2 class="text-white pb-2 fw-bold"><i class="fas fa-user-md mr-2"></i> dr. <?= $this->session->userdata('user'); ?></h2>
                        <h5 class="text-white op-7 mb-2">Selamat Datang Dokter!</h5>
                    </div>
                    <div class="ml-auto py-2 py-md-0 d-flex justify-content-end text-right">
                        <div class="ml-auto py-2 py-md-0 mr-4">
                            <h6 class="text-white text-right">Sudah diperiksa</h6>
                            <div class="d-flex align-items-center text-right">
                                <i class="fas fa-user-alt text-white pr-1" style="margin-top:-8px; font-size:14px;"></i>
                                <h3 class="text-white text-right" id="sudah"> Pasien</h3>
                            </div>
                        </div>
                        <div class="ml-md-auto py-2 py-md-0 text-right">
                            <h6 class="text-white text-right">Belum diperiksa</h6>
                            <div class="d-flex align-items-center text-right">
                                <i class="fas fa-user-alt text-white pr-1" style="margin-top:-8px; font-size:14px;"></i>
                                <h3 class="text-white text-right" id="belum"> Pasien</h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="page-inner mt--5 collapse" id="rekam">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h3>Data rekam medis</h3>
                    <!--<h4>Status : <span class="rmSts"></span></h4>-->
                    <a href="#" class="btn ttpRm btn-close btn-outline-danger ml-auto mr-2 btn-round" data-toggle="collapse">Tutup</a>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-12 px-5 d-flex justify-content-between align-items-end">
                            <table id="medis">
                                <tr>
                                    <td>Nama</td>
                                    <td>:</td>
                                    <td class="rmNama"></td>
                                </tr>
                                <tr>
                                    <td>Umur</td>
                                    <td>:</td>
                                    <td class="rmUmur"></td>
                                </tr>
                                <tr>
                                    <td>NIK</td>
                                    <td>:</td>
                                    <td class="rmNik"></td>
                                </tr>
                                <tr>
                                    <td>Alamat</td>
                                    <td>:</td>
                                    <td class="rmAlamat"></td>
                                </tr>
                            </table>
                            <div>
                                <form action="<?= base_url('dokter/cetak') ?>" target="_blank" method="post">
                                    <input type="hidden" name="ctkRm">
                                    <h3 class="text-center" style="margin-bottom:40px ;">No RM &nbsp; : &nbsp; <span class="rmNoRm"></span></h3>
                                    <button type="submit" class="btn btn-success ml-auto mr-2 btn-round">Cetak</button>
                                    <button type="button" class="btn tmbRm btn-primary btn-round">Tambah</button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col">
                            <div class="card collapse text-white  bg-info-gradient formTmbRm mt-4">
                                <div class="card-header">
                                    <h3>Tambah Data Rekam Medis</h3>
                                </div>
                                <div class="card-body">
                                    <form action="" id="formRmPsn">
                                        <div class="row">
                                            <div class="col-3">
                                                <label for="" class="text-white">Keluhan</label>
                                                <input type="hidden" class="form-control" id="idRm" name="idRm">
                                                <input type="hidden" class="form-control" id="rmNoRm" name="rmNoRm">
                                                <input type="hidden" class="form-control" id="tanggal" name="tanggal" value="<?= date('d/m/Y'); ?>">
                                                <textarea name="keluhan" class="form-control" id="keluhan" cols="20" rows="5"></textarea>
                                            </div>
                                            <div class="col-3">
                                                <label for="" class="text-white">Pemeriksaan Fisik</label>
                                                <textarea name="periksa" class="form-control" id="periksa" cols="20" rows="5"></textarea>
                                            </div>
                                            <div class="col-3">
                                                <label for="" class="text-white">Diagnosa</label>
                                                <textarea name="diagnosa" class="form-control" id="diagnosa" cols="20" rows="5"></textarea>
                                            </div>
                                            <div class="col-3">
                                                <label for="" class="text-white">Rencana</label>
                                                <textarea name="rencana" class="form-control" id="rencana" cols="20" rows="5"></textarea>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col text-right">
                                                <button type="reset" class="btn btn-danger mt-3" id="tmbReset">Reset</button>
                                                <button type="reset" id="btnBatal" class="btn btn-danger mt-3 btnBatal d-none">Batal</button>
                                                <button type="button" id="tmbSub" class="btn tmbSub btn-primary mt-3">Submit</button>
                                                <button type="button" id="tmbEditRm" class="btn d-none tmbEditRm btn-primary mt-3 ">Edit</button>
                                                <!--<button type="button" id="tmbDisabled" class="btn d-none btn-primary mt-3 disabled">Disabled</button>-->
                                            </div>
                                        </div>
                                    </form>
                                </div>

                            </div>
                        </div>
                    </div>
                    <div class="row mt-5">
                        <div class="col-12">
                            <table class="table table-striped" id="tablep">
                                <thead class="bg-info text-white">
                                    <tr>
                                        <th>Tanggal</th>
                                        <th>Keluhan Pasien</th>
                                        <th>Pemeriksaan Fisik</th>
                                        <th>Diagnosa</th>
                                        <th>Rencana</th>
                                        <th>Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="page-inner mt--5">
            <div class="card">
                <div class="card-header d-flex justify-content-between">
                    <h3>Data Pasien</h3>
                    <h5 class="mt-1">Otomatis update dalam 10 detik</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-12">
                            <table class="table table-striped" id="tableo">
                                <thead class="bg-primary text-white">
                                    <tr>
                                        <th width="10">Antrian</th>
                                        <th>Rm</th>
                                        <th>NIK</th>
                                        <th>Nama</th>
                                        <th>Alamat</th>
                                        <th width="10">Periksa</th>
                                        <th width="50">Aksi</th>
                                    </tr>
                                </thead>
                                <tbody>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>

        </div>
    </div>

    <!-- Modal detail data pasien -->
    <div class="modal fade" id="psnDet" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog  modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="staticBackdropLabel">Detail Pasien</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="container">
                        <div class="row">
                            <div class="col-12 mx-auto">
                                <form action="" id="formEdt">
                                    <div class="row">
                                        <div class="col-6">
                                            <label for="">No Antrian</label>
                                            <p class="fw-bold h3 psnAtr"></p>
                                        </div>
                                        <div class="col-6">
                                            <label for="">No RM</label>
                                            <p class="fw-bold h3 psnRm"></p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <label for="">Nama Lengkap</label>
                                            <p class="fw-bold h3 psnNama"></p>
                                        </div>
                                        <div class="col-6">
                                            <label for="">NIK</label>
                                            <p class="fw-bold h3 psnNik"></p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <label for="">Umur</label>
                                            <p class="fw-bold h3 psnUmur"></p>
                                        </div>
                                        <div class="col-6">
                                            <label for="">Jenis kelamin</label>
                                            <p class="fw-bold h3 psnJenkel"></p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <label for="">Alamat</label>
                                            <p class="fw-bold h3 psnAlamat"></p>
                                        </div>
                                        <div class="col-6">
                                            <label for="">Tanggal Daftar</label>
                                            <p class="fw-bold psnTgl h3"></p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <label for="">Jam daftar</label>
                                            <p class="fw-bold psnJam h3"></p>
                                        </div>
                                        <div class="col-6">
                                            <label for="">Penginput data</label>
                                            <p class="fw-bold psnUser h3"></p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col">
                                            <span for="" class=" ml-auto">Status &nbsp;:&nbsp; <div type="button" class="badge psnSts"></div></span>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Akhir modal -->

    <!-- Modal detail data pasien -->
    <div class="modal fade" id="mdlRm" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h3 class="modal-title" id="staticBackdropLabel">Tambah Data Rekam Medis</h3>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="container">
                        <div class="row">
                            <div class="col-12 mx-auto">
                                <form action="" id="formEdt">
                                    <div class="row">
                                        <div class="col-6">
                                            <label for="">No Antrian</label>
                                            <p class="fw-bold h3 psnAtr"></p>
                                        </div>
                                        <div class="col-6">
                                            <label for="">No RM</label>
                                            <p class="fw-bold h3 psnRm"></p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <label for="">Nama Lengkap</label>
                                            <p class="fw-bold h3 psnNama"></p>
                                        </div>
                                        <div class="col-6">
                                            <label for="">NIK</label>
                                            <p class="fw-bold h3 psnNik"></p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <label for="">Umur</label>
                                            <p class="fw-bold h3 psnUmur"></p>
                                        </div>
                                        <div class="col-6">
                                            <label for="">Jenis kelamin</label>
                                            <p class="fw-bold h3 psnJenkel"></p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <label for="">Alamat</label>
                                            <p class="fw-bold h3 psnAlamat"></p>
                                        </div>
                                        <div class="col-6">
                                            <label for="">Tanggal Daftar</label>
                                            <p class="fw-bold psnTgl h3"></p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-6">
                                            <label for="">Jam daftar</label>
                                            <p class="fw-bold psnJam h3"></p>
                                        </div>
                                        <div class="col-6">
                                            <label for="">Penginput data</label>
                                            <p class="fw-bold psnUser h3"></p>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col">
                                            <span for="" class=" ml-auto">Status &nbsp;:&nbsp; <div type="button" class="badge psnSts"></div></span>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Akhir modal -->

    <footer class="footer">
        <div class="container-fluid">
            <div class="copyright ml-auto mx-auto my-auto">
                &copy; 2024 TUGAS BK
                <svg class="bi bi-suit-heart-fill" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#f20202" viewBox="0 0 16 16">
                    <path d="M4 1c2.21 0 4 1.755 4 3.92C8 2.755 9.79 1 12 1s4 1.755 4 3.92c0 3.263-3.234 4.414-7.608 9.608a.513.513 0 0 1-.784 0C3.234 9.334 0 8.183 0 4.92 0 2.755 1.79 1 4 1z"></path>
                </svg>&nbsp;by&nbsp;<a class="text-black" href="#" target="_blank"><b>Muhammad Nur Fauzi</b>
            </div>
        </div>
    </footer>
</div>