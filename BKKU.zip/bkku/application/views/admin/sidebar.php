<!-- ===============================================-->
<!--    Div pembuka -->
<!-- ===============================================-->
<div class="wrapper ">

		<div class="main-header">

			<!-- Logo Header -->
			<div class="logo-header" data-background-color="blue2">
				
				<a href="index.html" class="logo d-flex align-items-end">
					<!--<img src="<?= base_url()?>vendor/assets/img/logo.svg" alt="navbar brand" class="navbar-brand">-->
					<h1 class="text-white ">SIRAME</h1>
				</a>
				<button class="navbar-toggler sidenav-toggler ml-auto" type="button" data-toggle="collapse" data-target="collapse" aria-expanded="false" aria-label="Toggle navigation">
					<span class="navbar-toggler-icon">
						<i class="icon-menu"></i>
					</span>
				</button>
				<button class="topbar-toggler more"><i class="icon-options-vertical"></i></button>
				<div class="nav-toggle">
					<button class="btn btn-toggle toggle-sidebar">
						<i class="icon-menu"></i>
					</button>
				</div>
			</div>
			<!-- End Logo Header -->

			<!-- Navbar Header -->
			<nav class="navbar navbar-header navbar-expand-lg" data-background-color="blue2">
				<div class="container-fluid">
					<ul class="navbar-nav topbar-nav ml-md-auto align-items-center">
						<li class="nav-item text-white">
							<?php  date_default_timezone_set('Asia/Jakarta'); 
							$hari   = date('l');
							$hari_indonesia = array('Monday'  => 'Senin',
								'Tuesday'  => 'Selasa',
								'Wednesday' => 'Rabu',
								'Thursday' => 'Kamis',
								'Friday' => 'Jumat',
								'Saturday' => 'Sabtu',
								'Sunday' => 'Minggu');
							echo $hari_indonesia[$hari].", ";
							function tanggal_indo($tanggal)
											{
												$bulan = array (1 =>   'Januari',
															'Februari',
															'Maret',
															'April',
															'Mei',
															'Juni',
															'Juli',
															'Agustus',
															'September',
															'Oktober',
															'November',
															'Desember'
														);
												$split = explode('-', $tanggal);
												return $split[2] . ' ' . $bulan[ (int)$split[1] ] . ' ' . $split[0];
											} echo tanggal_indo(date('Y-m-d'));?>
						</li>
						<i class="fas fa-calendar-alt text-white fs-2"></i>
					</ul>
				</div>
			</nav>
			<!-- End Navbar -->
		</div>

		<!-- ===============================================-->
		<!--    Sidebar menu -->
		<!-- ===============================================-->
		<div class="sidebar sidebar-style-2">			
			<div class="sidebar-wrapper scrollbar scrollbar-inner">
				<div class="sidebar-content">
					<div class="user">
						<div class="avatar-sm float-left mr-2 ">
							<?php $user = $this->db->select('foto,nama')->get_where('user', ['id'=>$this->session->userdata('id')])->row_array(); ?>
							
							<img src="<?php echo base_url()?>assets/<?= $user['foto'];?>" alt="<?= base_url()?>vendor." class="avatar-img rounded-circle">
						</div>
						<div class="info">
							<a href="">
								<span>
									<?= $user['nama'];?>
									<span class="user-level">Administrator</span>
								</span>
							</a>
						</div>
					</div>

                    <!-- Menu admin -->
                    <ul class="nav nav-primary">
                        <?php foreach($menu as $m ):?>
                            <?php if($title == $m['nama']) : ?>
                                <li class="nav-item active">
                            <?php else : ?>
                                <li class="nav-item">
                            <?php endif;?>
                                    <a id="menu" href="<?= base_url($m['url'])?>">
                                        <i class="<?= $m['icon'];?>"></i>
                                        <p><?= $m['nama'];?></p>
                                    </a>
                                </li>
                        <?php endforeach;?>
                    </ul>
                    <?= $title;?>
                    <!-- End of menu admin -->
                    
					<!--<ul class="nav nav-primary">
						<li class="nav-item">
							<a href="<?= base_url('admin')?>">
								<i class="fas fa-home"></i>
								<p>Dashboard</p>
								
							</a>
						</li>
						<li class="nav-item">
							<a href="<?= base_url('admin/landingPage')?>">
								<i class="fas fa-layer-group"></i>
								<p>landing page</p>
								
							</a>
						</li>
						<li class="nav-item">
							<a href="<?= base_url('auth/logout')?>">
								<i class="fas fa-sign-out-alt"></i>
								<p>logout</p>
								
							</a>
						</li>
					</ul>-->
				</div>
			</div>
		</div>
		<!-- ===============================================-->
		<!--    End of Sidebar menu -->
		<!-- ===============================================-->
