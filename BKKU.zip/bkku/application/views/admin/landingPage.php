		<!-- ===============================================-->
		<!--    Main menu -->
		<!-- ===============================================-->
		<div class="main-panel">
			<?= 
			$this->session->flashdata('pesan');
			?>

			<div class="content">
				<div class="panel-header bg-primary-gradient">
					<div class="page-inner py-5">
						<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
							<div>
								<h2 class="text-white pb-2 fw-bold">Landing page</h2>
								<h5 class="text-white op-7 mb-2">Pengaturan umum website!</h5>
								<!--<a href="" class="btn btn-primary">Preview</a>-->
							</div>
							<div class="ml-md-auto py-2 py-md-0">
								<!--<div class="alert alert-success alert-dismissible fade show shadow-lg" role="alert" id="alert">
									Data berhasil diubah! &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
									<button type="button" class="close my-auto" style="transform: translateY(-12px);" data-dismiss="alert" aria-label="Close">
										&times;
										
									</button>
								</div>-->
							<!--<a href="#" class="btn btn-light btn-round">Update</a>-->
							</div>
							<div class="ml-md-auto py-2 py-md-0">
								<!--<a class="alert bg-success-gradient text-white text-center  fade show shadow" role="alert" id="alert" style="margin-bottom:-30px; transform:translateY(-10px); border-radius:30px !important;">Data berhasil diubah!</a>-->
								<a href="<?= base_url();?>" target="_blank" class="btn btn-white  btn-round mr-2">Preview</a>
								
								<!--<a href="#" class="btn btn-light btn-round">Update</a>-->
							</div>
						</div>
					</div>
				</div>

				<div class="container-fluid">
					<div class="row">
						<div class="col-6">
							<div class="card mx-auto px-3 py-3" style="transform : translateY(-35px);">
								<form action="<?= base_url('admin/general')?>" method="post" id="formGnl">
									<div class="col">
										<h3 for="" class=" fw-bold">General<?= $this->session->flashdata('general');?></h3>
										<hr style="background: black;">
										<label for="" class="mb-2">Nama Website</label>
										<input autocomplete="off" required type="text" name="nama_web" class="form-control" value="<?= $kelola['nama_web'];?>">
										<label for="" class="mb-2 mt-3">Judul website</label>
										<input autocomplete="off" required type="text" name="judul_web" class="form-control mb-2" value="<?= $kelola['judul_web'];?>">
										<button type="button" class="btnGnl disabled btn btn-primary mt-3 ml-md-auto d-flex align-items-left">Ubah</button>
									</form>
									</div>
							</div>
							<div class="card mx-auto px-3 py-3" style="transform : translateY(-35px);">
								<form action="<?= base_url('admin/tentangKami')?>" method="post" id="formTng">
									<div class="col">
										<h3 for="" class="mb-2 fw-bold">Tentang kami<?= $this->session->flashdata('tentang');?></h3>
										<hr style="background: black;">
										<label for="" class="mb-2 ">Tagline</label>
										<textarea required type="text" name="tagline_tk" class="form-control" value=""><?= $kelola['tagline_tk'];?></textarea>
										<label for="" class="mb-2 mt-3">Detail isi</label>
										<textarea required type="text" name="detail_tk" class="form-control mb-2" value=""><?= $kelola['detail_tk'];?></textarea>
										<button type="button" href="" class="btn btn-primary mt-3 ml-md-auto d-flex align-items-left btnTng disabled">Ubah</button>
									</div>
								</form>
							</div>
							
							<div class="card mx-auto px-3 py-3" style="transform : translateY(-35px);">
								<form action="<?= base_url('admin/jamBuka')?>" method="post" id="formJb">
									<div class="col">
										<h3 for="" class="mb-2 fw-bold">Jam buka<?= $this->session->flashdata('jam_buka');?></h3>
										<hr style="background: black;">
										<div class="row">
											<div class="col-12 mb-2">
												<label for="" class="mb-2 ">Keterangan</label>
												<textarea name="tg_utama" class="form-control" id="tg_utama" cols="30" rows="3"><?= $jam['tg_utama']?></textarea>
												<!--<input type="text" class="form-control" value="">-->
											</div>
										</div>
										<label for="" class="mb-2 ">Judul</label>
										<div class="row">
											<div class="col-4">
												<input autocomplete="off" required type="text" name="judul_1" class="form-control mb-2" value="<?= $jam['judul_1']?>">
											</div>
											<div class="col-4">
												<input  autocomplete="off" required type="text" name="judul_2" class="form-control mb-2" value="<?= $jam['judul_2']?>">
											</div>
											<div class="col-4">
												<input autocomplete="off" required type="text" name="judul_3" class="form-control mb-2" value="<?= $jam['judul_3']?>">
											</div>
										</div>
										<label for="" class="mb-2 mt-3">Tagline</label>
										<div class="row">
											<div class="col-4">
												<textarea required name="tagline_1"  class="form-control" id="" cols="30" rows="10"><?= $jam['tagline_1']?></textarea>
											</div>
											<div class="col-4">
												<textarea required name="tagline_2" class="form-control" id="" cols="30" rows="10"><?= $jam['tagline_2']?></textarea>
											</div>
											<div class="col-4">
												<textarea required name="tagline_3" class="form-control" id="" cols="30" rows="10"><?= $jam['tagline_3']?></textarea>
											</div>
										</div>
										<label for="" class="mb-2 mt-3">Jam buka</label>
										
										<div class="row">
											<div class="col-4">
												<a href="javascript:void(0);" class="btn btn-block btn-primary mb-2 py-1 lb1 text-white" onclick="libur1()">Libur</a>
												<div class="form1">
													<input autocomplete="off" type="time" name="jam_1b" value="<?= $jam['jam_1b']?>" class="form-control mb-2" >
													<h6 class="text-center">s/d</h6>
													<input autocomplete="off" type="time" name="jam_1t" value="<?= $jam['jam_1t']?>" class="form-control mb-2" >
												</div>
												
											</div>
											<div class="col-4">
												<a href="javascript:void(0);" class="btn btn-block btn-primary mb-2 py-1 lb2 text-white" onclick="libur2()">Libur</a>
												<div class="form2">
													<input autocomplete="off" type="time" name="jam_2b" value="<?= $jam['jam_2b']?>" class="form-control mb-2" >
													<h6 class="text-center">s/d</h6>
													<input autocomplete="off" type="time" name="jam_2t" value="<?= $jam['jam_2t']?>" class="form-control mb-2" >
												</div>
												
											</div>
											<div class="col-4">
												<a href="javascript:void(0);" class="btn btn-block btn-primary mb-2 py-1 lb3 text-white" onclick="libur3()">Libur</a>
												<div class="form3">
													<input autocomplete="off" type="time" name="jam_3b" value="<?= $jam['jam_3b']?>" class="form-control mb-2" >
													<h6 class="text-center">s/d</h6>
													<input autocomplete="off" type="time" name="jam_3t" value="<?= $jam['jam_3t']?>" class="form-control mb-2" >
												</div>
												
											</div>
											<button type="submit" class="btn btn-primary mt-3 mr-3 ml-md-auto d-flex align-items-left btnJb disabled">Ubah</button>
										</div>
									</div>
								</form>
							</div>
							<div class="card mx-auto px-3 py-3" style="transform : translateY(-35px);">
								<form action="<?= base_url('admin/footer')?>" method="post" id="formFt">
									<div class="col">
										<h3 for="" class="mb-2 fw-bold">Footer<?= $this->session->flashdata('footer');?></h3>
										<hr style="background: black;">
										<label for="" class="mb-2 ">Tagline</label>
										<textarea required type="text" name="tagline_ft" class="form-control" value=""><?= $kelola['tagline_ft'];?></textarea>
										<label for="" class="mb-2 mt-3">Instagram</label>
										<div class="input-group ">
											<div class="input-group-prepend">
												<span class="input-group-text">https://</span>
											</div>
											<input autocomplete="off" required type="text" name="instagram_ft" class="form-control" value="<?= $kelola['instagram_ft'];?>">
										</div>
										<label for="" class="mb-2 mt-3">Facebook</label>
										<div class="input-group ">
											<div class="input-group-prepend">
												<span class="input-group-text">https://</span>
											</div>
											<input autocomplete="off" required type="text" name="facebook_ft" class="form-control" value="<?= $kelola['facebook_ft'];?>">
										</div>
										<label for="" class="mb-2 mt-3">Twitter</label>
										<div class="input-group ">
											<div class="input-group-prepend">
												<span class="input-group-text">https://</span>
											</div>
											<input autocomplete="off" required type="text" name="twitter_ft" class="form-control" value="<?= $kelola['twitter_ft'];?>">
										</div>
										<label for="" class="mb-2 mt-3">Youtube</label>
										<div class="input-group ">
											<div class="input-group-prepend">
												<span class="input-group-text">https://</span>
											</div>
											<input autocomplete="off" required type="text" name="youtube" class="form-control" value="<?= $kelola['youtube'];?>">
										</div>
										<button type="submit" href="" class="btn btn-primary mt-3 ml-md-auto d-flex align-items-left btnFt disabled">Ubah</button>
									</div>
								</form>
							</div>
						</div>
						<div class="col-6">
							<div class="card mx-auto px-3 py-3" style="transform : translateY(-35px);">
								<form action="<?= base_url('admin/jumbotron')?>" method="post" id="formJmb">
									<div class="col">
										<h3 for="" class="mb-2 fw-bold">Jumbotron<?= $this->session->flashdata('jumbo');?></h3>
										<hr style="background: black;">
										<label for="" class="mb-2">Nama</label>
										<input autocomplete="off" required type="text" name="nama_jumbo" class="form-control" value="<?= $kelola['nama_jumbo'];?>">
										<label for="" class="mb-2 mt-3">Tagline</label>
										<textarea autocomplete="off" required type="text" name="tagline_jumbo" class="form-control mb-2" value=""><?= $kelola['tagline_jumbo'];?></textarea>
										<button type="button" href="" class="btn btn-primary mt-3 ml-md-auto d-flex align-items-left btnJmb disabled">Ubah</button>
									</div>
								</form>
							</div>
							
							<div class="card mx-auto px-3 py-3" style="transform : translateY(-35px);">
								<form action="<?= base_url('admin/layanan')?>" method="post" id="formLyn">
									<div class="col">
										<h3 for="" class="mb-2 fw-bold">Layanan<?= $this->session->flashdata('layanan');?></h3>
										<hr style="background: black;">
										<label for="" class="mb-2 ">Tagline</label>
										<textarea required type="text" name="tagline_ly" class="form-control mb-2" value=""><?= $kelola['tagline_ly'];?></textarea>
										<button type="submit" href="" class="btn disabled btnLyn btn-primary mt-3 ml-md-auto d-flex align-items-left">Ubah</button>
									</div>
								</form>
							</div>
							<div class="card mx-auto px-3 py-3" style="transform : translateY(-35px);">
								<form action="<?= base_url('admin/alamat')?>" method="post" id="formAlm">
									<div class="col">
										<h3 for="" class="mb-2 fw-bold">Alamat<?= $this->session->flashdata('alamat');?></h3>
										<hr style="background: black;">
										<label for="" class="mb-2 ">Tagline</label>
										<textarea required type="text" name="tagline_alm" class="form-control mb-2" value=""><?= $kelola['tagline_alm'];?></textarea>
										<label for="" class="mb-2 mt-3">Link google map</label>
										<div class="input-group ">
											<div class="input-group-prepend">
												<span class="input-group-text">https://</span>
											</div>
											<input autocomplete="off" required type="text" name="link_alm" class="form-control" value="<?= $kelola['link_alm'];?>">
										</div>
										<label for="" class="mb-2 mt-4">Maps inframe</label>
										<textarea required type="text" rows="10" name="maps" class="form-control mb-2" value=""><?= $kelola['maps'];?></textarea>
										<button type="submit" href="" class="btn btnAlm disabled btn-primary mt-3 ml-md-auto d-flex align-items-left">Ubah</button>
									</div>
								</form>
							</div>
							<div class="card mx-auto px-3 py-3" style="transform : translateY(-35px);">
								<form action="<?= base_url('admin/pesan')?>"  id="formData" method="post">
									<div class="col">
										<h3 for="" class="mb-2 fw-bold">Pesan<?= $this->session->flashdata('alert');?><div class="alertP"></div></h3>
										<hr style="background: black;">
										<label for="" class="mb-2 ">Judul</label>
										<input autocomplete="off" required name="judul" id="judul" type="text" class="form-control mb-2" >
										<input autocomplete="off" required name="idPesan" id="idPesan" type="hidden" class="form-control mb-2" >
										<label for="" class="mb-2 mt-3">Isi pesan</label>
										<textarea required name="isi" class="form-control" id="isi" cols="30" rows="5"></textarea>
										<div class="row d-flex justify-content-end">
											<div class="col-3">
												<button type="reset" class="btn btn-danger mt-3 ml-md-auto d-flex align-items-center" id="btnReset">Batal</button>
											</div>
											<div class="col-3">
												<button type="submit" class="btn btn-primary mt-3 ml-md-auto d-flex align-items-left btnTmb">Tambah</button>
											</div>
										</div>
									</div>
								</form>
							</div>
							<div class="card mx-auto px-3 py-3" style="transform : translateY(-35px);">
								<form action="" method="post">
									<div class="col">
										<h3 for="" class="mb-2 fw-bold">Daftar pesan</h3>
										<hr style="background: black;">
										<table class="table" id="table1">
											<thead>
												<tr>
													<th>Judul</th>
													<th>Isi pesan</th>
													<th>Aksi</th>
												</tr>
											</thead>
											<tbody>
												<?php foreach($pesan as $p):?>
													<tr>
														<td><p class="pt-2"><?= $p['judul'];?></p></td>
														<td><p class="pt-2"><?= $p['isi'];?></p></td>
														<td class="dropdown">
															<a class="dropdown-toggle btn btn-primary py-0 rounded-pill px-2" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"></a>
															<div class="dropdown-menu">
																<li class="dropdown-item" href="#"><a href="javascript:;" onclick="btnData(<?= $p['id'];?>)" class="badge badge-primary">Ubah</a></li>
																<li class="dropdown-item" href="#">
																	<?php if($p['active']==1):?>
																	<?php else:?>
																		<a href="javascript:void(0);" onclick="btnHapus(<?= $p['id'];?>)" class="badge badge-danger btnHapus">Hapus</a>
																	<?php endif;?>
																</li>
																<li class="dropdown-item" href="#">
																	<?php if($p['active']==1):?>
																		<div class="badge badge-success">Awal</div>
																	<?php else:?>
																		<a href="javascript:void(0);" data-id="<?= $p['id'];?>" onclick="btnAwal(<?= $p['id'];?>)" class="badge badge-danger btnAwal">Berikut</a>
																	<?php endif;?>
																</li>
															</div>
														</td>
													</tr>
												<?php endforeach;?>	
											</tbody>
										</table>
									</div>
								</form>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-12">
							<div class="card mx-auto px-3 py-3" style="transform : translateY(-35px);">
							<!--<form action="http://localhost/rm/dokter/udtProfil" enctype="multipart/form-data" method="post" accept-charset="utf-8">-->
								<form action="<?= base_url('admin/edtKop')?>" enctype="multipart/form-data" id="formKop" method="post" accept-charset="utf-8">
									<div class="col">
										<h3 for="" class="mb-2 fw-bold">KOP Rekam Medis<?= $this->session->flashdata('kop');?></h3>
										<hr style="background: black;">
										<label for="" class="mb-2">Nama</label>
										<input autocomplete="off" required name="nama_kop" type="text" class="form-control" value="<?= $kelola['nama_kop'];?>">
										<label for="" class="mb-2 mt-3">Nomer</label>
										<input autocomplete="off" required name="nomer_kop" type="text" class="form-control" value="<?= $kelola['nomer_kop'];?>">
										<label for="" class="mb-2 mt-3">Alamat</label>
										<input autocomplete="off" required name="alamat_kop" type="text" class="form-control" value="<?= $kelola['alamat_kop'];?>">
										<label for="" class="mb-2 mt-3">Telepon</label>
										<input autocomplete="off" required name="telp_kop" type="text" class="form-control" value="<?= $kelola['telp_kop'];?>">
										<label for="" class="mb-2 mt-3">Email</label>
										<input autocomplete="off" required name="email_kop" type="text" class="form-control" value="<?= $kelola['email_kop'];?>">
										<label for="" class="mb-2 mt-3">Logo</label>
										<input autocomplete="off" type="file" name="logo_kop" class="form-control-file" id="logo_kop">
										<button type="button" id="btnKop" class="disabled btn btn-primary mt-3 ml-md-auto d-flex align-items-left">Ubah</button>
									</div>
								</form>
							</div>
						</div>
						
					</div>
				</div>
			</div>

			<footer class="footer">
				<div class="container-fluid">
					<div class="copyright ml-auto mx-auto my-auto">
						&copy; 2024 TUGAS BK 
						<svg class="bi bi-suit-heart-fill" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#f20202" viewBox="0 0 16 16">
						<path d="M4 1c2.21 0 4 1.755 4 3.92C8 2.755 9.79 1 12 1s4 1.755 4 3.92c0 3.263-3.234 4.414-7.608 9.608a.513.513 0 0 1-.784 0C3.234 9.334 0 8.183 0 4.92 0 2.755 1.79 1 4 1z"></path>
						</svg>&nbsp;by&nbsp;<a class="text-black" href="#" target="_blank"><b>Muhammad Nur Fauzi</b>
					</div>				
				</div>
			</footer>
		</div>
		<!-- ===============================================-->
		<!--    End of Main menu -->
		<!-- ===============================================-->
	
		
	</div>
	<!-- ===============================================-->
	<!--    Div penutup -->
	<!-- ===============================================-->