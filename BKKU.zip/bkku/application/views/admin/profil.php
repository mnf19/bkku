		<!-- ===============================================-->
		<!--    Main menu -->
		<!-- ===============================================-->

		<?php $user = $this->db
		->get_where('user', ['id'=>$this->session->userdata('id')])
		->row_array(); ?>
		<?= $this->session->flashdata('pesan');?>

		<div class="main-panel">

			<div class="content">
				<div class="panel-header bg-primary-gradient">
					<div class="page-inner py-5">
						<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
							<div>
								<h2 class="text-white pb-2 fw-bold">Profil</h2>
								<h5 class="text-white op-7 mb-2">Semua data diri anda ada disini!</h5>
								<!--<a href="" class="btn btn-primary">Preview</a>-->
							</div>
							<div class="ml-md-auto py-2 py-md-0">
								<!--<a href="<?= base_url();?>" target="_blank" class="btn btn-white btn-border btn-round mr-2">Preview</a>-->
								<!--<form action="<?= base_url('admin/udtProfil')?>" method="post">-->
								<?= form_open_multipart('admin/udtProfil'); ?>
								<button type="submit" class="btn btn-light btn-round">Update</button>
							</div>
						</div>
					</div>
				</div>

				<div class="container-fluid">
					<div class="row">
						<div class="col">
							<div class=" mx-auto px-3 py-3" style="transform : translateY(-50px);">
								<div class="row">
									<div class="col-md-4">
													<div class="card card-profile">
														<div class="card-header" style="background-image: url('<?= base_url('vendor/assets/img/blogpost.jpg');?>')">
															<div class="profile-picture">
																<div class="avatar avatar-xl" style="width:100px; height:100px;">
																	<!--<?php $foto = $this->db->select('foto')->get_where('user', ['id'=>$this->session->userdata('id')])->row_array(); ?>-->
																	<img src="<?php echo base_url()?>assets/<?= $user['foto'];?>" alt="<?= base_url()?>vendor." class="avatar-img rounded-circle">
																</div>
															</div>
														</div>
														<div class="card-body">
															<div class="user-profile text-center">
																<div class="name"><?= $user['nama']?></div>
																<div class="job">Username : <?= $user['username']?></div>
																<div class="view-profile">
																	<div class="btn btn-secondary btn-block"><span class="fs-5 fw-bold">Sebagai administrator</span></div>
																</div>
															</div>
														</div>
													</div>
												</div>
									<div class="col-md-8">
										<div class="card card-with-nav">
											<div class="card-header">
												<div class="row row-nav-line">
													<ul class="nav nav-tabs nav-line nav-color-secondary w-100 pl-3" role="tablist">
														<li class="nav-item">
															<h1 class="fw-bold py-3">User profil </h1>
														</li>
														<?= $this->session->flashdata('profil');?>
												</div>
											</div>
											<div class="card-body">
												
												<div class="row mt-3">
													<div class="col-md-6">
														<div class="form-group form-group-default">
															<label>Nama lengkap</label>
															<input autocomplete="off" type="hidden" class="form-control" name="id" value="<?= $user['id'];?>">
															<input  autocomplete="off" type="text" required class="form-control" name="nama" value="<?= $user['nama'];?>">
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group form-group-default">
															<label>Username</label>
															<input autocomplete="off" type="text" required class="form-control" name="username"  value="<?= $user['username'];?>">
														</div>
													</div>
												</div>

												<div class="row mt-3">
													<div class="col-md-6">
														<div class="form-group form-group-default">
															<label>NIP</label>
															<input autocomplete="off" type="text" required class="form-control"  name="nip" value="<?= $user['nip'];?>">
														</div>
													</div>
													<div class="col-md-6">
														<div class="form-group form-group-default">
															<label>Jenis kelamin</label>
															<select required class="form-control" name="jenkel">
																<?php $sex = ['laki-laki','perempuan']; foreach($sex as $jk):?>
																	<?php if($jk == $user['jenkel']):?>
																		<option value="<?= $jk;
																		?>" selected><?= $jk;
																		?></option>
																	<?php else:?>
																		<option value="<?= $jk;
																		?>"><?= $jk;?></option>
																	<?php endif;?>
																<?php endforeach;?>
															</select>
														</div>
													</div>
												</div>

												<div class="row mt-3">
													<div class="col-md-4">
														<div class="form-group form-group-default">
															<label>Tempat lahir</label>
															<input autocomplete="off" required type="text" class="form-control"  name="tempat_lahir" value="<?= $user['tempat_lahir'];?>">
														</div>
													</div>
													<div class="col-md-4">
														<div class="form-group form-group-default">
															<label>Tanggal lahir</label>
															<input autocomplete="off" required type="date" class="form-control" id="datepicker" name="tgl_lahir" value="<?= $user['tgl_lahir'];?>">
														</div>
													</div>
													<div class="col-md-4">
														<div class="form-group form-group-default">
															<label>Agama</label>
															<select required class="form-control" name="agama">
																<?php $agama = ['Islam','Kristen','Budha','Hindu','Konghucu']; foreach($agama as $a):?>
																	<?php if($a == $user['agama']):?>
																		<option value="<?= $a;
																		?>" selected><?= $a;
																		?></option>
																	<?php else:?>
																		<option value="<?= $a;
																		?>"><?= $a;?></option>
																	<?php endif;?>
																<?php endforeach;?>
															</select>
														</div>
													</div>
												</div>
												<div class="row mt-3">
													<div class="col-md-12">
														<div class="form-group form-group-default">
															<label>Alamat</label>
															<input autocomplete="off" required type="text" class="form-control" value="<?= $user['alamat'];?>" name="alamat">
														</div>
													</div>
												</div>
												<div class="row mt-3 mb-4">
													<div class="col-md-6">
														<div class="form-group form-group-default">
															<label>Foto profil</label>
															<input autocomplete="off" type="file" name="foto" value="" id="filePhoto" class="required borrowerImageFile" data-errormsg="PhotoUploadErrorMsg">
														</div>
														<span class='text-danger'>Ukuran file maximal 2 mb | </span>
														<span class='text-danger'>Format file yang didukung  ('GIF' , 'PNG' , 'JPEG' , 'JPG' )</span>
													</div>
													<div class="col-md-6 mx-auto">
														<div class="profile-picture d-flex justify-content-center">
															<div class="avatar avatar-xl" style="width:100px; height:100px;">
																<img src="<?= base_url('assets/default.jpg')?>" id="previewHolder" alt="" class="avatar-img rounded-circle">
																<span>Image preview</span>
															</div>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<footer class="footer">
				<div class="container-fluid">
					<div class="copyright ml-auto mx-auto my-auto">
						&copy; 2024 TUGAS BK
						<svg class="bi bi-suit-heart-fill" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#f20202" viewBox="0 0 16 16">
						<path d="M4 1c2.21 0 4 1.755 4 3.92C8 2.755 9.79 1 12 1s4 1.755 4 3.92c0 3.263-3.234 4.414-7.608 9.608a.513.513 0 0 1-.784 0C3.234 9.334 0 8.183 0 4.92 0 2.755 1.79 1 4 1z"></path>
						</svg>&nbsp;by&nbsp;<a class="text-black" href="#" target="_blank"><b>Muhammad Nur Fauzi</b>
					</div>				
				</div>
			</footer>
		</div>
		<!-- ===============================================-->
		<!--    End of Main menu -->
		<!-- ===============================================-->
	
		
	</div>
	<!-- ===============================================-->
	<!--    Div penutup -->
	<!-- ===============================================-->