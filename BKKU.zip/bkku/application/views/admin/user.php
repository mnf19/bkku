		<!-- ===============================================-->
		<!--    Main menu -->
		<!-- ===============================================-->
		<div class="main-panel">

			<div class="content">
				<div class="panel-header bg-primary-gradient">
					<div class="page-inner py-5">
						<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
							<div>
								<h2 class="text-white pb-2 fw-bold">User</h2>
								<h5 class="text-white op-7 mb-2">Memuat semua data user!</h5>
							</div>
							<div class="ml-md-auto py-2 py-md-0">
								<a href="#form" class="btn btn-light btn-round" id="buka">Tambah</a>
							</div>
						</div>
					</div>
				</div>
				<div class="container-fluid">
					<div class="row">
						<div class="col-8 mx-auto">
							<div class="collapse page-inner mt--5" id="collapseExample">
								<div class="card card-body">
									<div class="contianer">
										<div class="d-flex">
											<h2>Detail User</h2>
											<h4 class="ml-auto py-auto pt-0" id="detLevel"></h4>
										</div>
										
										<hr style="background:grey;">
										<div class="row">
											<div class="col d-flex justify-content-center">
												<div class="imgProfil">
												</div>
											</div>
										</div>
										<div class="row mt-4">
											<div class="col-4"> 
												<span>Nama lengkap</span>
												<h3 id="detNama"></h3>
											</div>
											<div class="col-4"> 
												<span>Username</span>
												<h3 id="detUsername"></h3>
											</div>
											<div class="col-4"> 
												<span>Alamat</span>
												<h3 id="detAlamat"></h3>
											</div>
										</div>
										<div class="row mt-3">
											<div class="col-4"> 
												<span>NIP</span>
												<h3 id="detNip"></h3>
											</div>
											<div class="col-4"> 
												<span>Jenis kelamin</span>
												<h3 id="detJenkel"></h3>
											</div>
											<div class="col-4"> 
												<span>Status user</span>
												<h3 id="detStatus"></h3>
											</div>
										</div>
										<div class="row mt-3">
											<div class="col-4"> 
												<span>Tempat lahir</span>
												<h3 id="detTmp"></h3>
											</div>
											<div class="col-4"> 
												<span>Tanggal lahir</span>
												<h4 id="detLhr"></h4>
											</div>
											<div class="col-4"> 
												<span>Agama</span>
												<h3 id="detAgama"></h3>
											</div>
										</div>
										<button data-toggle="collapse" data-target="#collapseExample" class="btn btn-primary ml-auto float-right mt-3 rounded-pill">Tutup</button>
									</div>
								</div>
							</div>
						</div>
					</div>
					
					<div class="row">
						<div class="col">
							<div class="ollapse page-inner mt--5">
								<div class="card mx-auto px-3 py-3">
									<div class="card-header">
										<div class="d-flex justify-content-between">
											<h2 class="fw-bold ml-3">Data user</h2>
											<?= $this->session->flashdata('pesan');?>
											<h5 class="fw-bold ml-auto mr-3 my-2">Anda sedang online</h5>
										</div>
									</div>
									<div class="card-body">
										<table class="table mt-5" id="table2">
											<thead>
												<tr class='bg-primary text-white table-borderless'>
													<th>No</th>
													<th>Nama</th>
													<th>Username</th>
													<th>Level</th>
													<th>Active</th>
													<th>Aksi</th>
												</tr>
											</thead>
											<tbody>
												<?php $no=1; foreach($user as $u):?>
													<?php if($u['nama'] == $admin):?>
														<tr>
															<td width="15"><?= $no++?></td>
															<td><?= $u['nama']?></td>
															<td><?= $u['username']?></td>
															<td>
																<div class="badge badge-success">Online</div>
															</td>
															<td>
																<div class="badge badge-success">Online</div>
															</td>
															<td>
																<div class="badge badge-success">Online</div>
															</td>
														</tr>
												<?php else:?>
												<tr>
													<td width="15"><?= $no++?></td>
													<td><?= $u['nama']?></td>
													<td><?= $u['username']?></td>
													<td width="50">
														<?php if( $u['level'] == 1):?>
															<div class="badge badge-primary">Admin</div>
														<?php elseif($u['level'] == 2):?>
															<div class="badge badge-secondary">Dokter</div>
														<?php else:?>
															<div class="badge badge-info">Nakes</div>
														<?php endif;?>
													</td>
													<td width="50">
														<a href="<?= base_url('admin/actUser/'.$u['id']);?>"

														<?php if ($u['active']==1):?>
															class="badge badge-success" 
														<?php else :?>
															class="badge badge-danger"
														<?php endif;?>
															>

															<?php if ($u['active']==1):?>
																Aktif
															<?php else :?>
																Tidak
															<?php endif;?>

														</a>
														
													</td>
													<td class="dropdown" width="50">
														<a class="dropdown-toggle badge-primary badge py-auto" href="#" id="navbarDropdown" role="button" data-toggle="dropdown">Aksi</a>

														<div class="dropdown-menu">
															<li class="dropdown-item" href="#"><a href="javascript:;" onclick="admUbah(<?= $u['id']?>)" data-id="" class="badge badge-primary">Ubah</a></li>
															<li class="dropdown-item" href="#"><a href="javascript:void(0);" onclick="admHapus(<?= $u['id']?>)" class="badge badge-danger btnHapus">Hapus</a></li>
															<li class="dropdown-item"><a href="#javascript:void(0);" onclick="admDetail(<?= $u['id']?>)"  class="badge badge-secondary btnHapus">Detail</a></li>
														</div>
													</td>
												</tr>
												<?php endif;?>
												<?php endforeach;?>
											</tbody>
										</table>
									</div>
								</div>
							</div>
							
						</div>
					</div>
				</div>
				<div class="modal fade" id="addUser" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
					<div class="modal-dialog" style="margin-top: 100px; height: 500px !important;">
						<div class="modal-content">
						<div class="modal-header">
							<h3 class="modal-title" id="staticBackdropLabel">Tambah user</h3>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body">
							<div class="container-fluid">
								<div class="row">
									<div class="col-12 mx-auto">
										<form action="<?= base_url('admin/addUser');?>" method="post">
											<label for="" class="mt-2">Nama lengkap</label>
											<input autocomplete="off" required type="text" class="form-control mt-2" name="nama" placeholder="Masukan nama lengkap user!" value="<?= set_value('nama');?>">
											<?= form_error('nama', '<small class="text-danger pl-3">', '</small>'); ?>
											<label for="" class="mt-3">Username</label>
											<input autocomplete="off" required type="text" class="form-control mt-2" name="username" placeholder="Masukan username untuk user!" value="<?= set_value('username');?>">
											<?= form_error('username', '<small class="text-danger pl-3">', '</small>'); ?>
											<label for=""  class="mt-3">Password</label>
											<input autocomplete="off" required type="text" class="form-control mt-2" name="password" placeholder="Masukan password untuk user!" value="<?= set_value('password');?>">
											<?= form_error('password', '<small class="text-danger pl-3">', '</small>'); ?>
											<label for=""  class="mt-3">Level user</label>
											<select required class="form-control mb-3 mt-2" name="level" id="level" value="<?= set_value('level');?>">
												<option value="0">Silakan pilih</option>
												<option value="1">Admin</option>
												<option value="2">Dokter</option>
												<option value="3">Nakes</option>
											</select>
											<span class="label"></span>
											<?= form_error('level');?>
									</div>
								</div>
							</div>
							
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
							<button type="button" class="btn tmbUser btn-primary">Tambah</button>
						</form>
						</div>
						</div>
					</div>
				</div>
				<!-- Akhir modal -->

				<!-- Modal tambah user-->
				<div class="modal fade" id="editUser" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
					<div class="modal-dialog" style="margin-top: 100px;">
						<div class="modal-content">
						<div class="modal-header">
							<h3 class="modal-title" id="staticBackdropLabel">Edit user</h3>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body">
							<div class="container">
								<div class="row">
									<div class="col-12 mx-auto">
										<form action="<?= base_url('admin/editUser');?>" method="post">
											<?= form_error('nama', '<small class="text-danger pl-3">', '</small>'); ?>
											<label for="" class="mt-2">Username</label>
											<input autocomplete="off" type="hidden" class="form-control mt-2" id="editId" name="id">
											<input autocomplete="off" required type="text" class="form-control mt-2" id="editUm" name="username" value="<?= set_value('username');?>">
											<?= form_error('username', '<small class="text-danger pl-3">', '</small>'); ?>
											<label for=""  class="mt-3">Level user</label>
											<select class="form-control mb-3 mt-2" name="level" id="editLevel" value="<?= set_value('level');?>">
												<option value="1">Admin</option>
												<option value="2">Dokter</option>
												<option value="3">Nakes</option>
											</select>
											<?= form_error('level');?>
									</div>
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
							<button type="submit" class="btn btn-primary">Ubah</button>
						</form>
						</div>
						</div>
					</div>
				</div>
				<!-- Akhir modal -->

			</div>

			<footer class="footer">
				<div class="container-fluid">
					<div class="copyright ml-auto mx-auto my-auto">
						&copy; 2024 TUGAS BK
						<svg class="bi bi-suit-heart-fill" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#f20202" viewBox="0 0 16 16">
						<path d="M4 1c2.21 0 4 1.755 4 3.92C8 2.755 9.79 1 12 1s4 1.755 4 3.92c0 3.263-3.234 4.414-7.608 9.608a.513.513 0 0 1-.784 0C3.234 9.334 0 8.183 0 4.92 0 2.755 1.79 1 4 1z"></path>
						</svg>&nbsp;by&nbsp;<a class="text-black" href="#" target="_blank"><b>Muhammad Nur Fauzi</b>
					</div>				
				</div>
			</footer>
		</div>
		<!-- ===============================================-->
		<!--    End of Main menu -->
		<!-- ===============================================-->
	
		
	</div>
	<!-- ===============================================-->
	<!--    Div penutup -->
	<!-- ===============================================-->