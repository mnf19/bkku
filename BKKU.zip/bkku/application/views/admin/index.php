		<!-- ===============================================-->
		<!--    Main menu -->
		<!-- ===============================================-->
		<div class="main-panel">

			<div class="content">
				<div class="panel-header bg-primary-gradient">
					<div class="page-inner py-5">
						<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
							<div>
								<h2 class="text-white pb-2 fw-bold"> <i class="fas fa-user-cog mr-2"></i> Selamat Datang Admin!</h2>
								<h5 class="text-white op-7 mb-2">Admin dashboard sistem klinik</h5>
							</div>
						</div>
					</div>
				</div>

				<div class="page-inner mt--5">
					<div class="row mt--2">
						<div class="col-md-4">
							<div class="card shadow card-dark bg-danger-gradient">
								<div class="card-body bubble-shadow">
									<h1><?= $this->db->get('user')->num_rows();
									?> orang</h1>
									<h5 class="op-8">Total User</h5>
									<div class="pull-right">
										<h3 class="fw-bold op-8">User</h3>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="card shadow card-dark bg-success-gradient">
								<div class="card-body bubble-shadow">
									<?php $pengunjung = $this->db->query("SELECT * FROM statistik")->num_rows();?>
									<h1><?= $pengunjung;?> orang</h1>
									<h5 class="op-8">Total Pengunjung</h5>
									<div class="pull-right">
										<h3 class="fw-bold op-8">Visitor</h3>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-4">
							<div class="card shadow card-dark bg-info-gradient">
								<div class="card-body bubble-shadow">
									<h1><?= $this->db->get('pasien')->num_rows();
									?> orang</h1>
									<h5 class="op-8">Total Pendaftar</h5>
									<div class="pull-right">
										<h3 class="fw-bold op-8">Pasien</h3>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row mt--2">
						<div class="col-6">
							<div class="card" style="height:405px;">
								<div class="card-header">
									<div class="card-title">Total Pengunjung Tahunan</div>
								</div>
								<div class="card-body">
									<h4>Data pengunjung website per tahun</h4> 
									<div class="mt-3 mb-3">
										<?php foreach($kunjungan as $k):?>
											<div class="row overflow-auto">
												<div class="col-2">
													<?= substr($k['tanggal'], 0, 4);?>
												</div>
												<div class="col">
													<div class="progress">
													<div class="progress-bar" role="progressbar" style="width: <?= $k['total'];?>%;" aria-valuenow="<?= $k['total'];?>" aria-valuemin="0" aria-valuemax="100"><?= $k['total'];?>%</div>
													</div>
												</div>
											</div>
										<?php endforeach;?>
									</div>
									Data akan bertambah setiap tahunnya sesuai dengan data visitor yang mengunjungi website.
								</div>
							</div>
						</div>
						<div class="col-6">
							<div class="card">
								<div class="card-header">
									<div class="card-title">Total Pendaftar</div>
								</div>
								<div class="card-body">
									<div class="chart-container">
										<canvas id="pieChart" style="width: 50%; height: 50%"></canvas>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row mt--2">
						<div class="col-12">
							<div class="card">
								<div class="card-header">
									<div class="card-title">Total Pengunjung</div>
								</div>
								<div class="card-body">
									<div>
										<div class="chart-container">
											<canvas id="barChart"></canvas>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<footer class="footer">
				<div class="container-fluid">
					<div class="copyright ml-auto mx-auto my-auto">
						&copy; 2024 TUGAS BK 
						<svg class="bi bi-suit-heart-fill" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#f20202" viewBox="0 0 16 16">
						<path d="M4 1c2.21 0 4 1.755 4 3.92C8 2.755 9.79 1 12 1s4 1.755 4 3.92c0 3.263-3.234 4.414-7.608 9.608a.513.513 0 0 1-.784 0C3.234 9.334 0 8.183 0 4.92 0 2.755 1.79 1 4 1z"></path>
						</svg>&nbsp;by&nbsp;<a class="text-black" href="#" target="_blank"><b>Muhammad Nur Fauzi</b>
					</div>				
				</div>
			</footer>
		</div>
		<!-- ===============================================-->
		<!--    End of Main menu -->
		<!-- ===============================================-->
		
	</div>
	<!-- ===============================================-->
	<!--    Div penutup -->
	<!-- ===============================================-->

	