<!--   Core JS Files   -->
<!--<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>-->
<script src="<?= base_url() ?>vendor/assets/js/core/jquery.3.2.1.min.js"></script>
<script src="<?= base_url() ?>vendor/assets/js/core/popper.min.js"></script>
<script src="<?= base_url() ?>vendor/assets/js/core/bootstrap.min.js"></script>

<!-- jQuery UI -->
<script src="<?= base_url() ?>vendor/assets/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js"></script>
<script src="<?= base_url() ?>vendor/assets/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js"></script>

<!-- jQuery Scrollbar -->
<script src="<?= base_url() ?>vendor/assets/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js"></script>


<!-- Chart JS -->
<script src="<?= base_url() ?>vendor/assets/js/plugin/chart.js/chart.min.js"></script>

<!-- jQuery Sparkline -->
<!--<script src="<?= base_url() ?>vendor/assets/js/plugin/jquery.sparkline/jquery.sparkline.min.js"></script>-->

<!-- Chart Circle -->
<!--<script src="<?= base_url() ?>vendor/assets/js/plugin/chart-circle/circles.min.js"></script>-->

<!-- Datatables -->
<script src="<?= base_url() ?>vendor/assets/js/plugin/datatables/datatables.min.js"></script>

<!-- Bootstrap Notify -->
<!--<script src="<?= base_url() ?>vendor/assets/js/plugin/bootstrap-notify/bootstrap-notify.min.js"></script>-->

<!-- jQuery Vector Maps -->
<!--<script src="<?= base_url() ?>vendor/assets/js/plugin/jqvmap/jquery.vmap.min.js"></script>-->
<!--<script src="<?= base_url() ?>vendor/assets/js/plugin/jqvmap/maps/jquery.vmap.world.js"></script>-->

<!-- Sweet Alert -->
<script src="<?= base_url() ?>vendor/assets/js/plugin/sweetalert/sweetalert2@11.js"></script>
<script src="<?= base_url() ?>vendor/assets/js/plugin/sweetalert/sweetalert.min.js"></script>
<!--<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>-->

<!-- AtlRmis JS -->
<script src="<?= base_url() ?>vendor/assets/js/atlantis.min.js"></script>

<!--<script src="<?= base_url() ?>vendor/assets/js/admin.js"></script>-->
<!--<script src="<?= base_url() ?>vendor/assets/js/nakes.js"></script>-->
<!-- Atlantis DEMO methods, don't include it in your project! -->
<!--<script src="<?= base_url() ?>vendor/assets/js/setting-demo.js"></script>
	<script src="<?= base_url() ?>vendor/assets/js/demo.js"></script>-->
<!-- Script fungsi Admin -->

<script>
	$(document).ready(function() {


		$("#bkk").click(function() {
			var isi = $(this).html();
			if (isi == 'Tambah') {
				$(this).html('Tutup');
			} else {
				$(this).html('Tambah');
			}
		});

		///// Tabel /////

		//Tabel Pesan
		$('#table1').DataTable({
			"dom": 'ftrip',
			"scrollY": true,
			"lengthMenu": [
				[3],
				[3]
			],
			"order": false
		});

		//Button ambil data pesan
		btnData = function(id) {
			$.ajax({
				type: "post",
				url: "<?= base_url('admin/getData') ?>",
				data: {
					id: id
				},
				dataType: "json",
				success: function(data) {
					$("#judul").val(data.judul);
					$("#isi").val(data.isi);
					$("#idPesan").val(data.id);
					$('#btnCancel').removeClass('d-md-none');
					$(".btnTmb").replaceWith(('<button type="button" class="btn btn-primary mt-3 ml-md-auto d-flex align-items-left btnUbah" onclick="btnUbah()">Ubah</button>'));
				}
			});
		}

		//Button ubah data pesan
		btnUbah = function() {
			var judul = $("#judul").val();
			var isi = $("#isi").val();
			var idPesan = $("#idPesan").val();

			$.ajax({
				type: "post",
				url: "<?= base_url('admin/ubahPesan') ?>",
				data: {
					judul: judul,
					isi: isi,
					id: idPesan
				},
				dataType: "json",
				success: function(response) {
					location.reload();
				}
			});
		}

		//Button reset/batal data pesan
		$("#btnReset").click(function() {
			$(".btnUbah").replaceWith(('<button type="button" class="btn btn-primary mt-3 ml-md-auto d-flex align-items-left btnTmb">Tambah</button>'));
		});

		//Button hapus data pesan
		btnHapus = function(id) {
			var id = id;
			swal({
				title: 'Hapus pesan!',
				text: "Anda yakin ingin menghapus pesan ini?",
				type: 'warning',
				buttons: {
					confirm: {
						text: 'Yakin!',
						className: 'btn btn-success'
					},
					cancel: {
						text: 'Batal',
						visible: true,
						className: 'btn btn-danger'
					}
				}
			}).then((Delete) => {
				if (Delete) {
					$.ajax({
						type: "post",
						url: "<?= base_url('admin/hapusPesan') ?>",
						data: {
							id: id
						},
						dataType: "json",
						success: function(response) {
							console.log(response);
						}
					});
					location.reload();

				} else {
					swal.close();
				}
			});
		}

		//Button awal data pesan
		btnAwal = function(id) {
			var id = id;
			swal({
				title: 'Awal pesan!',
				text: "Anda yakin mengatur pesan ini diawal?",
				type: 'warning',
				buttons: {
					confirm: {
						text: 'Yakin!',
						className: 'btn btn-success'
					},
					cancel: {
						text: 'Batal',
						visible: true,
						className: 'btn btn-danger'
					}
				}
			}).then((Delete) => {
				if (Delete) {
					$.ajax({
						type: "post",
						url: "<?= base_url('admin/awalPesan') ?>",
						data: {
							id: id
						},
						dataType: "dataType",
						success: function(response) {
							console.log(response);
							location.reload();
						}
					});
					location.reload();

				} else {
					swal.close();
				}
			});
		}
		///// Akhir tabel ///// 


		///// Jam buka /////

		//Form jam buka 1
		libur1 = function() {
			$("input[name=jam_1b]").val('');
			$("input[name=jam_1t]").val('');
		}

		//Form jam buka 2
		libur2 = function() {
			$("input[name=jam_2b]").val('');
			$("input[name=jam_2t]").val('');
		}

		//Form jam buka 3
		libur3 = function() {
			$("input[name=jam_3b]").val('');
			$("input[name=jam_3t]").val('');
		}

		///// Akhir jam buka /////


		//Tabel user
		$('#table2').DataTable();

		$("#buka").click(function() {
			$('#addUser').modal('show');
		});

		admUbah = function(id) {
			$('#editUser').modal('show');
			$.ajax({
				type: "post",
				url: "<?= base_url('admin/getDataUser'); ?>",
				data: {
					id: id
				},
				dataType: "json",
				success: function(data) {
					$("#editId").val(data.id);
					$("#editUm").val(data.username);
					$("#editLevel").val(data);
				}
			});
		}

		admHapus = function(id) {
			swal({
				title: 'Hapus user!',
				text: "Anda yakin ingin menghapus data user ini?",
				type: 'warning',
				buttons: {
					confirm: {
						text: 'Yakin!',
						className: 'btn btn-success'
					},
					cancel: {
						text: 'Batal',
						visible: true,
						className: 'btn btn-danger'
					}
				}
			}).then((Delete) => {
				if (Delete) {
					$.ajax({
						type: "post",
						url: "<?= base_url('admin/hpsUser') ?>",
						data: {
							id: id
						},
						dataType: "json",
						success: function(response) {
							console.log(response);
						}
					});
					location.reload();

				} else {
					swal.close();
				}
			});
		}

		admDetail = function(id) {
			$('#collapseExample').collapse('show');
			$.ajax({
				type: "post",
				url: "<?= base_url('admin/getDataUser'); ?>",
				data: {
					id: id
				},
				dataType: "json",
				success: function(data) {
					$("#detNama").html(data.nama);
					$("#detUsername").html(data.username);
					$("#detAlamat").html(data.alamat);
					$("#detNip").html(data.nip);
					$("#detJenkel").html(data.jenkel);
					$("#detTmp").html(data.tempat_lahir);
					var tgl = data.tgl_lahir;
					var date = tgl.split('-');
					var tanggal = date['2'] + '-' + date['1'] + '-' + date['0'];
					console.log(tanggal);
					$("#detLhr").html(tanggal);
					$("#detAgama").html(data.agama);
					$(".imgProfil").html('<img width="300" src="' + '<?= base_url() ?>' + 'assets/' + data.foto + '" class="rounded">');

					if (data.level == 1) {
						$("#detLevel").html('Level : <div class="badge badge-primary">Admin</div>');
					} else if (data.level == 2) {
						$("#detLevel").html('Level : <div class="badge badge-secondary">Dokter</div>');
					} else {
						$("#detLevel").html('Level : <div class="badge badge-info">Nakes</div>');
					}

					if (data.active == 1) {
						$("#detStatus").html('<div class="badge badge-success">Aktif</div>');
					} else {
						$("#detStatus").html('<div class="badge badge-danger">Tidak aktif</div>');
					}
				}
			});
		}

		function readURL(input) {
			if (input.files && input.files[0]) {
				var reader = new FileReader();
				reader.onload = function(e) {
					$('#previewHolder').attr('src', e.target.result);
				}
				reader.readAsDataURL(input.files[0]);
			} else {
				alert('select a file to see preview');
				$('#previewHolder').attr('src', '');
			}
		}

		$("#filePhoto").change(function() {
			readURL(this);
		});

		$("#formGnl").keyup(function() {
			$(".btnGnl").attr('type', 'submit');
			$(".btnGnl").removeClass('disabled');
		});

		$("#formJmb").keyup(function() {
			$(".btnJmb").attr('type', 'submit');
			$(".btnJmb").removeClass('disabled');
		});

		$("#formTng").keyup(function() {
			$(".btnTng").attr('type', 'submit');
			$(".btnTng").removeClass('disabled');
		});

		$("#formLyn").keyup(function() {
			$(".btnLyn").attr('type', 'submit');
			$(".btnLyn").removeClass('disabled');
		});

		$("#formAlm").keyup(function() {
			$(".btnAlm").attr('type', 'submit');
			$(".btnAlm").removeClass('disabled');
		});

		$("#formFt").keyup(function() {
			$(".btnFt").attr('type', 'submit');
			$(".btnFt").removeClass('disabled');
		});

		$("#formJb").keyup(function() {
			$(".btnJb").attr('type', 'submit');
			$(".btnJb").removeClass('disabled');
		});

		$("#formJb").change(function() {
			$(".btnJb").attr('type', 'submit');
			$(".btnJb").removeClass('disabled');
		});

		setTimeout(alerte, 8000);
		setTimeout(alertKu, 400);

		function alertKu() {
			$('#alert').animate({
				opacity: 1,
			}, 900);
		}

		function alerte() {
			$('#alert').animate({
				opacity: 0
			}, 900);
		}

		$(".tmbUser").click(function() {
			var isi = $("#level").val();
			if (isi == 0) {
				$('#level').addClass('is-invalid');
				$(".label").addClass('text-danger').html('Level belum dipilih!');
			} else {
				$(".tmbUser").attr('type', 'submit');
			}
		});

		var formKop = $('#formKop');
		$(formKop).keyup(function(e) {
			$('#btnKop').removeClass('disabled');
			$('#btnKop').removeAttr('type', 'button');
			$('#btnKop').Attr('type', 'submit');
		});

		$("#logo_kop").click(function(e) {
			e.preventDefault();
			$('#btnKop').removeClass('disabled');
			$('#btnKop').removeAttr('type', 'button');
			$('#btnKop').Attr('type', 'submit');
		});
	});
</script>
<!-- Akhir script -->

<!-- Script Fungsi Nakes -->
<script>
	$(document).ready(function() {
		function antrian() {
			$.ajax({
				type: "post",
				url: "<?= base_url('Nakes/getAnt') ?>",
				dataType: "json",
				success: function(data) {
					if (data.antrian != data.kuota) {
						$('#noAnt').val(data.antrian);
						//$('#noAnt').val(data.noAtr);

					} else {
						$('#noAnt').val('Antrian penuh');
					}
				}
			});
		}

		antrian();
		setInterval(() => {
			antrian();
		}, 3000);

		$("#formPsn").keyup(function() {
			var nama = $("#namaPsn").val();
			$("#krtNama").html(nama);
			var nik = $("#nikPsn").val();
			$("#krtNik").html(nik);
			var umur = $("#umurPsn").val();
			$("#krtUmur").html(umur + " tahun");
			var alamat = $("#alamatPsn").val();
			$("#krtAlamat").html(alamat);
		});

		$("#jenkelPsn").change(function() {
			var jenkel = $(this).val();
			$("#krtJenkel").html(jenkel);
		});

		var tablePsn = $('#tablen').DataTable({
			"responsive": true,
			"scrollY": true,
			"serverSide": true,
			"lengthMenu": [
				[5, 10, 25, 50],
				[5, 10, 25, 50]
			],
			"order": false,
			"ajax": {
				url: "<?= base_url('nakes/viewData'); ?>",
				type: "POST"
			}
		});

		var table = $('#tablen').DataTable();

		setInterval(() => {
			refresh();
		}, 10000);

		function refresh() {
			tablePsn.ajax.reload();
		}

		$(".btnReset").click(function(e) {
			e.preventDefault();
			$("#namaPsn").val('');
			$("#nikPsn").val('');
			$("#umurPsn").val('');
			$("#alamatPsn").val('');
			$("#krtNama").html('');
			$("#krtNik").html('');
			$("#krtUmur").html('' + " tahun");
			$("#krtAlamat").html('');
		});

		$(".tmbPsn").click(function(e) {
			e.preventDefault();

			const formPsn = $('#formPsn');
			if ($("#namaPsn").val() == '' | $("#nikPsn").val() == '' | $("#umurPsn").val() == '' | $("#alamatPsn").val() == '') {
				Swal.fire({
					position: 'top',
					background: 'rgb(255, 0, 0, 0.8)',
					backdrop: `
									rgba(0,0,0,0)
									left top
									no-repeat
								`,
					html: '<span style="color:white;">Data Belum lengkap!</span>',
					showConfirmButton: false,
					timer: 3000,
					width: '200px',
				});
			} else {
				$.ajax({
					type: "post",
					url: "<?= base_url('nakes/addPsn') ?>",
					data: formPsn.serialize(),
					dataType: "json",
					success: function(data) {
						console.log(data);
						var nama = data.nama;
						formPsn[0].reset();
						$("#krtNama").html('');
						$("#krtNik").html('');
						$("#krtUmur").html('' + " tahun");
						$("#krtAlamat").html('');
						//$("#krtJenkel").html(jenkel);
						Swal.fire({
							position: 'top',
							background: 'rgb(55, 206, 88, 0.8)',
							backdrop: `
									rgba(0,0,0,0)
									left top
									no-repeat
								`,
							html: '<span style="color:white;">Data Tersimpan!</span>',
							showConfirmButton: false,
							timer: 3000,
							width: '200px',
						});
						$("input[name=noRm]").attr('id', 'noRm');
						$(".krtRm").attr('id', 'krtRm');
						refresh();
						//noAnt();
						antrian();
					}
				});
			}
		});

		function noAnt() {
			$.ajax({
				type: "post",
				url: "<?= base_url('nakes/noAnt') ?>",
				dataType: "json",
				success: function(data) {
					console.log(data);
					//$('#noAnt').val(data.noAtr);
					$('#noRm').val(data.noRm);
					var isi = data.noRm;
					var rm = isi;
					console.log(rm);
					//$('.noAnt').html(data.noAtr);
					$('#krtRm').html(data.noRm);
				}
			});
		}
		waktu = () => {
			setInterval(() => {
				noAnt();
			}, 3000);
		}
		waktu();
		noAnt();

		psnEdit = function(id) {
			$('#editPsn').modal('show');
			$.ajax({
				type: "post",
				url: "<?= base_url('nakes/getPsn'); ?>",
				data: {
					id: id
				},
				dataType: "json",
				success: function(data) {
					console.log(data);
					console.log(data.noRm);
					$("#edtNamaPsn").val(data.nama);
					$("#edtNikPsn").val(data.nik);
					$("#edtUmurPsn").val(data.umur);
					$("#edtAlamatPsn").val(data.alamat);
					$("#edtJenkelPsn").val(data.jenkel);
					$("input[name=noRm]").val(data.noRm);
					$("#edtAnt").val(data.noAtr);
					$("#idPsn").val(data.id);
				}
			});
		}

		btnEdtPsn = () => {
			$('#editPsn').modal('hide');
			const formEdt = $('#formEdt');
			$.ajax({
				type: "post",
				url: "<?= base_url('nakes/edtPasien') ?>",
				data: formEdt.serialize(),
				dataType: "json",
				success: function(response) {
					console.log(response);
					refresh();
					Swal.fire({
						position: 'top',
						background: 'rgb(55, 206, 88, 0.8)',
						backdrop: `
									rgba(0,0,0,0)
									left top
									no-repeat
								`,
						html: '<span style="color:white;">Data diubah!</span>',
						showConfirmButton: false,
						timer: 3000,
						width: '200px',
					});
				}
			});
		}

		psnHapus = (id) => {
			swal({
				title: 'Hapus data pasien!',
				text: "Anda yakin ingin menghapus data pasien ini?",
				type: 'warning',
				buttons: {
					confirm: {
						text: 'Yakin!',
						className: 'btn btn-success'
					},
					cancel: {
						text: 'Batal',
						visible: true,
						className: 'btn btn-danger'
					}
				}
			}).then((Delete) => {
				if (Delete) {
					$.ajax({
						type: "post",
						url: "<?= base_url('nakes/hpsPasien') ?>",
						data: {
							id: id
						},
						dataType: "json",
						success: function(response) {
							console.log(response);
							refresh();
							Swal.fire({
								position: 'top',
								background: 'rgb(55, 206, 88, 0.8)',
								backdrop: `
										rgba(0,0,0,0)
										left top
										no-repeat
									`,
								html: '<span style="color:white;">Data dihapus!</span>',
								showConfirmButton: false,
								timer: 3000,
								width: '200px',
							});
						}
					});
					//location.reload();

				} else {
					swal.close();
				}
			});
		}

		psnDetail = (id) => {
			$('#detPsn').modal('show');
			$.ajax({
				type: "post",
				url: "<?= base_url('nakes/detPasien') ?>",
				data: {
					id: id
				},
				dataType: "json",
				success: function(data) {
					$(".detAnt").html(data.noAtr);
					$(".detRm").html(data.noRm);
					$(".detNamaPsn").html(data.nama);
					$(".detNikPsn").html(data.nik);
					$(".detUmurPsn").html(data.umur);
					$(".detAlamatPsn").html(data.alamat);
					$(".detTglPsn").html(data.tglPrk);
					$(".detJamPsn").html(data.jamPrk);
					$(".detUserPsn").html(data.user);
					$(".detJenkelPsn").html(data.jenkel);
					if (data.sts == 1) {
						$('.stsPsn').removeClass('badge-danger');
						$('.stsPsn').addClass('badge-success');
						$('.stsPsn').html('Sudah periksa');
					} else {
						$('.stsPsn').removeClass('badge-success');
						$('.stsPsn').addClass('badge-danger');
						$('.stsPsn').html('Belum periksa');
					}
				}
			});
		}

		psnDu = (id) => {
			$("#collapseExample").collapse('show');
			$("#bkk").html('Tutup');
			$.ajax({
				type: "post",
				url: "<?= base_url('nakes/getPsn') ?>",
				data: {
					id: id
				},
				dataType: "json",
				success: function(data) {
					console.log(data);
					$("#namaPsn").val(data.nama);
					$("#krtNama").html(data.nama);
					$("#nikPsn").val(data.nik);
					$("#krtNik").html(data.nik);
					$("#umurPsn").val(data.umur);
					$("#krtUmur").html(data.umur + " tahun");
					$("#alamatPsn").val(data.alamat);
					$("input[name=noRm]").removeAttr('id');
					$("input[name=noRm]").val(data.noRm);
					$("#krtAlamat").html(data.alamat);
					$(".krtRm").html(data.noRm);
					$(".krtRm").removeAttr('id');
					$(".psnBr").html("Daftar Pasien Lama");
					$(".btnBatal").html("Batal");
				}
			});
		}

		$(".btnBatal").click(function(e) {
			e.preventDefault();
			$(".psnBr").html("Daftar Pasien Baru");
			$(this).html('Reset');
			$("input[name=noRm]").attr('id', 'noRm');
			$(".krtRm").attr('id', 'krtRm');
			noAnt();
		});



	});
</script>
<!-- Akhir script -->

<script>
	$(document).ready(function() {
		function muat() {
			tables.api().ajax.reload();
		}

		setInterval(() => {
			muat();
		}, 10000);
		sts = (id) => {
			$.ajax({
				type: "post",
				url: "<?= base_url('dokter/getSts') ?>",
				data: {
					id: id
				},
				dataType: "json",
				success: function(response) {
					console.log(response);
					muat();
					Swal.fire({
						position: 'top',
						background: 'rgb(55, 206, 88, 0.8)',
						backdrop: `
						rgba(0,0,0,0)
						left top
						no-repeat
					`,
						html: '<span style="color:white;">Status berhasil diubah!</span>',
						showConfirmButton: false,
						timer: 1000,
						width: '200px',
					});
				}
			});
		}

		var tables = $('#tableo').dataTable({
			"responsive": true,
			"scrollY": true,
			"lengthMenu": [
				[5, 10, 25, 50],
				[5, 10, 25, 50]
			],
			"order": false,
			"ajax": '<?= base_url('dokter/lihatData') ?>',
			"columns": [{
					"data": "noAtr"
				},
				{
					"data": "noRm"
				},
				{
					"data": "nik"
				},
				{
					"data": "nama"
				},
				{
					"data": "alamat"
				},
				{
					"mData": null,
					"title": "Status",
					"sortable": false,
					"render": function(data) {
						let btn = '';
						if (data.sts != 1) {
							btn += "<a href='#' class='badge badge-danger' onclick='sts(" + data.id + ")'>Belum</i></a>";
						} else {
							btn += "<a href='#' class='badge badge-success' onclick='sts(" + data.id + ")'>Sudah</i></a>";
						}
						return btn;
					}
				},
				{
					"mData": null,
					"title": "Aksi",
					"sortable": false,
					"render": function(data) {
						btn = `<td class="dropdown" width="50">
									<a class="dropdown-toggle badge-primary badge py-auto" href="#" id="navbarDropdown" role="button" data-toggle="dropdown">Aksi</a>
									<div class="dropdown-menu">
										<li class="dropdown-item" href="#">
											<a href="javascript:void(0);" class="badge badge-success " onclick="psnDet(` + data.id + `)">Detail</a>
										</li>
										<li class="dropdown-item" href="#">
											<a href="<?= base_url('dokter/rekam') ?>" data-toggle="collapse" class="badge badge-secondary tmbPsn" onclick="rekam(` + data.noRm + `)">Rekam medis</a>
										</li>
									</div>
								</td>`;
						return btn;
					}
				},
			]
		});

		function ulang() {
			$('#tablep').dataTable();
		}

		var tabel = $('#tablep').DataTable();

		rekam = function(noRm) {
			$('#rekam').collapse('show');
			tabel.destroy();
			tabel = $('#tablep').DataTable({
				"responsive": true,
				"scrollY": true,
				"lengthMenu": [
					[5, 10, 25, 50],
					[5, 10, 25, 50]
				],
				"order": false,
				"ajax": '<?= base_url() ?>dokter/rmPasien/' + noRm,
				"columns": [{
						"data": "tanggal"
					},
					{
						"data": "keluhan"
					},
					{
						"data": "periksa"
					},
					{
						"data": "diagnosa"
					},
					{
						"data": "rencana"
					},
					{
						"mData": null,
						"title": "Aksi",
						"sortable": false,
						"render": function(data) {
							btn = `<td class="dropdown" width="50">
										<a class="dropdown-toggle badge-primary badge py-auto" href="#" id="navbarDropdown" role="button" data-toggle="dropdown">Aksi</a>
										<div class="dropdown-menu">
											<li class="dropdown-item" href="#">
												<a href="javascript:void(0);" class="badge badge-success " onclick="getRm(` + data.id + `)">Edit</a>
											</li>
											<li class="dropdown-item" href="#">
												<a href="javascript:void(0);" data-toggle="collapse" class="badge badge-danger tmbPsn" onclick="hpsRm(` + data.id + `)">Hapus</a>
											</li>
										</div>
									</td>`;
							return btn;
						}
					},
				]
			});

			$.ajax({
				type: "post",
				url: "<?= base_url("dokter/getPsn") ?>",
				data: {
					noRm: noRm
				},
				dataType: "json",
				success: function(data) {
					console.log(data);
					$(".rmNama").html(data.nama);
					$(".rmUmur").html(data.umur);
					$(".rmNik").html(data.nik);
					$(".rmAlamat").html(data.alamat);
					$(".rmNoRm").html(data.noRm);
					$("#rmNoRm").val(data.noRm);
					$("input[name=ctkRm]").val(data.noRm);
					$(".rmSts").html(data.sts);
				}
			});

		}

		psnDet = function(id) {
			console.log(id);
			$('#psnDet').modal('show');
			$.ajax({
				type: "post",
				url: "<?= base_url('dokter/detPasien') ?>",
				data: {
					id: id
				},
				dataType: "json",
				success: function(data) {
					//console.log(data);
					$(".psnAtr").html(data.noAtr);
					$(".psnRm").html(data.noRm);
					$(".psnNama").html(data.nama);
					$(".psnNik").html(data.nik);
					$(".psnUmur").html(data.umur);
					$(".psnAlamat").html(data.alamat);
					$(".psnTgl").html(data.tglPrk);
					$(".psnJam").html(data.jamPrk);
					$(".psnUser").html(data.user);
					$(".psnJenkel").html(data.jenkel);
					if (data.sts == 1) {
						$('.psnSts').removeClass('badge-danger');
						$('.psnSts').addClass('badge-success');
						$('.psnSts').html('Sudah periksa');
					} else {
						$('.psnSts').removeClass('badge-success');
						$('.psnSts').addClass('badge-danger');
						$('.psnSts').html('Belum periksa');
					}
				}
			});
		}

		$(".ttpRm").click(function(e) {
			$('#rekam').collapse('hide');
		});

		$(".tmbRm").click(function(e) {
			e.preventDefault();
			$('.formTmbRm').collapse('toggle');
			var elm = $(this).html();
			if (elm == "Tambah") {
				$(this).html('Tutup');
				$(this).removeClass('btn-primary');
				$(this).addClass('btn-danger');
			} else {
				$(this).html('Tambah');
				$(this).removeClass('btn-danger');
				$(this).addClass('btn-primary');
			}
		});

		$(".tmbSub").click(function() {
			if ($("#keluhan").val() == '' | $("#periksa").val() == '' | $("#diagnosa").val() == '' | $("#rencana").val() == '') {
				Swal.fire({
					position: 'top',
					background: 'rgb(255, 0, 0, 0.8)',
					backdrop: `
						rgba(0,0,0,0)
						left top
						no-repeat
					`,
					html: '<span style="color:white;">Data belum lengkap!</span>',
					showConfirmButton: false,
					timer: 1000,
					width: '200px',
				});
			} else {

				var formRmPsn = $('#formRmPsn');
				$.ajax({
					type: "post",
					url: "<?= base_url('dokter/tmbRm'); ?>",
					data: formRmPsn.serialize(),
					dataType: "json",
					success: function(response) {
						console.log(response);
						formRmPsn[0].reset();
						tabel.ajax.reload();
						Swal.fire({
							position: 'top',
							background: 'rgb(55, 206, 88, 0.8)',
							backdrop: `
								rgba(0,0,0,0)
								left top
								no-repeat
							`,
							html: '<span style="color:white;">Data berhasil ditambahkan!</span>',
							showConfirmButton: false,
							timer: 1000,
							width: '200px',
						});
					}
				});
			}

		});

		getRm = (id) => {
			console.log(id);
			$('.formTmbRm').collapse('show');
			//var elm = $('.tmbRm').html();
			$('.tmbRm').html('Tutup');
			$('.tmbRm').removeClass('btn-primary');
			$('.tmbRm').addClass('btn-danger');
			$.ajax({
				type: "post",
				url: "<?= base_url('dokter/getRm') ?>",
				data: {
					id: id
				},
				dataType: "json",
				success: function(data) {
					$("#keluhan").val(data.keluhan);
					$("#periksa").val(data.periksa);
					$("#diagnosa").val(data.diagnosa);
					$("#rencana").val(data.rencana);
					$("#idRm").val(data.id);
					//$("#tmbEditRm").html("Edit");
					$("#tmbSub").addClass("d-none");
					$("#tmbReset").addClass("d-none");
					$(".tmbEditRm").removeClass("d-none");
					$(".btnBatal").removeClass("d-none");
				}
			});
		}

		$("button[id=tmbEditRm]").click(function() {
			if ($("#keluhan").val() == '' | $("#periksa").val() == '' | $("#diagnosa").val() == '' | $("#rencana").val() == '') {
				Swal.fire({
					position: 'top',
					background: 'rgb(255, 0, 0, 0.8)',
					backdrop: `
						rgba(0,0,0,0)
						left top
						no-repeat
					`,
					html: '<span style="color:white;">Data belum lengkap!</span>',
					showConfirmButton: false,
					timer: 1000,
					width: '200px',
				});
			} else {
				var formRmPsn = $('#formRmPsn');
				$.ajax({
					type: "post",
					url: "<?= base_url('dokter/editRm') ?>",
					data: formRmPsn.serialize(),
					dataType: "json",
					success: function(response) {
						console.log(response);
						$("#tmbEditRm").addClass("d-none");
						$("#tmbSub").removeClass("d-none");
						$("#btnBatal").addClass('d-none');
						$("#tmbReset").removeClass("d-none");
						formRmPsn[0].reset();
						tabel.ajax.reload();
						Swal.fire({
							position: 'top',
							background: 'rgb(55, 206, 88, 0.8)',
							backdrop: `
									rgba(0,0,0,0)
									left top
									no-repeat
								`,
							html: '<span style="color:white;">Data berhasil diubah!</span>',
							showConfirmButton: false,
							timer: 1000,
							width: '200px',
						});
					}
				});
			}
		});

		$(".btnBatal").click(function() {
			$("#keluhan").val('');
			$("#periksa").val('');
			$("#diagnosa").val('');
			$("#rencana").val('');
			$("#btnBatal").addClass("d-none");
			$("#tmbReset").removeClass("d-none");
			$("#tmbEditRm").addClass("d-none");
			$("#tmbSub").removeClass("d-none");
		});

		hpsRm = (id) => {
			swal({
				title: 'Hapus pesan!',
				text: "Anda yakin ingin menghapus data ini?",
				type: 'warning',
				buttons: {
					confirm: {
						text: 'Yakin!',
						className: 'btn btn-success'
					},
					cancel: {
						text: 'Batal',
						visible: true,
						className: 'btn btn-danger'
					}
				}
			}).then((Delete) => {
				if (Delete) {
					$.ajax({
						type: "post",
						url: "<?= base_url('dokter/hpsRm') ?>",
						data: {
							id: id
						},
						dataType: "json",
						success: function(response) {
							console.log(response);
							tabel.ajax.reload();
							Swal.fire({
								position: 'top',
								background: 'rgb(55, 206, 88, 0.8)',
								backdrop: `
									rgba(0,0,0,0)
									left top
									no-repeat
								`,
								html: '<span style="color:white;">Data berhasil dihapus!</span>',
								showConfirmButton: false,
								timer: 1000,
								width: '200px',
							});
						}
					});
					//location.reload();

				} else {
					swal.close();
				}
			});
		}

		setInterval(() => {
			ttlPeriksa();
		}, 1000);

		function ttlPeriksa() {
			$.ajax({
				type: "get",
				url: "<?= base_url('dokter/stsPeriksa') ?>",
				dataType: "json",
				success: function(data) {
					$("#sudah").html(data.sudah + " pasien");
					$("#belum").html(data.belum + " pasien");
				}
			});
		}

		var barChart = document.getElementById('barChart').getContext('2d');

		var myBarChart = new Chart(barChart, {
			type: 'bar',
			data: {
				labels: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
				datasets: [{
					label: "Visitor",
					backgroundColor: 'rgb(23, 125, 255)',
					borderColor: 'rgb(23, 125, 255)',
					data: [3, 2, 9, 5, 4, 6, 4, 6, 7, 8, 7, 4],
				}],
			},
			options: {
				responsive: true,
				maintainAspectRatio: false,
				scales: {
					yAxes: [{
						ticks: {
							beginAtZero: true
						}
					}]
				},
			}
		});

	});
</script>
</body>

</html>