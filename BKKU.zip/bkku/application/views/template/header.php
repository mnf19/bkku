<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title><?= $title['judul_web'];?></title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
	<link rel="icon" href="<?= base_url()?>vendor/assets/img/icon.png" type="image/x-icon"/>

	<!-- Fonts and icons -->
	<script src="<?= base_url()?>vendor/assets/js/plugin/webfont/webfont.min.js"></script>
	<script>
		WebFont.load({
			google: {"families":["Lato:300,400,700,900"]},
			custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['<?= base_url()?>vendor/assets/css/fonts.min.css']},
			active: function() {
				sessionStorage.fonts = true;
			}
		});
	</script>
	<style>
		.nav-item .active {
			/*background: #1572E8 !important;*/
			background: -webkit-linear-gradient(legacy-direction(-45deg), #06418E, #1572E8) !important;
			background: linear-gradient(-45deg, #06418E, #1572E8) !important;
		}
		#alert{
			transform:translateY(-39px);
			border-radius:5px; 
			opacity:0;
		}
		#tablen tr td{
			height:40px !important;
		}
		#tableo tr td{
			height:40px !important;
		}

		.krtObat{
			background:#FEF173 !important;
			font-family:  Times, 'Times New Roman', serif !important;
		}

		.kop{
			font-family:  Times, 'Times New Roman' !important;
			border:1px solid black !important;
			color:black;
			margin:0px 30px 0px 30px !important;
		}

		#tablerm tr td{
			padding:0px !important;
			height:40px !important;
			border: 0px !important;
			color:black; 
			font-family:  Times, 'Times New Roman';
			font-size: 16px;
			text-transform:uppercase;
			/*margin: 30px 0px 0px 30px !important;*/
		}

		#tablerm{
			margin: 0px 30px 0px 30px;
		}

		#tablerm tr #nat{
			width:130px !important;
		}

		#tablerm tr #nut{
			width:20px !important;
		}

		#tableRM tr td{
			/*border:1px solid black !important;*/
			padding: 0px 1px !important;
		}

		#medis tr td{
			text-transform: uppercase;
			font-size:16px;
			font-weight:bold;
			padding-right: 10px;
		}

		#mdlRm .modal-dialog{
			width: 900px !important;
		}
	</style>

	<!-- CSS Files -->
	<link rel="stylesheet" href="<?= base_url()?>vendor/assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="<?= base_url()?>vendor/assets/css/atlantis.min.css">
	
	<!-- CSS Just for demo purpose, don't include it in your project -->
	<!--<link rel="stylesheet" href="<?= base_url()?>vendor/assets/css/demo.css">-->
</head>
<body>