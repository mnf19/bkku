<!DOCTYPE html>
<html lang="en-US" dir="ltr">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="<?= base_url()?>vendor/assets/img/icon.png" type="image/x-icon"/>


    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
    <title><?= $title['judul_web'];?></title>


    <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <!--<link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">-->
    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link href="<?= base_url()?>home/assets/css/theme.css" rel="stylesheet"/>
    <link href="<?= base_url()?>home/assets/fonts/font.css" rel="stylesheet"/>
    <link href="<?= base_url()?>home/assets/css/animate.min.css" rel="stylesheet"/>
    <!-- ===============================================-->
    <!--    End of Stylesheets-->
    <!-- ===============================================-->

    <style>
      .btnDaftar{
        margin-right: -30px !important;
      }
      .btnReset{
        margin-right: 10px !important;
      }

      #jumboPB{
        height: 740px !important;
      }

      .kosong{
        margin:190px 0px 0px 0px;
        font-size:150px;
        color:white;
      }
    </style>

  </head>


  <body class="bg-primary-gradient">


    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    <main class="main" id="top">


      <!-- ===============================================-->
      <!--    Navbar menu -->
      <!-- ===============================================-->
      <nav class="navbar  navbar-dark fixed-top py-1 navPB">
        <div class="container">
          <!--<a class="navbar-brand text-white d-flex align-items-center fw-bold fs-4" href="#">
          Klinik</a>-->
          <!--<a href="index.html" class="btn btn-outline-light border-0 mt-2 fs-1" >Info</a>-->
          <!--<button type="submit" class="btn btn-outline-light btnDaftar mt-3">Download</button>-->
        </div>
      </nav>
      <!-- ===============================================-->
      <!--    Akhir navbar -->
      <!-- ===============================================-->


      <!-- ===============================================-->
      <!--    Jumbotron -->
      <!-- ===============================================-->
      <section class="py-0" id="jumboPB" >
        
        <div class="bg-holder" style="background-image:url(<?= base_url()?>home/assets/img/illustrations/dot.png);background-position:left;background-size:auto;margin-top:-105px;">
        </div>

        <div class="container position-relative">
          <div class="row align-items-center">
            <div class="col-md-6 col-lg-6 daftar mx-auto">
            
              <div class="container">
                <div class="row">
                  <div class="col-12 text-center">
                    <div class="kosong text-center py-auto">404</div>
                    <h4 class="text-white fw-bold">NOT FOUND</h4>
                    <!--<p class="text-white mt-2">Silakan "<i>Download</i>" terlebih dahulu kartu diatas sebelum keluar dari aplikasi ini!</p>-->
                    <a href="#javascsript:void(0);" onclick="goBack()" class="btn btn-outline-light btnSelesai mt-1 ">Kembali</a>
                    <!--<button type="submit" class="btn btn-outline-light btnDownload mt-1">Download</button>-->
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!--<div class="text-center mt-4 pb-3">
                <p class="mb-0 text-white">&copy; 2021 Created with 
                  <svg class="bi bi-suit-heart-fill" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#f20202" viewBox="0 0 16 16">
                    <path d="M4 1c2.21 0 4 1.755 4 3.92C8 2.755 9.79 1 12 1s4 1.755 4 3.92c0 3.263-3.234 4.414-7.608 9.608a.513.513 0 0 1-.784 0C3.234 9.334 0 8.183 0 4.92 0 2.755 1.79 1 4 1z"></path>
                  </svg>&nbsp;by&nbsp;<a class="text-black" href="#" target="_blank"><b>M. Fila Shaufiq</b></a>
                </p>
              </div>-->
      </section>
      <!-- ===============================================-->
      <!--    Akhir jumbotron -->
      <!-- ===============================================-->


    </main>
    <!-- ===============================================-->
    <!--    End of Main Content-->
    <!-- ===============================================-->


    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="<?= base_url()?>home/assets/js/jquery-3.6.0.min.js"></script>
    <script src="<?= base_url()?>home/vendors/@popperjs/popper.min.js"></script>
    <script src="<?= base_url()?>home/vendors/bootstrap/bootstrap.min.js"></script>
    <script src="<?= base_url()?>home/vendors/is/is.min.js"></script>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
    <script src="<?= base_url()?>home/assets/js/theme.js"></script>
    <!-- ===============================================-->
    <!--    End of JavaScripts-->
    <!-- ===============================================-->
    <script>
      $(document).ready(function () {
        $('.btnDownload').click(function () { 
          $(this).addClass('d-none');
          $('.btnSelesai').removeClass('d-none');
        });

        goBack = () =>{
          console.log('ok');
          window.history.back();
        }
      });
    </script>

  </body>

</html>