<!DOCTYPE html>
<html lang="en"><head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title></title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />

	<!-- Style -->
	<style>
		.card{
			background: #FEF173;
			border-radius: 10px !important;
			width: 550px;
			margin:auto;
			min-height: 450px;
		}
		.judul{
			border: 2px solid black;
			font-weight: bold;
			margin: 25px 20px 0px 20px ;
			padding: 5px 0px;
			text-align: center;
		}
		.tanggal{
			text-align:right; 
			padding-right: 30px;
			font-size: 12px;
		}
		#pasien{
			margin-left: 20px;
			transform:translateY(-25px);
		}
		table tr td{
			padding: 10px 0px 10px 0px;
			text-transform: uppercase;
		}
		.bawah{
			margin-bottom: 30px;
		}
	</style>
	<!-- Akhir -->

</head><body>
	<div class="card" style="border-radius: 20px !important;">
		<h3 class="judul">KARTU ANTRIAN</h3>
		<p class="tanggal"><?= $tglPrk;?></p>
		<table id="pasien" width="100" border="0">
			<tr>
				<td>NO ANTRIAN</td>
				<td width="10">:</td>
				<td width='10'><b><?= $noAtr;?></b></td>
			</tr>
			<tr>
				<td>NO RM</td>
				<td>:</td>
				<td><?= $noRm;?></td>
			</tr>
			<tr>
				<td>NIK</td>
				<td>:</td>
				<td><?= $nik;?></td>
			</tr>
			<tr>
				<td>NAMA</td>
				<td>:</td>
				<td width="250"><?= $nama;?></td>
			</tr>
			<tr>
				<td>UMUR</td>
				<td>:</td>
				<td><?= $umur;?></td>
			</tr>
			<tr>
				<td width="100">JENIS KELAMIN</td>
				<td>:</td>
				<td><?= $jenkel;?></td>
			</tr>
			<tr>
				<td>ALAMAT</td>
				<td>:</td>
				<td width="250"><?= $alamat;?></td>
			</tr>
		</table>
		<h4 class="judul bawah"><i><b>Bila berobat</b>, mohon kartu ini dibawa!</i></h4>
	</div>
		<footer>
			<h6 style="position: fixed; bottom:0px; left: 12px;">Developed by Muhammad Nur Fauzi</h6>
		</footer>
</body></html>
