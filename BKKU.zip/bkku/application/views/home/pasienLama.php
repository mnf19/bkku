<!DOCTYPE html>
<html lang="en-US" dir="ltr">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="<?= base_url()?>vendor/assets/img/icon.png" type="image/x-icon"/>


    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
    <title><?= $title['judul_web'];?></title>


    <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <!--<link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">-->
    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link href="<?= base_url()?>home/assets/css/theme.css" rel="stylesheet"/>
    <link href="<?= base_url()?>home/assets/fonts/font.css" rel="stylesheet"/>
    <link href="<?= base_url()?>home/assets/css/animate.min.css" rel="stylesheet"/>
    <!-- ===============================================-->
    <!--    End of Stylesheets-->
    <!-- ===============================================-->

    <style>
      .pageDaftar{
        margin-top: 70px;
        margin-bottom: 50px;
      }
      .btnDaftar{
        margin-right: -30px !important;
      }
      .btnReset{
        margin-right: 10px !important;
      }

      #jumboPB{
        height: 950px !important;
      }
    </style>

  </head>


  <body class="bg-primary-gradient">


    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    <main class="main" id="top">


      <!-- ===============================================-->
      <!--    Navbar menu -->
      <!-- ===============================================-->
      <nav class="navbar  navbar-dark fixed-top py-1 navPB animate__animated animate__fadeInDown">
        <div class="container">
          <a class="navbar-brand text-white d-flex align-items-center fw-bold fs-1" href="<?= base_url();?>">
          <span class="mt-3" style="margin-left:-15px;">&laquo; kembali</span></a>
          <!--<a href="" class="btn btn-outline-light border-0" >kembali</a>-->
        </div>
      </nav>
      <!-- ===============================================-->
      <!--    Akhir navbar -->
      <!-- ===============================================-->


      <!-- ===============================================-->
      <!--    Jumbotron -->
      <!-- ===============================================-->
      <section class="py-0  mb-3" style="background-attachment: fixed; height: 745px;" id="jumboPB" >
        
        <div class="bg-holder" style="background-image:url(<?= base_url()?>home/assets/img/illustrations/dot.png);background-position:left;background-size:auto;margin-top:-105px;">
        </div>

        <div class="container position-relative">
          <div class="row align-items-center">
            <div class="col-md-6 col-lg-6 daftar mx-auto">
              <div class="card pageDaftar animate__animated animate__fadeIn  animate__delay-1s">
                <div class="card-body">
                  <h5 class="card-title text-center">Pasien lama</h5>
                  <hr>
                  <form action="<?= base_url('home/psnLm');?>" method="post" id="formData">
                    <div class="alert d-none"></div>
                    <div class="form-group">
                      <label>Cari data anda!</label>
                      <div class="row ">
                        <div class="col-9">
                          <input type="text" class="form-control mb-3" id="keyword" placeholder="Cari dengan no RM / NIK" name="keyword" required>
                        </div>
                        <div class="col-3">
                          <!--<label>&nbsp;</label>-->
                          <a href="#" name="cari" class="btn btn-primary mb-3 px-3" id="cari">cari</a>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-4">
                          <label>No antrian</label>
                          <input type="text" readonly  name="noAtr" class="form-control mb-3" id="noAtr" value="">
                        </div>
                        <div class="col-7">
                          <label>No RM</label>
                          <input type="text" readonly name="noRm" class="form-control mb-3" id="noRm" placeholder="No RM anda!">
                        </div>
                      </div>
                      <label>NIK</label>
                      <input type="text" name="nik" readonly class="form-control mb-3" id="nik" placeholder="NIK anda!">
                      <label>Nama lengkap</label>
                      <input type="text" name="nama" readonly class="form-control mb-3" id="nama" placeholder="Nama anda!">
                      <label>Umur</label>
                      <input type="text" name="umur" readonly class="form-control mb-3" id="umur" placeholder="Umur anda!">
                    </div>
                    <label class="form-check-label">Jenis kelamin</label>
                    <input type="text" name="jenkel" readonly class="form-control" placeholder="Jenis kelamin anda!" id="jenkel">
                    <div class="form-group mt-3">
                      <label>Alamat</label>
                      <textarea name="alamat" readonly  class="form-control" id="alamat" cols="10" rows="2" placeholder="Alamat anda!"></textarea>
                    </div>
                    <input type="hidden" value="<?php date_default_timezone_set('Asia/Jakarta'); echo date('d/m/Y');?>" name="tglPrk" class="form-control mb-3">
                    <input type="hidden" value="<?php 
                      date_default_timezone_set('Asia/Jakarta'); 
                      $time = time() + (60 * 60 * 7);
                      echo gmdate('H : i',$time);
                      ?>" 
                    name="jamPrk" class="form-control mb-3">
                    <div class="container">
                      <div class="row">
                        <div class="col-12 d-flex justify-content-end">
                          <button type="reset" class="btn btn-danger btnReset mt-3">Reset</button>
                          <button type="submit" class="btn btn-primary btnDaftar mt-3">Daftar</button>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="text-center mb-3 pb-3">
          <p class="mb-0 text-white">&copy; 2024 TUGAS BK  
          <svg class="bi bi-suit-heart-fill" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#f20202" viewBox="0 0 16 16">
          <path d="M4 1c2.21 0 4 1.755 4 3.92C8 2.755 9.79 1 12 1s4 1.755 4 3.92c0 3.263-3.234 4.414-7.608 9.608a.513.513 0 0 1-.784 0C3.234 9.334 0 8.183 0 4.92 0 2.755 1.79 1 4 1z"></path>
          </svg>&nbsp;by&nbsp;<a class="text-black" href="#" target="_blank"><b>Muhammad Nur Fauzi</b></a>
          </p>
        </div>
      </section>
      <!-- ===============================================-->
      <!--    Akhir jumbotron -->
      <!-- ===============================================-->


    </main>
    <!-- ===============================================-->
    <!--    End of Main Content-->
    <!-- ===============================================-->


    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="<?= base_url()?>home/assets/js/jquery-3.6.0.min.js"></script>
    <script src="<?= base_url()?>home/vendors/@popperjs/popper.min.js"></script>
    <script src="<?= base_url()?>home/vendors/bootstrap/bootstrap.min.js"></script>
    <script src="<?= base_url()?>home/vendors/is/is.min.js"></script>
    <!--<script src="https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>-->
    <script src="<?= base_url()?>home/assets/js/theme.js"></script>
    <script src="<?= base_url('home/sweatalert/sweetalert2.all.min.js');?>"></script>
    <!-- ===============================================-->
    <!--    End of JavaScripts-->
    <!-- ===============================================-->
    <script>
      $(document).ready(function () {
        function antrian(){
          $.ajax({
            type: "post",
            url: "<?= base_url('Home/getAnt')?>",
            dataType: "json",
            success: function (data) {
              if( data.antrian != data.kuota){
                $('#noAtr').val(data.antrian);
              } else {
                $('#noAtr').val('Antrian penuh');
              }
            }
          });
        }

        antrian();
        setInterval(() => {
          antrian();
        }, 3000);

        $(window).scroll(function () { 

          var navScroll = $(this).scrollTop();

          if(navScroll >= 20){
            $('.navPB').addClass('bg-primary-gradient');
          }

          if(navScroll < 20){
            $('.navPB').removeClass('bg-primary-gradient');
          }

        });

        //Tombol cari
        $('#cari').click(function () { 

          var keyword = $('#keyword').val();
          let timerInterval

          //Progress bar
          Swal.fire({
            title: 'Proses',
            html: 'Sedang mencari data!',
            timer: 1500,
            timerProgressBar: true,
            showConfirmButton: false,
            willClose: () => {
              clearInterval(timerInterval)
            }
          });

          //Ambil data
          $.ajax({
            type: "post",
            url: "<?= base_url('home/getPsn')?>",
            data: {keyword : keyword},
            dataType: "json",
            success: function (data) {
              if(data == null){
                $('#formData')[0].reset();
                $(".alert").replaceWith(('<div class="alert alert-warning alert-dismissible fade show" role="alert"><strong>Sepertinya anda belum pernah mendaftar!<button type="button" class="btn-close" onclick="btnClose()" ></button></div>'));
                $('#proses').modal('hide');
              } else {
                $(".alert").replaceWith(('<div class="alert d-none"></div>'));
                $('#nama').val(data.nama);
                $('#nik').val(data.nik);
                $('#noRm').val(data.noRm);
                $('#umur').val(data.umur);
                $('#alamat').val(data.alamat);
                $("#jenkel").val(data.jenkel);
              }
            }
          });
        });

        //Tombol keluar alert
        btnClose = function(){
          $(".alert").replaceWith(('<div class="alert d-none"></div>'));
        }

      });
    </script>

  </body>

</html>