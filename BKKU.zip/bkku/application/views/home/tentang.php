<!DOCTYPE html>
<html lang="en-US" dir="ltr">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="<?= base_url()?>vendor/assets/img/icon.png" type="image/x-icon"/>


    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
    <title><?= $title['judul_web'];?></title>


    <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <!--<link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">-->
    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link href="<?= base_url();?>home/assets/css/theme.css" rel="stylesheet" />
    <link href="<?= base_url();?>home/assets/fonts/font.css" rel="stylesheet" />
    <link
    rel="stylesheet"
    href="<?= base_url();?>home/assets/css/animate.min.css"
  />
    <!-- ===============================================-->
    <!--    End of Stylesheets-->
    <!-- ===============================================-->

    <style>
      @media only screen and (max-width: 600px) {
        #hero{
          width: 300px !important;
          display: block;
          margin: auto;
        }

        .layanan{
          text-align: center;
          display: inline;
          margin: auto;
        }
      }

      .top{
        background-color: rgba(90, 153, 242);
        opacity: 0;
        width: 40px;
        height: 40px;
        border-radius: 50px;
        z-index: 999;
        position: fixed;
        bottom: 10px;
        right: 10px;
        transition: 0.36s;
      }
      #arrow_up{
        width: 25px;
        color: white;
        margin: auto;
        display: block;
        transform: translateY(5px);
      }
    </style>


  </head>


  <body>


    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    <main class="main" id="top">


      <!-- ===============================================-->
      <!--    Navbar menu -->
      <!-- ===============================================-->
      <nav class="navbar navbar-expand-lg navbar-dark fixed-top py-3" data-navbar-on-scroll="data-navbar-on-scroll">
        <div class="container"><a class="navbar-brand text-white d-flex align-items-center fw-bold fs-4" href="#">
          <!--<img class="d-inline-block me-3" src="assets/img/icons/logo.png" alt="" />-->
          <?= $kelola['nama_web'];?></a>
          <!--<a href="<?= base_url()?>" class="btn btn-outline-light border-0" >kembali</a>-->
          <!--<button class="navbar-toggler btn-close d-none collapsed border-0 " type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" id="btnClose" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"></button>-->
          <!--<button type="button" class="btn btn-lg" aria-label="Close">
            <i class="fas fa-times"></i>
          </button>-->
          <!--<div class="collapse navbar-collapse border-top border-lg-0 mt-4 mt-lg-0" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto pt-2 pt-lg-0">
              <li class="nav-item"><a class="nav-link active" href="#jumbotron">Home</a></li>
              <li class="nav-item"><a class="nav-link active" href="#tentang_kami">Tentang</a></li>
              <li class="nav-item"><a class="nav-link active" href="#layanan_kami">Layanan</a></li>
              <li class="nav-item"><a class="nav-link active" href="#alamat_klinik">Alamat</a></li>
              <li class="nav-item"><a class="nav-link active" style="padding-right: 20px !important;"  href="#jam_buka">Jam</a></li>
              <li class="nav-item"><a class="btn login btn-outline-light px-4 rounded-pill hover-top" href="#" role="button">Login</a></li>
            </ul>
          </div>-->
        </div>
      </nav>
      <!-- ===============================================-->
      <!--    Akhir navbar -->
      <!-- ===============================================-->

      <!-- ===============================================-->
      <!--    Jumbotron -->
      <!-- ===============================================-->
      <section class="py-0 bg-primary-gradient" style="background-attachment: fixed; height: 745px;" id="jumbotron" >
        <!--<div class="bg-holder" style="background-image:url(assets/img/illustrations/dot.png);background-position:left;background-size:auto;margin-top:-105px;">-->
        <div class="bg-holder" style="background-image:url(<?= base_url();?>home/assets/img/illustrations/dot.png);background-position:left;background-size:auto;margin-top:-105px;">
        </div>
        <!--/.bg-holder-->

        <div class="container position-relative">
          <div class="row align-items-center">
            <div class="col-md-5 col-lg-6 order-md-1 pt-8">
              <img class="img-fluid hero animate__animated animate__fadeIn" id="hero" src="<?= base_url();?>home/assets/img/illustrations/hero-header.png"/>
            </div>
            <div class="col-md-7 col-lg-6 text-center text-md-start pt-5 pt-md-9 ">
              <h1 class="mb-4 display-3 fw-bold text-white animate__animated animate__fadeInUp" id="judul">Tentang kami<br class="d-block d-lg-none d-xl-block" /></h1>
              <p class="mt-3 mb-4 fs-1 text-white animate__animated animate__fadeInUp "><?= $kelola['detail_tk'];?></p><a class="btn btn-lg btn-light rounded-pill hover-top animate__animated animate__fadeInUp" href="<?= base_url()?>" role="button">&laquo; Kembali</a>
            </div>
          </div>
        </div>
      </section>
      <!-- ===============================================-->
      <!--    Akhir jumbotron -->
      <!-- ===============================================-->

      <!-- ===============================================-->
      <!--    Footer -->
      <!-- ===============================================-->
      <section class="py-6 pt-7 bg-primary-gradient">
      <div>
        <a href="#jumbotron" class="top">
          <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="arrow-up" id="arrow_up" class="svg-inline--fa fa-arrow-up fa-w-8" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M34.9 289.5l-22.2-22.2c-9.4-9.4-9.4-24.6 0-33.9L207 39c9.4-9.4 24.6-9.4 33.9 0l194.3 194.3c9.4 9.4 9.4 24.6 0 33.9L413 289.4c-9.5 9.5-25 9.3-34.3-.4L264 168.6V456c0 13.3-10.7 24-24 24h-32c-13.3 0-24-10.7-24-24V168.6L69.2 289.1c-9.3 9.8-24.8 10-34.3.4z"></path></svg>
        </a>
      </div>

        <div class="bg-holder" style="background-image:url(<?= base_url();?>home/assets/img/illustrations/dot.png);background-position:left bottom;background-size:auto;filter:contrast(1.5);">
        </div>
        <!--/.bg-holder-->

        <div class="bg-holder" style="background-image:url(<?= base_url();?>home/assets/img/illustrations/dot-2.png);background-position:right top;background-size:auto;margin-top:-75px;">
        </div>
        <!--/.bg-holder-->

        <div class="container">
          <div class="row">
            <div class="col-12 col-lg-4 order-0 order-sm-0 pe-6"><a class="text-decoration-none" href="#">
              <!--<img class="img-fluid me-2" src="assets/img/icons/footer-logo.png" alt="" />-->
              <span class="fw-bold fs-3 text-light"><?= $kelola['nama_web'];?></span></a>
              <p class="mt-3 text-white"><?= $kelola['tagline_ft']?></p>
            </div>
            <div class="col-5 col-md-5 col-lg mb-3 order-2 order-sm-1">
              <h6 class="lh-lg fw-bold text-light">Thanks to</h6>
              <ul class="list-unstyled mb-md-5 mb-lg-0">
                <li class="lh-lg"><a class="text-light fs--1 text-decoration-none" href="#!">Allah SWT</a></li>
                <li class="lh-lg"><a class="text-light fs--1 text-decoration-none" href="#!">dr. Didik Agus Haryanto</a></li>
                <li class="lh-lg"><a class="text-light fs--1 text-decoration-none" href="#!">Semua team klinik dr. Didik</a></li>
                <!--<li class="lh-lg"><a class="text-light fs--1 text-decoration-none" href="#!">Themewagon.com</a></li>-->
                <!--<li class="lh-lg"><a class="text-light fs--1 text-decoration-none" href="#!">Apps</a></li>-->
              </ul>
            </div>
            <div class="col-5 col-md-5 col-lg mb-3 order-3 order-sm-2">
              <h6 class="lh-lg fw-bold text-light"> Ikuti kami </h6>
              <ul class="list-unstyled mb-md-5 mb-lg-0">
                <li class="lh-lg"><a class="text-light fs--1 text-decoration-none" href="#!">Instagram</a></li>
                <li class="lh-lg"><a class="text-light fs--1 text-decoration-none" href="#!">Facebook</a></li>
                <li class="lh-lg"><a class="text-light fs--1 text-decoration-none" href="#!">Twitter</a></li>
                <li class="lh-lg"><a class="text-light fs--1 text-decoration-none" href="#!">Youtube</a></li>
                <!--<li class="lh-lg"><a class="text-light fs--1 text-decoration-none" href="#!">Canada</a></li>-->
              </ul>
            </div>
            <div class="col-5 col-md-5 col-lg mb-3 order-3 order-sm-2">
              <h6 class="lh-lg fw-bold text-light"> Statistik Pengunjung </h6>
              <ul class="list-unstyled mb-md-5 mb-lg-0">
                <li class="lh-lg"><span class="text-light fs--1 text-decoration-none" >Pengunjung Hari ini : <?php echo $pengunjung ?> orang</span></li>
                <li class="lh-lg"><span class="text-light fs--1 text-decoration-none" >Total Pengunjung : <?php echo $totalpengunjung['total'] ?> orang</span></li>
                <li class="lh-lg"><span class="text-light fs--1 text-decoration-none" >Pengunjung Online : <?php echo $pengunjungonline ?> orang</span></li>
              </ul>
            </div>
          </div>
        </div>

        <div class="container mt-5" >
          <div class="row" style="transform: translateY(50px);">
            <div class="col-12">
              <div class="text-center">
                <p class="mb-0 text-white">&copy; 2024 TUGAS BK  
                  <svg class="bi bi-suit-heart-fill" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#f20202" viewBox="0 0 16 16">
                    <path d="M4 1c2.21 0 4 1.755 4 3.92C8 2.755 9.79 1 12 1s4 1.755 4 3.92c0 3.263-3.234 4.414-7.608 9.608a.513.513 0 0 1-.784 0C3.234 9.334 0 8.183 0 4.92 0 2.755 1.79 1 4 1z"></path>
                  </svg>&nbsp;by&nbsp;<a class="text-black" href="#" target="_blank"><b>Muhammad Nur Fauzi</b></a>
                </p>
              </div>
            </div>
          </div>
        </div>

      </section>
      <!-- ===============================================-->
      <!--    Akhir Footer-->
      <!-- ===============================================-->

    </main>
    <!-- ===============================================-->
    <!--    End of Main Content-->
    <!-- ===============================================-->


    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="<?= base_url();?>home/vendors/@popperjs/popper.min.js"></script>
    <script src="<?= base_url();?>home/vendors/bootstrap/bootstrap.min.js"></script>
    <script src="<?= base_url();?>home/vendors/is/is.min.js"></script>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
    <script src="<?= base_url();?>home/assets/js/theme.js"></script>
    <script src="<?= base_url();?>home/assets/js/jquery-3.6.0.min.js"></script>
    <!-- ===============================================-->
    <!--    End of JavaScripts-->
    <!-- ===============================================-->

    <script>
      $(document).ready(function(){
        
        var scroll = $(window).scroll(function(){
        //console.log('Sudah oke');
          var wScroll = $(this).scrollTop();

          console.log(wScroll);
          if(wScroll >= 50){
            $('nav').removeClass('navbar-dark');
            $('nav').addClass('navbar-light');
            $('.navbar-brand').removeClass('text-white');
            $('.login').removeClass('btn-outline-light');
            $('.login').addClass('btn-outline-secondary');
          }

          if(wScroll < 50){
            $('nav').removeClass('navbar-light');
            $('nav').addClass('navbar-dark');
            $('.login').removeClass('btn-outline-secondary');
            $('.login').addClass('btn-outline-light');
          }

          if(wScroll > 300){
            $('.top').animate({
              opacity : '0.8'
            }, 0);
          }

          if(wScroll < 300){
            $('.top').animate({
              opacity : '0'
            }, 0);
          }

          //if(wScroll > 500){
          //  $('#ttg_1').removeClass('d-none');
          //  $('#ttg_1').addClass('animate__animated animate__fadeInRight');
          //  $('#ttg_2').removeClass('d-none');
          //  $('#ttg_2').addClass('animate__animated animate__fadeInLeft');
          //}

        });

        $('#btnOpen').click(function(){
          $(this).addClass('d-none');
          $('nav').addClass('bg-primary');
          $('#btnClose').removeClass('d-none');
          $('nav .nav-item .nav-link, .navbar-brand').addClass('text-white');
          $('.login').addClass('btn-outline-light');
        });

        $('#btnClose').click(function(){
          $(this).addClass('d-none');
          $('nav').removeClass('bg-primary');
          $('#btnOpen').removeClass('d-none');
          $('nav .navbar-brand').removeClass('text-white');
        });

      });
    </script>

  </body>

</html>