<!DOCTYPE html>
<html lang="en">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="<?= base_url()?>vendor/assets/img/icon.png" type="image/x-icon"/>


    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
    <title><?= $title['judul_web'];?></title>


    <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <!--<link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">-->
    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link href="<?= base_url('home/assets/css/theme.css');?>" rel="stylesheet" />
    <link href="<?= base_url('home/assets/fonts/font.css');?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?= base_url('home/assets/css/animate.min.css')?>"/>
    <!-- ===============================================-->
    <!--    End of Stylesheets-->
    <!-- ===============================================-->

    <style>
      html,
        body {
        height: 100%;
        margin: 0;
        padding: 0;
        }
        
      @media only screen and (max-width: 600px) {
        #hero{
          width: 300px !important;
          display: block;
          margin: auto;
        }

        .card iframe{
          width: 350px !important;
          height: 350px !important;
        }

        .layanan{
          margin: 0px 0px 0px -15px !important;
          /*text-align: center;*/
          /*display: inline;*/
          margin: auto;
        }

        .tg_layanan{
          padding: 0px 20px 0px 20px;
        }

        .jamBuka{
          margin:auto;
          text-align:center;
          padding: 0px 10px 0px 10px !important;
        }
      }

      .top{
        background-color: rgba(90, 153, 242);
        opacity: 0;
        width: 40px;
        height: 40px;
        border-radius: 50px;
        z-index: 999;
        position: fixed;
        bottom: 10px;
        right: 10px;
        transition: 0.36s;
      }
      #arrow_up{
        width: 25px;
        color: white;
        margin: auto;
        display: block;
        transform: translateY(5px);
      }

      #modalDaftar{
        border-radius: 90px !important;
      }
    </style>


  </head>


  <body>


    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    <main class="main" id="top">


      <!-- ===============================================-->
      <!--    Navbar menu -->
      <!-- ===============================================-->
      <nav class="navbar navbar-expand-lg navbar-dark fixed-top py-3 animate__animated animate__fadeInDown" data-navbar-on-scroll="data-navbar-on-scroll">
        <div class="container"><a class="navbar-brand text-white d-flex align-items-center fw-bold fs-4" href="#">
          <!--<img class="d-inline-block me-3" src="assets/img/icons/logo.png" alt="" />-->
          <?= $kelola['nama_web'];?></a>
          <button class="navbar-toggler collapsed btn-open border-0 " type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" id="btnOpen" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
          <button class="navbar-toggler btn-close d-none collapsed border-0 " type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" id="btnClose" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"></button>
          <!--<button type="button" class="btn btn-lg" aria-label="Close">
            <i class="fas fa-times"></i>
          </button>-->
          <div class="collapse navbar-collapse border-top border-lg-0 mt-4 mt-lg-0" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto pt-2 pt-lg-0">
              <li class="nav-item"><a class="nav-link active" href="#jumbotron">Home</a></li>
              <li class="nav-item"><a class="nav-link active" href="#tentang_kami">Tentang</a></li>
              <li class="nav-item"><a class="nav-link active" href="#layanan_kami">Layanan</a></li>
              <li class="nav-item"><a class="nav-link active" href="#alamat_klinik">Alamat</a></li>
              <li class="nav-item"><a class="nav-link active" style="padding-right: 20px !important;"  href="#jam_buka">Jam</a></li>
              <li class="nav-item"><a class="btn login btn-outline-light px-4 rounded-pill hover-top" href="<?= base_url('auth')?>" role="button">Login</a></li>
            </ul>
          </div>
        </div>
      </nav>
      <!-- ===============================================-->
      <!--    Akhir navbar -->
      <!-- ===============================================-->


      <!-- ===============================================-->
      <!--    Jumbotron -->
      <!-- ===============================================-->
      <section class="py-0 bg-primary-gradient" style="background-attachment: fixed; height: 745px;" id="jumbotron" >
        <!--<div class="bg-holder" style="background-image:url(assets/img/illustrations/dot.png);background-position:left;background-size:auto;margin-top:-105px;">-->
        <div class="bg-holder" style="background-image:url(<?= base_url('home/assets/img/illustrations/dot.png');?>);background-position:left;background-size:auto;margin-top:-105px;">
        </div>
        <!--/.bg-holder-->

        <div class="container position-relative">
          <div class="row align-items-center">
            <div class="col-md-5 col-lg-6 order-md-1 pt-8">
              <img class="img-fluid hero animate__animated animate__fadeIn  animate__delay-1s" id="hero" src="<?= base_url('home/assets/img/illustrations/hero-header.png');?>"/>
            </div>
            <div class="col-md-7 col-lg-6 text-center text-md-start pt-5 pt-md-9 ">
              <h1 class="mb-4 display-3 fw-bold text-white animate__animated animate__fadeInUp" id="judul"><?= $kelola['nama_jumbo'];?></h1>
              <p class="mt-3 mb-4 fs-1 text-white animate__animated animate__fadeInUp "><?= $kelola['tagline_jumbo'];?> </p>

              <?php date_default_timezone_set('Asia/Jakarta');?>

              <!-- Logika buka dan tutup pendaftaran sesuai jam yang telah diatur -->
              <!-- Jam buka -->
              <?php if(date('H:i:s') >= $jam['jam_2b'] && date('H:i:s') <= $jam['jam_2t'] || date('H:i:s') >= $jam['jam_1b'] && date('H:i:s') <= $jam['jam_1t'] || date('H:i:s') >= $jam['jam_3b'] && date('H:i:s') <= $jam['jam_3t']):?>
                <a class="btn btn-lg btn-light rounded-pill hover-top animate__animated animate__fadeInUp" href="#" id="daftar" role="button"> Daftar</a>
                <?php else:?>
                <a class="btn btn-lg btn-light rounded-pill hover-top animate__animated animate__fadeInUp" href="#" role="button"> Pendaftaran Di Tutup</a>
              <?php endif;?>

              
            </div>
          </div>
        </div>
      </section>
      <!-- ===============================================-->
      <!--    Akhir jumbotron -->
      <!-- ===============================================-->


      <!-- ===============================================-->
      <!--    Tentang kami -->
      <!-- ===============================================-->
      <section class="py-6 py-lg-8 mb-5 mt-5" style="transform: translateY(50px); margin-bottom: 200px !important;" id="tentang_kami">

        <div class="container">
          <div class="row g-xl-0 align-items-center">
            <div class="col-md-6 order-md-1 text-md-start" id="ttg_1">
              
              <h2 class="fw-bold lh-base">Tentang kami</h2>
              <hr class="text-dark mx-md-0" style="height:2px;width:50px" />
              <p class="pt-3"><?= $kelola['tagline_tk'];?></p>
              <div class="py-3">
                <a href="<?= base_url('home/tentang');?>" class="btn btn-lg btn-outline-primary rounded-pill" type="submit">Detail</a>
              </div>

              
            
            </div>
            <div class="col-md-6 text-center text-md-start order-md-0" id="ttg_2">
              <img class="img-fluid mb-5 mb-md-0" src="<?= base_url('home/assets/img/illustrations/about-1.png')?>" width="480" alt="" />
            </div>
          </div>
        </div><!-- end of .container-->

      </section>
      <!-- ===============================================-->
      <!--    Akhir ucapan kami -->
      <!-- ===============================================-->


      <!-- ===============================================-->
      <!--    Layanan kami -->
      <!-- ===============================================-->
      <section class="py-8" id="layanan_kami">
        <div class="bg-holder" style="background-image:url(<?= base_url('home/assets/img/illustrations/services-bg.png');?>);background-position:center left;background-size:auto; background-attachment: fixed;">
        </div>
        <!--/.bg-holder-->

        <div class="bg-holder" style="background-image:url(<?= base_url('home/assets/img/illustrations/dot-2.png');?>);background-position:center right;background-size:auto;margin-left:-180px;margin-top:20px; background-attachment: fixed;">
        </div>
        <!--/.bg-holder-->

        <div class="container-lg mt-5">
          <div class="" id="ly_title">
            <div class="row justify-content-center">
              <div class="col-3 text-center">
                <h2 class="fw-bold layanan" >Layanan</h2>
                <hr class="w-25 mx-auto text-dark" style="height:2px;" />
              </div>
            </div>
            <div class="row justify-content-center">
              <div class="col-sm-9 col-xl-8 text-center">
                <p class="px-2 tg_layanan"><?= $kelola['tagline_ly'];?></p>
              </div>
            </div>
          </div>

          <div class="row justify-content-center h-100 pt-7 g-4">
            <div class="col-sm-9 col-md-4">
              <div class="card h-100 w-100 shadow rounded-lg p-3 p-md-2 p-lg-3 p-xl-5">
                <div class="card-body text-center text-md-start">
                  <div class="py-3"><img class="img-fluid" src="<?= base_url('home/assets/img/illustrations/search.png')?>" height="90" alt="" /></div>
                  <div class="py-3">
                    <h4 class="fw-bold card-title">Cek dokter</h4>
                    <p class="card-text">Pasien mendapatkan pemeriksaan secara langsung oleh dr. di Poli Klinik Udinus</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-9 col-md-4">
              <div class="card h-100 w-100 shadow rounded-lg p-3 p-md-2 p-lg-3 p-xl-5">
                <div class="card-body text-center text-md-start">
                  <div class="py-3"><img class="img-fluid" src="<?= base_url('home/assets/img/illustrations/online-pharmacy.png')?>" height="90" alt="" /></div>
                  <div class="py-3">
                    <h4 class="fw-bold card-title">Apotek</h4>
                    <p class="card-text">Pasien dapat membeli obat dengan mudah di apotek Poli Klinik Udinus</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-9 col-md-4">
              <div class="card h-100 w-100 shadow rounded-lg p-3 p-md-2 p-lg-3 p-xl-5">
                <div class="card-body text-center text-md-start">
                  <div class="py-3"><img class="img-fluid" src="<?= base_url('home/assets/img/illustrations/consultation.png')?>" height="90" alt="" /></div>
                  <div class="py-3">
                    <h4 class="fw-bold card-title">Daftar online</h4>
                    <p class="card-text">Pasien bisa mendaftarkan diri secara online melalui website</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-9 col-md-4">
              <div class="card h-100 w-100 shadow rounded-lg p-3 p-md-2 p-lg-3 p-xl-5">
                <div class="card-body text-center text-md-start">
                  <div class="py-3"><img class="img-fluid" src="<?= base_url('home/assets/img/illustrations/details-info.png');?>" height="90" alt="" /></div>
                  <div class="py-3">
                    <h4 class="fw-bold card-title">Konsultasi</h4>
                    <p class="card-text">Pasien dapat konsultasi secara langsung dengan dr. di Poli Klinik Udinus</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-9 col-md-4">
              <div class="card h-100 w-100 shadow rounded-lg p-3 p-md-2 p-lg-3 p-xl-5">
                <div class="card-body text-center text-md-start">
                  <div class="py-3"><img class="img-fluid" src="<?= base_url('home/assets/img/illustrations/emergency-care.png');?>" height="90" alt="" /></div>
                  <div class="py-3">
                    <h4 class="fw-bold card-title">P3K</h4>
                    <p class="card-text">Memberikan pertolongan pertama kepada korban yang mengalami kecelakan</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-9 col-md-4">
              <div class="card h-100 w-100 shadow rounded-lg p-3 p-md-2 p-lg-3 p-xl-5">
                <div class="card-body text-center text-md-start">
                  <div class="py-3"><img class="img-fluid" src="<?= base_url('home/assets/img/illustrations/tracking.png');?>" height="90" alt="" /></div>
                  <div class="py-3">
                    <h4 class="fw-bold card-title">Tracking</h4>
                    <p class="card-text">Membantu pasien dalam melakukan tracking penyakit yang di derita</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="text-center py-4">
              <!--<button class="btn btn-lg btn-outline-primary rounded-pill" type="submit">Learn more </button>-->
            </div>
          </div>
        </div>
      </section>
      <!-- ===============================================-->
      <!--    Akhir layanan kami -->
      <!-- ===============================================-->


      <!-- ===============================================-->
      <!--    Alamat klinik -->
      <!-- ===============================================-->
      <section class="py-6 py-lg-8" id="alamat_klinik">
        <div class="bg-holder" style="background-image:url(<?= base_url('home/assets/img/illustrations/dot.png');?>);background-position:right bottom;background-size:auto;margin-top:50px;">
        </div>
        <!--/.bg-holder-->

        <div class="container">
          <div class="row g-xl-0 align-items-center">
            <div class="col-md-6 " id="alm_1">
              <h2 class="fw-bold lh-base">Alamat</h2>
              <hr class="text-dark  mx-md-0" style="height:2px;width:50px" />
              <p class="pt-3"><?= $kelola['tagline_alm'];?></p>
              <div class="py-3">
                <a href="https://<?= $link;?>" target="_blank"  class="btn btn-lg btn-outline-primary rounded-pill" type="submit">Google map </a>
              </div>
            </div>
            <div class="col-md-6 text-center text-md-end " id="alm_2">
              <!--<div id="map"><h1>maps</h1></div>
              <img class="img-fluid mb-5 mb-md-0" src="<?= base_url('home/assets/img/illustrations/about.png');?>" alt="" />-->
              <div class="card shadow" >
                  <?= $kelola['maps'];?>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!-- ===============================================-->
      <!--    Akhir alamat klinik -->
      <!-- ===============================================-->


      <!-- ===============================================-->
      <!--    Jam buka -->
      <!-- ===============================================-->
      <section id="jam_buka">
        <div class="container-lg mt-2">
          <div class="row justify-content-center " id="jam1">
            <div class="col-5  text-center">
              <h2 class="fw-bold jamBuka" style="padding-left: 10px;">Jam buka</h2>
              <hr class="w-25 mx-auto text-dark" style="height:2px;" />
            </div>
          </div>
          <div class="row justify-content-center">
              <div class="col-sm-9 col-xl-8 text-center">
                <h5 class="px-2 "><b><?= $jam['tg_utama'];?></b></h5>
              </div>
            </div>
          <div class="row justify-content-center h-100 pt-7 g-4 " id="jam2" style="transform: translateY(-50px);">
            <div class="col-sm-9 col-md-4">
              <div class="card border h-100 w-100 rounded-lg p-3 p-md-2 p-lg-3 p-xl-5">
                <div class="card-body text-center text-md-start">
                  <div class="py-3 text-center">
                    <h4 class="fw-bold card-title"><?= $jam['judul_1']?></h4>
                    <p class="card-text"> <br><?= $jam['tagline_1']?><br> <br> 
                    <?php if($jam['jam_1b']==''):?>
                      <h5>Tidak melayani pemeriksaan!</h5></p>
                    <?php else:?>
                      <h5><?= $jam['jam_1b']?> - <?= $jam['jam_1t']?> WIB </h5></p>
                    <?php endif;?>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-9 col-md-4">
              <div class="card h-100 w-100 border rounded-lg p-3 p-md-2 p-lg-3 p-xl-5">
                <div class="card-body text-center text-md-start">
                  <div class="py-3 text-center">
                    <h4 class="fw-bold card-title"><?= $jam['judul_2']?></h4>
                    <p class="card-text"> <br><?= $jam['tagline_2']?><br> <br> 
                    <?php if($jam['jam_2b']==''):?>
                      <h5>Tidak melayani pemeriksaan!</h5></p>
                    <?php else:?>
                      <h5><?= $jam['jam_2b']?> - <?= $jam['jam_2t']?> WIB </h5></p>
                    <?php endif;?>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-sm-9 col-md-4">
              <div class="card h-100 w-100 border rounded-lg p-3 p-md-2 p-lg-3 p-xl-5">
                <div class="card-body text-center text-md-start">
                  <div class="py-3 text-center">
                    <h4 class="fw-bold card-title"><?= $jam['judul_3']?></h4>
                    <p class="card-text"> <br> <?= $jam['tagline_3']?><br> <br> 
                    <?php if($jam['jam_3b'] == ''):?>
                      <h5>Tidak melayani pemeriksaan!</h5></p>
                    <?php else:?>
                      <h5><?= $jam['jam_3b']?> - <?= $jam['jam_3t']?> WIB </h5></p>
                    <?php endif;?>
                  </div>
                </div>
              </div>
            </div>
            <div class="text-center py-4">
            </div>
          </div>
        </div>
      </section>
      <!-- ===============================================-->
      <!--    Akhir jam buka -->
      <!-- ===============================================-->


      <!-- ===============================================-->
      <!--    Ucapan -->
      <!-- ===============================================-->
      <section class="py-8" style="transform: translateY(-130px);" id="ucapan">
        <div class="container">
          <div class="bg-holder z-index-1" style="background-image:url(<?= base_url('home/assets/img/illustrations/dot.png');?>);background-position:right top;background-size:auto;margin-left:-30px;margin-top:10px;filter:contrast(1.5);">
          </div>
          <!--/.bg-holder-->

          <div class="bg-holder z-index-1" style="background-image:url(<?= base_url('home/assets/img/illustrations/dot-2.png');?>);background-position:left bottom;background-size:auto;margin-left:-35px;margin-top:-65px;filter:contrast(1.5);">
          </div>
          <!--/.bg-holder-->

          <div class="carousel slide" id="carouselExampleDark" data-bs-ride="carousel">
            <div class="carousel-inner">

              <?php foreach($pesan as $p):?>
                <?php if($p['active'] == 1):?>
                  <div class="carousel-item active" data-bs-interval="5000">
                <?php else : ?>
                  <div class="carousel-item" data-bs-interval="5000">
                <?php endif;?>
                  <div class="row h-100">
                    <div class="col-12">
                      <div class="card text-white bg-primary-gradient">
                        <div class="card-body p-4 p-md-4 p-lg-7">
                          <h2 class="fw-bold text-white text-center"><?= $p['judul']?></h2>
                          <hr class="mx-auto" style="height:2px;width:50px" />
                          <div class="d-md-flex align-items-md-center mt-1 text-center text-md-start">
                            <div class="w-md text-center">
                              <p class="card-text ms-md-5 text-center">“<?= $p['isi']?>”</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <?php endforeach;?>

              </div>
            <div class="row mt-4 flex-center">
              <div class="col-4 col-sm-5 text-end position-relative z-index-2"><a class="carousel-control-prev carousel-icon z-index-2" href="#carouselExampleDark" role="button" data-bs-slide="prev"><span class="carousel-control-prev-icon" aria-hidden="true"></span><span class="visually-hidden">Previous</span></a></div>
              <div class="col-auto position-relative z-index-2">
                <ol class="carousel-indicators">
                  <?php foreach($pesan as $p):?>
                    <?php if($p['active']==1):?>
                      <li class="active" data-bs-target="#carouselExampleDark" data-bs-slide-to="<?= $p['id']-1?>"></li>
                    <?php else:?>
                      <li data-bs-target="#carouselExampleDark" data-bs-slide-to="<?= $p['id']-1?>"></li>
                    <?php endif;?>
                  <?php endforeach; ?>
                </ol>
              </div>
              <div class="col-4 col-sm-5 position-relative z-index-2"><a class="carousel-control-next carousel-icon z-index-2" href="#carouselExampleDark" role="button" data-bs-slide="next"><span class="carousel-control-next-icon" aria-hidden="true"></span><span class="visually-hidden">Next</span></a></div>
            </div>
          </div>
        </div>
      </section>
      <!-- ===============================================-->
      <!--    Akhir ucapan-->
      <!-- ===============================================-->


      <!-- ===============================================-->
      <!--    Footer -->
      <!-- ===============================================-->
      <section class="py-6 pt-7 bg-primary-gradient mt-5">
      <div>
        <a href="#jumbotron" class="top">
          <svg aria-hidden="true" focusable="false" data-prefix="fas" data-icon="arrow-up" id="arrow_up" class="svg-inline--fa fa-arrow-up fa-w-8" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512"><path fill="currentColor" d="M34.9 289.5l-22.2-22.2c-9.4-9.4-9.4-24.6 0-33.9L207 39c9.4-9.4 24.6-9.4 33.9 0l194.3 194.3c9.4 9.4 9.4 24.6 0 33.9L413 289.4c-9.5 9.5-25 9.3-34.3-.4L264 168.6V456c0 13.3-10.7 24-24 24h-32c-13.3 0-24-10.7-24-24V168.6L69.2 289.1c-9.3 9.8-24.8 10-34.3.4z"></path></svg>
        </a>
      </div>

        <div class="bg-holder" style="background-image:url(<?= base_url('home/assets/img/illustrations/dot.png');?>);background-position:left bottom;background-size:auto;filter:contrast(1.5);">
        </div>
        <!--/.bg-holder-->

        <div class="bg-holder" style="background-image:url(<?= base_url('home/assets/img/illustrations/dot-2.png');?>);background-position:right top;background-size:auto;margin-top:-75px;">
        </div>
        <!--/.bg-holder-->

        <div class="container">
          <div class="row">
            <div class="col-12 col-lg-4 order-0 order-sm-0 pe-6"><a class="text-decoration-none" href="#">
              <!--<img class="img-fluid me-2" src="assets/img/icons/footer-logo.png" alt="" />-->
              <span class="fw-bold fs-3 text-light"><?= $kelola['nama_web'];?></span></a>
              <p class="mt-3 text-white"><?= $kelola['tagline_ft']?></p>
            </div>
            <div class="col-5 col-md-5 col-lg mb-3 order-2 order-sm-1">
              <h6 class="lh-lg fw-bold text-light">Thanks to</h6>
              <ul class="list-unstyled mb-md-5 mb-lg-0">
                <li class="lh-lg"><a class="text-light fs--1 text-decoration-none" href="#!">Allah SWT</a></li>
                <li class="lh-lg"><a class="text-light fs--1 text-decoration-none" href="#!">Poli Klinik udinus</a></li>
                <li class="lh-lg"><a class="text-light fs--1 text-decoration-none" href="#!">Semua team klinik UDINUS</a></li>
                <!--<li class="lh-lg"><a class="text-light fs--1 text-decoration-none" href="#!">Themewagon.com</a></li>-->
              </ul>
            </div>
            <div class="col-5 col-md-5 col-lg mb-3 order-3 order-sm-2">
              <h6 class="lh-lg fw-bold text-light"> Ikuti kami </h6>
              <ul class="list-unstyled mb-md-5 mb-lg-0">
                <li class="lh-lg"><a class="text-light fs--1 text-decoration-none" target="_blank" href="https://<?= $kelola['instagram_ft']?>">Instagram</a></li>
                <li class="lh-lg"><a class="text-light fs--1 text-decoration-none" target="_blank" href="https://<?= $kelola['facebook_ft']?>">Facebook</a></li>
                <li class="lh-lg"><a class="text-light fs--1 text-decoration-none" target="_blank" href="https://<?= $kelola['twitter_ft']?>">Twitter</a></li>
                <li class="lh-lg"><a class="text-light fs--1 text-decoration-none" target="_blank" href="https://<?= $kelola['youtube']?>">Youtube</a></li>
              </ul>
            </div>
            <div class="col-5 col-md-5 col-lg mb-3 order-3 order-sm-2">
              <h6 class="lh-lg fw-bold text-light"> Statistik Pengunjung </h6>
              <ul class="list-unstyled mb-md-5 mb-lg-0">
                <li class="lh-lg"><span class="text-light fs--1 text-decoration-none" >Pengunjung Hari ini : <?php echo $pengunjung ?> orang</span></li>
                <li class="lh-lg"><span class="text-light fs--1 text-decoration-none" >Total Pengunjung : <?php echo $totalpengunjung['total'] ?> orang</span></li>
                <li class="lh-lg"><span class="text-light fs--1 text-decoration-none" >Pengunjung Online : <?php echo $pengunjungonline ?> orang</span></li>
              </ul>
            </div>
          </div>
        </div>


        <div class="container mt-5" >
          <div class="row" style="transform: translateY(50px);">
            <div class="col-12">
              <div class="text-center">
              <p class="mb-0 text-white">&copy; 2024 TUGAS BK 
            <svg class="bi bi-suit-heart-fill" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#f20202" viewBox="0 0 16 16">
            <path d="M4 1c2.21 0 4 1.755 4 3.92C8 2.755 9.79 1 12 1s4 1.755 4 3.92c0 3.263-3.234 4.414-7.608 9.608a.513.513 0 0 1-.784 0C3.234 9.334 0 8.183 0 4.92 0 2.755 1.79 1 4 1z"></path>
            </svg>&nbsp;by&nbsp;<a class="text-black" href="#" target="_blank"><b>Muhammad Nur Fauzi</b></a>
              </p>
              </div>
            </div>
          </div>
        </div>

      </section>
      <!-- ===============================================-->
      <!--    Akhir Footer-->
      <!-- ===============================================-->


      <!-- ===============================================-->
      <!--    Modal -->
      <!-- ===============================================-->
      <div class="modal fade " id="modalDaftar" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true" style="border-radius: 0px;">
        <div class="modal-dialog modal-dialog-centered">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title text-center mx-auto px-auto" style="padding-left: 90px;">Mau daftar?</h5>
              <button type="button" class="btn btn-close" id="close2"></button>
            </div>
            <div class="modal-body">
              <h5 class=" text-center">
                Apakah anda sudah pernah mendaftar? Jika belum, silakan tekan "Pasien baru" jika sudah, tekan "Pasien Lama"
              </h5>
              
            </div>
            <div class="modal-footer text-center">
              <div class="mx-auto">
                <a href="<?= base_url('home/psnBr')?>" class="btn btn-primary">Pasien baru</a>
                <a href="<?= base_url()?>home/psnLm" class="btn btn-danger">Pasien lama</a>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- ===============================================-->
      <!--    End of Modal -->
      <!-- ===============================================-->



    </main>
    <!-- ===============================================-->
    <!--    End of Main Content-->
    <!-- ===============================================-->


    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="<?= base_url('home/assets/js/jquery-3.6.0.min.js');?>"></script>
    <script src="<?= base_url('home/vendors/@popperjs/popper.min.js');?>"></script>
    <script src="<?= base_url('home/vendors/bootstrap/bootstrap.min.js');?>"></script>
    <script src="<?= base_url('home/vendors/is/is.min.js');?>"></script>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
    <script src="<?= base_url('home/assets/js/theme.js');?>"></script>
    <!-- ===============================================-->
    <!--    End of JavaScripts-->
    <!-- ===============================================-->
    <?php if(date('H:i:s') >= $jam['jam_2b'] && date('H:i:s') <= $jam['jam_2t'] || date('H:i:s') >= $jam['jam_1b'] && date('H:i:s') <= $jam['jam_1t'] || date('H:i:s') >= $jam['jam_3b'] && date('H:i:s') <= $jam['jam_3t']):?>
      <script>
        function coba(){
          console.log('test');
        }

        coba();
      </script>
    <?php else:?>
      <script>
        function coba1(){
          $.ajax({
                  type: "post",
                  url: "<?= base_url('Home/udtAnt')?>",
                  dataType: "json",
                  success: function (response) {
                    console.log(response);
                    //antrian();
                  }
                });
        }

        coba1();
      </script>
    <?php endif;?>
    <script>
      $(document).ready(function(){
        
        var scroll = $(window).scroll(function(){
        
          var wScroll = $(this).scrollTop();

          if(wScroll >= 50){
            $('nav').removeClass('navbar-dark');
            $('nav').addClass('navbar-light');
            $('.navbar-brand').removeClass('text-white');
            $('.login').removeClass('btn-outline-light');
            $('.login').addClass('btn-outline-secondary');
          }

          if(wScroll < 50){
            $('nav').removeClass('navbar-light');
            $('nav').addClass('navbar-dark');
            $('.login').removeClass('btn-outline-secondary');
            $('.login').addClass('btn-outline-light');
          }

          if(wScroll > 300){
            $('.top').animate({
              opacity : '0.6'
            }, 0);
          }

          if(wScroll < 300){
            $('.top').animate({
              opacity : '0'
            }, 0);
          }

        });

        $('#btnOpen').click(function(){
          $(this).addClass('d-none');
          $('nav').addClass('bg-primary');
          $('#btnClose').removeClass('d-none');
          $('nav .nav-item .nav-link, .navbar-brand').addClass('text-white');
          $('.login').addClass('btn-outline-light');
        });

        $('#btnClose').click(function(){
          $(this).addClass('d-none');
          $('nav').removeClass('bg-primary');
          $('#btnOpen').removeClass('d-none');
          $('nav .navbar-brand').removeClass('text-white');
        });

      $('#close, #close2').click(function () {
        $('#modalDaftar').modal('hide');
      });

      $('#daftar').click(function () {
        $('#modalDaftar').modal('show');
      });

      });
    </script>

  </body>

</html>