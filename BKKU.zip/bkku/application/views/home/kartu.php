<!DOCTYPE html>
<html lang="en-US" dir="ltr">

  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" href="<?= base_url()?>vendor/assets/img/icon.png" type="image/x-icon"/>

    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
    <title><?= $title['judul_web'];?></title>


    <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
    <!--<link rel="apple-touch-icon" sizes="180x180" href="assets/img/favicons/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicons/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicons/favicon-16x16.png">
    <link rel="shortcut icon" type="image/x-icon" href="assets/img/favicons/favicon.ico">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="assets/img/favicons/mstile-150x150.png">-->
    <meta name="theme-color" content="#ffffff">


    <!-- ===============================================-->
    <!--    Stylesheets-->
    <!-- ===============================================-->
    <link href="<?= base_url()?>home/assets/css/theme.css" rel="stylesheet"/>
    <link href="<?= base_url()?>home/assets/fonts/font.css" rel="stylesheet"/>
    <link href="<?= base_url()?>home/assets/css/animate.min.css" rel="stylesheet"/>
    <!-- ===============================================-->
    <!--    End of Stylesheets-->
    <!-- ===============================================-->

    <style>
      .pageKartu{
        /*width: 480px;*/
        background: #FFF173;
        min-height: 465px;
        margin: 70px 0px 10px 0px;
        font-family:  Times, 'Times New Roman', serif;
      }
      .btnDaftar{
        margin-right: -30px !important;
      }
      .btnReset{
        margin-right: 10px !important;
      }

      #jumboPB{
        height: 740px !important;
      }

      @media only screen and (max-width: 600px) {
        #kartu tr td {
          font-size: 14px;
        }

      }

      .card-title{
        border: 2px solid black;
      }

      h5, h6{
        font-family: serif;
      }

      hr{
        width: 100%;
        margin: auto;
        background-color: black;
      }

      table tbody tr td{
        text-transform: uppercase;
      }

      #tableRM {
      }
    </style>

  </head>


  <body class="bg-primary-gradient">


    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    <main class="main" id="top">


      <!-- ===============================================-->
      <!--    Navbar menu -->
      <!-- ===============================================-->
      <nav class="navbar  navbar-dark fixed-top py-1 navPB animate__animated animate__fadeInDown">
        <div class="container">
          <a class="navbar-brand text-white d-flex align-items-center fw-bold fs-4" href="#">
          <?= $kelola['nama_web']?></a>
          <!--<a href="index.html" class="btn btn-outline-light border-0 mt-2 fs-1" >Info</a>-->
          <!--<button type="submit" class="btn btn-outline-light btnDaftar mt-3">Download</button>-->
        </div>
      </nav>
      <!-- ===============================================-->
      <!--    Akhir navbar -->
      <!-- ===============================================-->


      <!-- ===============================================-->
      <!--    Jumbotron -->
      <!-- ===============================================-->
      <section class="py-0" id="jumboPB" >
        
        <div class="bg-holder" style="background-image:url(<?= base_url()?>home/assets/img/illustrations/dot.png);background-position:left;background-size:auto;margin-top:-105px;">
        </div>

        <div class="container position-relative">
          <div class="row align-items-center">
            <div class="col-md-6 col-lg-6 daftar mx-auto">
              <div class="card pageKartu animate__animated animate__fadeIn  animate__delay-1s">
                <div class="card-body">
                  <div class="card-title text-center pt-1 mx-2 mt-3">
                    <h5 class="fw-bold">KARTU ANTRIAN</h5>
                  </div>
                  <h6 class="d-flex justify-content-end text-dark pr-4" style="margin-right: 20px;"><?= $tglPrk;?></h6>
                  <table class="table table-borderless mx-2" border="0" id="kartu">
                    <tbody>
                      <tr class="text-black">
                        <td width="140">No antrian</td>
                        <td width="5">:</td>
                        <td><b><?= $noAtr;?></b></td>
                      </tr>
                      <tr class="text-black">
                        <td>No RM</td>
                        <td>:</td>
                        <td>
                          <table id="tableRM">
                            <tr>
                              <td><?= substr($noRm,0,1);?></td>
                              <td><?= substr($noRm,1,1);?></td>
                              <td><?= substr($noRm,2,1);?></td>
                              <td><?= substr($noRm,3,1);?></td>
                              <td><?= substr($noRm,4,1);?></td>
                            </tr>
                          </table>
                        </td>
                      </tr>
                      <tr class="text-black">
                        <td>NIK</td>
                        <td>:</td>
                        <td><?= $nik;?></td>
                      </tr>
                      <tr class="text-black">
                        <td>Nama</td>
                        <td>:</td>
                        <td><?= $nama;?></td>
                      </tr>
                      <tr class="text-black">
                        <td>Umur</td>
                        <td>:</td>
                        <td><?= $umur;?> tahun</td>
                      </tr>
                      <tr class="text-black">
                        <td>Jenis kelamin</td>
                        <td>:</td>
                        <td><?= $jenkel;?></td>
                      </tr>
                      <tr class="text-black">
                        <td>Alamat</td>
                        <td>:</td>
                        <td width="150"><?= $alamat;?></td>
                      </tr>
                    </tbody>
                  </table>
                  <div class="card-title text-center pt-1 mx-2 mt-3">
                    <h6 class="fw-bold"><i><b>Bila berobat</b>, mohon kartu ini dibawa!</i></h6>
                  </div>
                </div>
              </div>
              <div class="container">
                <div class="row">
                  <div class="col-12 text-center">
                    <p class="text-white mt-2">Silakan "<i>Download</i>" terlebih dahulu kartu diatas sebelum keluar dari aplikasi ini!</p>
                    <a href="<?= base_url()?>" class="btn btn-outline-light btnSelesai mt-1 d-none">Selesai</a>
                    <form action="<?= base_url('Home/Kartu_antrian')?>" method="post" target="_blank">
                      <input type="hidden" value="<?= $tglPrk;?>" name="tglPrk">
                      <input type="hidden" value="<?= $noAtr;?>" name="noAtr">
                      <input type="hidden" value="<?= $noRm;?>" name="noRm">
                      <input type="hidden" value="<?= $nik;?>" name="nik">
                      <input type="hidden" value="<?= $nama;?>" name="nama">
                      <input type="hidden" value="<?= $umur;?>" name="umur">
                      <input type="hidden" value="<?= $jenkel;?>" name="jenkel">
                      <input type="hidden" value="<?= $alamat;?>" name="alamat">
                    <button type="submit" class="btn btn-outline-light btnDownload mt-1">Download</button>
                  </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="text-center mt-4 pb-3">
                <p class="mb-0 text-white">&copy; 2024 TUGAS BK 
                  <svg class="bi bi-suit-heart-fill" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#f20202" viewBox="0 0 16 16">
                    <path d="M4 1c2.21 0 4 1.755 4 3.92C8 2.755 9.79 1 12 1s4 1.755 4 3.92c0 3.263-3.234 4.414-7.608 9.608a.513.513 0 0 1-.784 0C3.234 9.334 0 8.183 0 4.92 0 2.755 1.79 1 4 1z"></path>
                  </svg>&nbsp;by&nbsp;<a class="text-black" href="#" target="_blank"><b>Muhammad Nur Fauzi</b></a>
                </p>
              </div>
      </section>
      <!-- ===============================================-->
      <!--    Akhir jumbotron -->
      <!-- ===============================================-->


    </main>
    <!-- ===============================================-->
    <!--    End of Main Content-->
    <!-- ===============================================-->


    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="<?= base_url()?>home/assets/js/jquery-3.6.0.min.js"></script>
    <script src="<?= base_url()?>home/vendors/@popperjs/popper.min.js"></script>
    <script src="<?= base_url()?>home/vendors/bootstrap/bootstrap.min.js"></script>
    <script src="<?= base_url()?>home/vendors/is/is.min.js"></script>
    <script src="https://polyfill.io/v3/polyfill.min.js?features=window.scroll"></script>
    <script src="<?= base_url()?>home/assets/js/theme.js"></script>
    <!-- ===============================================-->
    <!--    End of JavaScripts-->
    <!-- ===============================================-->
    <script>
      $(document).ready(function () {
        $('.btnDownload').click(function () { 
          $(this).addClass('d-none');
          $('.btnSelesai').removeClass('d-none');
        });
      });
    </script>

  </body>

</html>