<div class="main-panel">
			<div class="content">
				<div class="panel-header bg-primary-gradient">
					<div class="page-inner py-5">
						<div class="d-flex align-items-left align-items-md-center flex-column flex-md-row">
							<div>
								<h2 class="text-white pb-2 fw-bold"> <i class="fas fa-user-plus mr-2"></i> <?= $this->session->userdata('user');?></h2>
								<h5 class="text-white op-7 mb-2">Selamat Datang Nakes!</h5>
							</div>
							<div class="ml-md-auto py-2 py-md-0">
								<a href="<?= base_url('Nakes/cetakPsn')?>" class="btn btn-success btn-round mr-2" target="_blank" >Cetak</a>
								<button class="btn btn-light btn-round" id="bkk" data-toggle="collapse" data-target="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">Tambah</button>
								<!--<button class="btn btn-light btn-round" id="bkk" data-toggle="collapse" data-target="#detailPsn" role="button" aria-expanded="false" aria-controls="collapseExample">Detail</button>-->
							</div>
						</div>
					</div>
				</div>
				<div class="page-inner mt--5 tmbPasien collapse" id="collapseExample">
                    <div class="row">
                        <div class="col-12">
                            <div class="row">
                                <div class="col-5 mx-auto">
                                    <div class="card">
                                        <div class="card-header">
                                            <h4 class="psnBr">Daftar Pasien Baru</h4>
                                        </div>
                                        <div class="card-body">
                                            <form id="formPsn">
                                                <div class="row">
                                                    <div class="col-6">
                                                        <label for="">No Antrian</label>
                                                        <input id="noAnt" readonly name="noAnt" required autocomplete="off" placeholder="" type="text" class="mt-2 mb-3 form-control form-control-sm">
                                                        <input id="user" name="user" required autocomplete="off" placeholder="" value="<?= $this->session->userdata('user');?>" type="hidden" class="mt-2 mb-3 form-control form-control-sm">
                                                    </div>
                                                    <div class="col-6">
                                                        <label for="">No RM</label>
                                                        <input id="noRm" readonly name="noRm" required autocomplete="off" placeholder="" type="text" class="mt-2 mb-3 form-control form-control-sm">
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-6">
                                                        <label for="">Nama Lengkap</label>
                                                        <input id="namaPsn" name="namaPsn" required autocomplete="off" placeholder="Masukan nama pasien!" type="text" class="mt-2 mb-3 form-control form-control-sm">
                                                    </div>
                                                    <div class="col-6">
                                                        <label for="">NIK</label>
                                                        <input id="nikPsn" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength="16" name="nikPsn" required autocomplete="off" placeholder="Masukan NIK pasien!" type="number" class="mt-2 mb-3 form-control form-control-sm">
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-6">
                                                        <label for="">Umur</label>
                                                        <input id="umurPsn" oninput="javascript: if (this.value.length > this.maxLength) this.value = this.value.slice(0, this.maxLength);" maxlength="3" name="umurPsn" placeholder="Masukan umur pasien!" required autocomplete="off" type="number" class="mt-2 mb-3 form-control form-control-sm">
                                                    </div>
                                                    <div class="col-6">
                                                        <label for="">Jenis kelamin</label>
                                                        <Select id="jenkelPsn" name="jenkelPsn" class="form-control">
                                                            <option value="Laki-laki">Laki-laki</option>
                                                            <option value="Perempuan">Perempuan</option>
                                                        </Select>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col">
                                                        <label for="">Alamat</label>
                                                        <textarea id="alamatPsn" name="alamatPsn" required placeholder="Masukan alamat pasien!" autocomplete="off" type="text" class="mt-2 mb-3 form-control form-control-sm"></textarea>
                                                    </div>
                                                </div>
                                                <input type="hidden" value="<?php date_default_timezone_set('Asia/Jakarta'); echo date('d/m/Y');?>" name="tglPrk" class="form-control mb-3">
                                                <input type="hidden" value="<?php 
                                                date_default_timezone_set('Asia/Jakarta'); 
                                                $time = time() + (60 * 60 * 7);
                                                echo gmdate('H : i',$time);
                                                ?>" 
                                                name="jamPrk" class="form-control mb-3">
                                                <button type="submit" class="float-right btn btn-primary tmbPsn tmbPsnlm">Daftar</button>
                                                <button type="button" class="btnReset mr-3 float-right btn btn-danger btnBatal">Reset</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <!--<div class="col-5 mx-auto coba">
                                    <div class="card krtObat">
                                        <div class="card-title text-center kop pt-1 mx-2 mt-3 mx-4 mt-4">
                                            <h5 class="fw-bold" style="color:black; font-family:  Times, 'Times New Roman';">KARTU BEROBAT</h5>
                                        </div><br>
                                        <h6 class="d-flex justify-content-end text-dark pr-4" style="margin-right: 20px; font-family:  Times, 'Times New Roman';"><?= date('d/m/Y');?></h6>
                                        <table class='table' id="tablerm">
                                            <tbody>
                                            <tr class="text-black">
                                                <td id="nat">No antrian</td>
                                                <td id="nut">:</td>
                                                <td><b class="noAnt"></b></td>
                                            </tr>
                                            <tr class="text-black">
                                                <td id="nat">No RM</td>
                                                <td id="nut">:</td>
                                                <td class="krtRm">

                                                </td>
                                            </tr>
                                            <tr class="text-black">
                                                <td>NIK</td>
                                                <td>:</td>
                                                <td id="krtNik"></td>
                                            </tr>
                                            <tr class="text-black">
                                                <td>Nama</td>
                                                <td>:</td>
                                                <td id="krtNama"></td>
                                            </tr>
                                            <tr class="text-black">
                                                <td>Umur</td>
                                                <td>:</td>
                                                <td id="krtUmur"></td>
                                            </tr>
                                            <tr class="text-black">
                                                <td>Jenis kelamin</td>
                                                <td>:</td>
                                                <td id="krtJenkel">Laki-laki</td>
                                            </tr>
                                            <tr class="text-black">
                                                <td>Alamat</td>
                                                <td>:</td>
                                                <td id="krtAlamat"></td>
                                            </tr>
                                            </tbody>
                                        </table>
                                        <div class="card-title text-center kop pt-1 mx-4 mt-3 mb-4" >
                                            <h6 class="fw-bold" style="color:black; font-family:  Times, 'Times New Roman';"><i><b>Bila berobat</b>, mohon kartu ini dibawa!</i></h6>
                                        </div>
                                    </div>
                                </div>-->

                            
                                
                            </div>
                            
                        </div>
                    </div>
				</div>

				

				<div class="page-inner mt--5">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between">
                            <h3>Data Pasien</h3>
                            <h5 class="mt-1">Otomatis update dalam 10 detik</h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-12">
                                    <table class="table table-striped" id="tablen">
                                        <thead class="bg-primary text-white">
                                            <tr>
                                                <!--<th>No</th>-->
                                                <th width="10">Antrian</th>
                                                <th>Rm</th>
                                                <th>NIK</th>
                                                <th>Nama</th>
                                                <th>Alamat</th>
                                                <th width="10">Periksa</th>
                                                <th width="50">Aksi</th>
                                            </tr>
                                        </thead>
                                        <tbody id="lihat">
                                        
                                        </tbody>
                                    </table>
                                </div>
                                
                            </div>
                        </div>
                    </div>
					
				</div>
			</div>
            
            	<!-- Modal Edit data pasien -->
				<div class="modal fade" id="editPsn" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
					<div class="modal-dialog" style="margin-top: 100px;">
						<div class="modal-content">
						<div class="modal-header">
							<h3 class="modal-title" id="staticBackdropLabel">Edit Data Pasien</h3>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body">
							<div class="container">
								<div class="row">
									<div class="col-12 mx-auto">
										<form action="" id="formEdt">
                                                <div class="row">
                                                    <div class="col-6">
                                                        <label for="">No Antrian</label>
                                                        <input id="edtAnt" readonly name="noAnt" required autocomplete="off" placeholder="" type="text" class="mt-2 mb-3 form-control form-control-sm">
                                                        <input id="idPsn" readonly name="id" required autocomplete="off" placeholder="" type="hidden" class="mt-2 mb-3 form-control form-control-sm">
                                                        <input id="user" name="user" required autocomplete="off" placeholder="" value="<?= $this->session->userdata('user');?>" type="hidden" class="mt-2 mb-3 form-control form-control-sm">
                                                    </div>
                                                    <div class="col-6">
                                                        <label for="">No RM</label>
                                                        <input id="editNoRm" readonly name="noRm" required autocomplete="off" placeholder="" type="text" class="mt-2 mb-3 form-control form-control-sm">
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-6">
                                                        <label for="">Nama Lengkap</label>
                                                        <input id="edtNamaPsn" name="namaPsn" required autocomplete="off" placeholder="Masukan nama pasien!" type="text" class="mt-2 mb-3 form-control form-control-sm">
                                                    </div>
                                                    <div class="col-6">
                                                        <label for="">NIK</label>
                                                        <input id="edtNikPsn" name="nikPsn" required autocomplete="off" placeholder="Masukan NIK pasien!" type="number" class="mt-2 mb-3 form-control form-control-sm">
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-6">
                                                        <label for="">Umur</label>
                                                        <input id="edtUmurPsn" name="umurPsn" placeholder="Masukan umur pasien!" required autocomplete="off" type="number" class="mt-2 mb-3 form-control form-control-sm">
                                                    </div>
                                                    <div class="col-6">
                                                        <label for="">Jenis kelamin</label>
                                                        <Select id="edtJenkelPsn" name="jenkelPsn" class="form-control">
                                                            <option value="Laki-laki">Laki-laki</option>
                                                            <option value="Perempuan">Perempuan</option>
                                                        </Select>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col">
                                                        <label for="">Alamat</label>
                                                        <textarea id="edtAlamatPsn" name="alamatPsn" required placeholder="Masukan alamat pasien!" autocomplete="off" type="text" class="mt-2 mb-3 form-control form-control-sm"></textarea>
                                                    </div>
                                                </div>
                                                <input type="hidden" value="<?php date_default_timezone_set('Asia/Jakarta'); echo date('d/m/Y');?>" name="tglPrk" class="form-control mb-3">
                                                <input type="hidden" value="<?php 
                                                date_default_timezone_set('Asia/Jakarta'); 
                                                $time = time() + (60 * 60 * 7);
                                                echo gmdate('H : i',$time);
                                                ?>" 
                                                name="jamPrk" class="form-control mb-3">
                                        </form>
									</div>
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
							<button type="button" onclick="btnEdtPsn()" class="btn btn-primary">Ubah</button>
						</div>
						</div>
					</div>
				</div>
				<!-- Akhir modal -->

            	<!-- Modal detail data pasien -->
				<div class="modal fade" id="detPsn" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
					<div class="modal-dialog" style="margin-top: 100px;">
						<div class="modal-content">
						<div class="modal-header">
							<h3 class="modal-title" id="staticBackdropLabel">Detail Data Pasien</h3>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body">
							<div class="container">
								<div class="row">
									<div class="col-12 mx-auto">
										<form action="" id="formEdt">
                                                <div class="row">
                                                    <div class="col-6">
                                                        <label for="">No Antrian</label>
                                                        <p class="fw-bold h3 detAnt"></p>
                                                        <input id="user" name="user" required autocomplete="off" placeholder="" value="<?= $this->session->userdata('user');?>" type="hidden" class="mt-2 mb-3 form-control form-control-sm">
                                                    </div>
                                                    <div class="col-6">
                                                        <label for="">No RM</label>
                                                        <p class="fw-bold h3 detRm"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-6">
                                                        <label for="">Nama Lengkap</label>
                                                        <p class="fw-bold h3 detNamaPsn"></p>
                                                    </div>
                                                    <div class="col-6">
                                                        <label for="">NIK</label>
                                                        <p class="fw-bold h3 detNikPsn"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-6">
                                                        <label for="">Umur</label>
                                                        <p class="fw-bold h3 detUmurPsn"></p>
                                                    </div>
                                                    <div class="col-6">
                                                        <label for="">Jenis kelamin</label>
                                                        <p class="fw-bold h3 detJenkelPsn"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-6">
                                                        <label for="">Alamat</label>
                                                        <p class="fw-bold h3 detAlamatPsn"></p>
                                                    </div>
                                                    <div class="col-6">
                                                        <label for="">Tanggal Daftar</label>
                                                        <p class="fw-bold detTglPsn h3"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-6">
                                                        <label for="">Jam daftar</label>
                                                        <p class="fw-bold detJamPsn h3"></p>
                                                    </div>
                                                    <div class="col-6">
                                                        <label for="">Penginput data</label>
                                                        <p class="fw-bold detUserPsn h3"></p>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col">
                                                        <span for="" class=" ml-auto">Status &nbsp;:&nbsp; <div type="button" class="badge stsPsn"></div></span>
                                                    </div>
                                                </div>
                                        </form>
									</div>
								</div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Tutup</button>
						</div>
						</div>
					</div>
				</div>
				<!-- Akhir modal -->

			<footer class="footer">
				<div class="container-fluid">
					<div class="copyright ml-auto mx-auto my-auto">
						&copy; 2024 TUGAS BK 
						<svg class="bi bi-suit-heart-fill" xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="#f20202" viewBox="0 0 16 16">
						<path d="M4 1c2.21 0 4 1.755 4 3.92C8 2.755 9.79 1 12 1s4 1.755 4 3.92c0 3.263-3.234 4.414-7.608 9.608a.513.513 0 0 1-.784 0C3.234 9.334 0 8.183 0 4.92 0 2.755 1.79 1 4 1z"></path>
						</svg>&nbsp;by&nbsp;<a class="text-black" href="#" target="_blank"><b>Muhammad Nur Fauzi</b>
					</div>				
				</div>
			</footer>
		</div>

