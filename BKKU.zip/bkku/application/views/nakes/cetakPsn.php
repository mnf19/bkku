<!DOCTYPE html>
<html lang="en"><head>
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<title></title>
	<meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />

	<!-- Style -->
	<style>
		#kop{
			transform:translateY(-30px);
			margin:auto;
		}
		#pasien tr td{
			font-size: 18px;
			text-transform: uppercase;
			border:0px;
		}
		#rm tr td{
			text-align:center;
			border-right: 1px solid black;
			border-bottom: 1px solid black;
			max-height: 50px;
			padding: 10px 10px;
		}
		#rm tr th{
			text-align:center;
			padding: 0px;
			border-top: 2px solid black;
			border-left: 2px solid black;
			border-bottom: 2px solid black;
			height: 15px;
			font-size: 16px !important;
		}
		#rm tr th:last-child{
			border-right: 2px solid black;
		}
		#rm tr td:first-child{
			border-left: 1px solid black;
		}
		#rm{
			transform:translateX(-25px) !important;
			border-spacing: 0px;
		}
		.dokter{
			text-align: center;
			padding: 0px 0px;
			font-size:26px;
			font-weight:bolder;
			text-transform:uppercase;
			font-family:  Times, 'Times New Roman', serif;
			border-bottom: 2px solid black;
		}
		.noRm{
			text-align: center;
			transform:translate(200px, 10px);
			font-size:16px;
			font-weight:bolder;
			text-transform:uppercase;
			font-family:  Times, 'Times New Roman', serif;
			position: fixed;
			z-index: 9;
		}
		.garis{
			width:700px;
			height:1px;
			background:black;
			margin-left:-140px;
		}
		.garis2{
			width:700px;
			height:2px;
			background:black;
			transform:translateY(1px);
			margin-left:-140px;
		}
		#pasien{
			transform:translateY(-30px);
		}
		.att{
			transform:translateY(-10px);
			font-size:16px;
		}
	</style>
	<!-- Akhir -->

</head><body>
		<h5 style="text-align:right; position: fixed; top:-40px; right: 0px ;"> Dicetak pada : <?= date('d/m/Y')?> </h5>

		<table id="kop" border="0">
			<tr>
				<td>
					<img width="120" src="<?php echo 'assets/'.$kelola['logo_kop'] ;?>">
				</td>
				<td width="300">
					<center>
					<span>
						<u class="dokter"><?= $kelola['nama_kop']?></u>
					</span>
						<br>
						<br>
						<span class="att">SIP <?= $kelola['nomer_kop']?></span>
						<br>
						<span class="att"><?= $kelola['alamat_kop']?></span>
						<br>
						<span class="att">Telp. <?= $kelola['telp_kop']?></span>
						<br>
						<span class="att">Email : <?= $kelola['email_kop']?> </span>
						<div class="garis"></div>
						<div class="garis2"></div>
					</center>
				</td>
				<td width="100">
					<!--<p class="noRm"> NAMA  : <?= $this->session->userdata('user');?> </p>-->
				</td>
			</tr>
		</table>
		<center>
			<h2 class="mx-auto">DATA PASIEN</h2>
		</center>
		<br>
		<table width="100" border="1" id="rm">
			<tr >
				<th width="110">NAMA</th>
				<th width="40">NO RM</th>
				<th width="90">NIK</th>
				<th width="50">UMUR</th>
				<th width="70">JENKEL</th>
				<th width="100">ALAMAT</th>
			</tr>
			<?php foreach($pasien as $p):?>
			<tr>
				<td width="110"><?= $p['nama']?></td>
				<td width="40"><?= $p['noRm']?></td>
				<td width="90"><?= $p['nik']?></td>
				<td width="50"><?= $p['umur']?> tahun</td>
				<td width="70"><?= $p['jenkel']?></td>
				<td width="100"><?= $p['alamat']?></td>
			</tr>
			<?php endforeach;?>
		</table>
		<!--<footer>
			<h6 style="position: fixed; bottom:0px; left: 12px;">Developed by Muhammad Nur Fauzi</h6>
		</footer>-->
</body></html>
