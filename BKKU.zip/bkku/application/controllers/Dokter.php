<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dokter extends CI_Controller {

	public function __construct(){
        parent:: __construct();
        
		if(!$this->session->userdata('user')){
			
			redirect('auth','refresh');
			
		}

		if($this->session->userdata('level') != 2){
			
			redirect('auth','refresh');
			
		}

        $this->load->library('form_validation');
        $this->load->library('dompdf_gen');

    }

	//Sidebar menu function
	private function _sidebar($data){
		$data['menu'] = $this->db->get_where('menu',['akses'=>2])->result_array();
		$this->load->view('dokter/sidebar' , $data);
	}

	//Header function
	private function _header(){
		$data['title'] = $this->db->select('judul_web')
								->get_where('kelola',['id'=>1])
								->row_array();
		$this->load->view('template/header', $data);
	}

	//Index function
	public function index(){
		
		$data['title'] = 'Dashboard';
		
		$this->_header();
		$this->_sidebar($data);
		$this->load->view('dokter/index', $data);
		$this->load->view('template/footer');
		
	}

	public function getSts()
	{
		$id = $this->input->post('id');
		$this->db->select('sts');
		$isi = $this->db->get_where('pasien', ['id'=>$id])->row_array();
		if($isi['sts'] == 0){
			$sts = 1;
		} else {
			$sts = 0;
		}
		$data = [
			'sts' => $sts,
		];
		$this->db->update('pasien', $data, ['id'=>$id]);
		$pesan =" sudah diperiksa bos!";
		echo json_encode($pesan);
		
	}

	public function lihatData()
	{	
		$this->db->order_by('id', 'desc');
		$row = $this->db->get('pasien')->result_array();
		$data['data'] = $row;
		echo json_encode($data);
		
	}

	public function detPasien ()
	{
		$id = $this->input->post('id');
		$data = $this->db->get_where('pasien', ['id'=>$id])->row_array();
		echo json_encode($data);
	}

	public function rekam()
	{
		$data['title'] = 'Dashboard';
		$this->_header();
		$this->_sidebar($data);
		$this->load->view('dokter/rekam');
		$this->load->view('template/footer');
	}
	
	public function rmPasien($noRm = null)
	{	
		//echo $noRm;
		$this->db->order_by('id', 'desc');
		$row = $this->db->get_where('rekam_medis', ["noRm"=>$noRm])->result_array();
		$data['data'] = $row;
		echo json_encode($data);
	}

	public function getPsn ()
	{
		$noRm = $this->input->post('noRm');
		$data = $this->db->get_where('pasien', ['noRm'=>$noRm])->row_array();
		echo json_encode($data);
	}

	public function tmbRm()
	{
		$data = [
			'tanggal' => $this->input->post('tanggal'),
			'noRm'    => $this->input->post('rmNoRm'),
			'keluhan' => $this->input->post('keluhan'),
			'periksa' => $this->input->post('periksa'),
			'diagnosa'=> $this->input->post('diagnosa'),
			'rencana' => $this->input->post('rencana'),
		];

		$this->db->insert('rekam_medis', $data);
		$pesan = "Datanya udah masuk nih bos!";
		echo json_encode($pesan);
	}

	public function getRm()
	{
		$id = $this->input->post('id');
		$data = $this->db->get_where('rekam_medis', ['id'=>$id])->row_array();
		echo json_encode($data);
	}

	public function editRm()
	{
		$id = $this->input->post('idRm');
		$data = [
			'keluhan' => $this->input->post('keluhan'),
			'periksa' => $this->input->post('periksa'),
			'diagnosa'=> $this->input->post('diagnosa'),
			'rencana' => $this->input->post('rencana'),
		];

		$this->db->update('rekam_medis', $data, ['id'=>$id]);
		$pesan = "data sudah diedit nih bos!";
		echo json_encode($pesan);
	}

	public function hpsRm()
	{
		$id = $this->input->post('id');
		$this->db->delete('rekam_medis', ['id'=>$id]);
		$pesan = "Data udah dihapus bos!";
		echo json_encode($pesan);
		
	}

	public function profil(){
		
		$data['title'] = 'Profil';
		$this->_header();
		$this->_sidebar($data);
		$this->load->view('dokter/profil');
		$this->load->view('template/footer');
		
	}

	public function udtProfil(){

		$id = $this->input->post('id');
		//echo $id;
		//die;
		
		$data = [
			'nama' 	      => $this->input->post('nama'),
			'username'    => $this->input->post('username'),
			"nip" 		  => $this->input->post('nip'), 
			"alamat" 	  => $this->input->post('alamat'), 
			"jenkel" 	  => $this->input->post('jenkel'),
			"tgl_lahir"   => $this->input->post('tgl_lahir'), 
			"tempat_lahir"=> $this->input->post('tempat_lahir'), 
			"agama"       => $this->input->post('agama'), 
		];

		$upload_image = $_FILES['foto']['name'];
		
            if ($upload_image) {

                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size']      = '2048';
                $config['upload_path'] = './assets/';

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('foto')) {
				$user = $this->db->get_where('user', ['id'=>$id])->row_array();

                    $old_image = $user['foto'];
                    if ($old_image != 'default.jpg') {
                        unlink(FCPATH . 'assets/' . $old_image);
                    }
                    $new_image = $this->upload->data('file_name');
                    $this->db->set('foto', $new_image);
                } else {
                    echo $this->upload->display_errors();
                }
            }
		$this->db->where('id', $id)->update('user',$data);
		$this->session->set_flashdata('profil', '<div class="btn text-white bg-success-gradient ml-auto mt-5 mr-4" style="transform:translateY(-70px);" id="alert">Profil berhasil diupdate!</div>');
		redirect('dokter/profil','refresh');
		
	}

	public function stsPeriksa()
	{
		$sudah = $this->db->get_where('pasien', ['sts'=>1])->num_rows();
		$belum = $this->db->get_where('pasien', ['sts'=>0])->num_rows();

		$data=[
			'sudah'=>$sudah,
			'belum'=>$belum,
		];
		echo json_encode($data);
	}

	public function cetak(){
		$noRm = $this->input->post('ctkRm');
		
		//$data['rekam'] = $noRm;
		$data['rekam'] = $this->db->get_where('rekam_medis', ['noRm'=> $noRm])->result_array();
		$data['pasien'] = $this->db->get_where('pasien', ['noRm'=> $noRm])->row_array();
		$data['kelola'] = $this->db->get('kelola')->row_array();
		
        $this->load->view('dokter/cetakRm', $data);
        

        $html = $this->output->get_output();
        $this->dompdf->set_paper('A4', 'potrait');

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream('Rekam_Medis_'.$noRm.'.pdf', array('Attachment' => 0));
    }

}

