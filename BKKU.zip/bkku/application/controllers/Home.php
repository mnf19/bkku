<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function __construct(){
        parent:: __construct();
        //$this->load->model('Pasien_model'); 
        $this->load->library('form_validation');
        $this->load->library('dompdf_gen');
    }

	public function index()
	{
		$ip      = $_SERVER['REMOTE_ADDR'];
        $tanggal = date("Y-m-d");
        $waktu   = time(); 
        $cekk = $this->db->query("SELECT * FROM statistik WHERE ip='$ip' AND tanggal='$tanggal'");
        $rowh = $cekk->row_array();
        if($cekk->num_rows() == 0){
            $datadb = array('ip'=>$ip, 'tanggal'=>$tanggal, 'hits'=>'1', 'online'=>$waktu);
            $this->db->insert('statistik',$datadb);
        }else{
            $hitss = $rowh['hits'] + 1;
            $datadb = array('ip'=>$ip, 'tanggal'=>$tanggal, 'hits'=>$hitss, 'online'=>$waktu);
            $array = array('ip' => $ip, 'tanggal' => $tanggal);
            $this->db->where($array);
            $this->db->update('statistik',$datadb);
        }

		$data['title'] = $this->db->select('judul_web')
								->get_where('kelola',['id'=>1])
								->row_array();
		$data['kelola'] = $this->db->get_where('kelola', ['id'=>1])->row_array();
		$data['link'] = $data['kelola']['link_alm'];
		$data['pesan'] = $this->db->get('pesan')->result_array();
		$data['jam'] = $this->db->get('jam_buka')->row_array();
		$data['pengunjung'] = $this->db->query("SELECT * FROM statistik WHERE tanggal='".date("Y-m-d")."' GROUP BY ip")->num_rows();
		$data['totalpengunjung'] = $this->db->query("SELECT COUNT(hits) as total FROM statistik")->row_array();
		$bataswaktu       = time() - 300;
		$data['pengunjungonline'] = $this->db->query("SELECT * FROM statistik WHERE online > '$bataswaktu'")->num_rows();
		$data['ip'] = $_SERVER['REMOTE_ADDR'];
		$this->load->view('home/index', $data);
	}

	//Halaman pasien baru
	public function psnBr()
	{
		$this->form_validation->set_rules('nama','Nama','required|trim');
		$this->form_validation->set_rules('nik','NIK','required|trim');
		$this->form_validation->set_rules('umur','Umur','required|trim');
		$this->form_validation->set_rules('jenkel','Jenis kelamin','required|trim');
		$this->form_validation->set_rules('alamat','Alamat','required|trim');

		if($this->form_validation->run() == false){

			$data['title'] = $this->db->select('judul_web')
								->get_where('kelola',['id'=>1])
								->row_array();
			
			//Ambil nomer RM secara otomatis
			$b = $this->db->select_max('noRm')->get('pasien')->row_array();
			$data['noRm'] = $b['noRm']+1;

			$data['jam'] = $this->db->get('jam_buka')->row_array();

			$this->load->view('home/pasienBaru', $data);

		} else{
			$this->_antrian($this->input->post('noAtr'));

			$data = [
				'nama'		=> $this->input->post('nama'),
				'umur' 		=> $this->input->post('umur'),
				'alamat' 	=> $this->input->post('alamat'),
				'nik' 		=> $this->input->post('nik'),
				'jenkel' 	=> $this->input->post('jenkel'),
				'noAtr' 	=> $this->input->post('noAtr'),
				'noRm' 		=> $this->input->post('noRm'),
				'tglPrk' 	=> $this->input->post('tglPrk'),
				'jamPrk' 	=> $this->input->post('jamPrk'),
				'user' 	    => 'personal',
			];

			$this->db->insert('pasien', $data);

			$this->session->set_userdata($data);
			redirect('home/krtPsn');
			
		}

	}

	public function getAnt()		
	{
		//Ambil nomer antrian secara otomatis
		$a = $this->db->select_max('no_antrian')->get('antrian')->row_array();
		$c = $this->db->get_where('antrian',['id'=>1])->row_array();
		
		$data = [
			'antrian' => $a['no_antrian'],
			'kuota' => $c['kuota'],
		];

		echo json_encode($data);
	}

	public function jam()
	{
		$a = $this->db->get('jam_buka')->row_array();
		$data['jam'] = $a;
		echo json_encode($data);
	}

	public function udtAnt()
	{
		$data=[
			'no_antrian' => 1
		];

		$this->db->update('antrian', $data, ['id'=>1]);
		$pesan = 'udah diupdate nih bos!';
		echo json_encode($pesan);
		
	}

	private function _antrian($antrian){

		$data = [
				'no_antrian' => $antrian + 1,
			];

		$this->db->update('antrian', $data, ['id'=>1]);
	}

	//Halaman pasien lama
	public function psnLm()
	{	
		$this->form_validation->set_rules('nama','Anda','required|trim');

		if($this->form_validation->run() == false){
			
			$data['title'] = $this->db->select('judul_web')
								->get_where('kelola',['id'=>1])
								->row_array();
			
			//Ambil nomer antrian secara otomatis
			$a = $this->db->select_max('noAtr')->get('pasien')->row_array();
			$data['noAtr'] = $a['noAtr']+1;

			$this->load->view('home/pasienLama', $data);

		} else {
			$this->_antrian($this->input->post('noAtr'));
			$data = [
				'nama'		=> $this->input->post('nama'),
				'umur' 		=> $this->input->post('umur'),
				'alamat' 	=> $this->input->post('alamat'),
				'nik' 		=> $this->input->post('nik'),
				'jenkel' 	=> $this->input->post('jenkel'),
				'noAtr' 	=> $this->input->post('noAtr'),
				'noRm' 		=> $this->input->post('noRm'),
				'tglPrk' 	=> $this->input->post('tglPrk'),
				'jamPrk' 	=> $this->input->post('jamPrk'),
				'user' 	    => 'personal',
			];

			$this->db->insert('pasien', $data);
			$this->session->set_userdata($data);
			redirect('home/krtPsn');
		}


	}

	//Halaman kartu pasien
	public function krtPsn()
	{

		$data = [
				'nama'		=> $this->session->userdata('nama'),
				'umur' 		=> $this->session->userdata('umur'),
				'alamat' 	=> $this->session->userdata('alamat'),
				'nik' 		=> $this->session->userdata('nik'),
				'jenkel' 	=> $this->session->userdata('jenkel'),
				'noAtr' 	=> $this->session->userdata('noAtr'),
				'noRm' 		=> $this->session->userdata('noRm'),
				'tglPrk' 	=> $this->session->userdata('tglPrk'),
				'jamPrk' 	=> $this->session->userdata('jamPrk'),
			];
		$data['kelola'] = $this->db->get_where('kelola', ['id'=>1])->row_array();
		$data['title'] = $this->db->select('judul_web')
								->get_where('kelola',['id'=>1])
								->row_array();
		$this->load->view('home/kartu', $data);
	}

	//Cari data pasien lama
	public function getPsn(){
		$keyword = $this->input->post('keyword');
		if($keyword){
			$data = $this->db->like('nik', $keyword)
					->or_like('noRm', $keyword)
					->get('pasien')
					->row_array();
			echo json_encode($data);
		} else {
			$pesan = "Sepertinya anda belum pernah mendaftar!";
			echo json_encode($pesan);
		}
	}

	public function tentang(){
		$ip      = $_SERVER['REMOTE_ADDR'];
        $tanggal = date("Y-m-d");
        $waktu   = time(); 
        $cekk = $this->db->query("SELECT * FROM statistik WHERE ip='$ip' AND tanggal='$tanggal'");
        $rowh = $cekk->row_array();
        if($cekk->num_rows() == 0){
            $datadb = array('ip'=>$ip, 'tanggal'=>$tanggal, 'hits'=>'1', 'online'=>$waktu);
            $this->db->insert('statistik',$datadb);
        }else{
            $hitss = $rowh['hits'] + 1;
            $datadb = array('ip'=>$ip, 'tanggal'=>$tanggal, 'hits'=>$hitss, 'online'=>$waktu);
            $array = array('ip' => $ip, 'tanggal' => $tanggal);
            $this->db->where($array);
            $this->db->update('statistik',$datadb);
        }
		$data['pengunjung'] = $this->db->query("SELECT * FROM statistik WHERE tanggal='".date("Y-m-d")."' GROUP BY ip")->num_rows();
		$data['totalpengunjung'] = $this->db->query("SELECT COUNT(hits) as total FROM statistik")->row_array();
		$bataswaktu       = time() - 300;
		$data['pengunjungonline'] = $this->db->query("SELECT * FROM statistik WHERE online > '$bataswaktu'")->num_rows();
		$data['ip'] = $_SERVER['REMOTE_ADDR'];
		$data['title'] = $this->db->select('judul_web')
								->get_where('kelola',['id'=>1])
								->row_array();

		$data['kelola'] = $this->db->get_where('kelola', ['id'=>1])->row_array();
		
		$this->load->view('home/tentang', $data);
	}

	public function forbidden(){
		$data['title'] = $this->db->select('judul_web')
								->get_where('kelola',['id'=>1])
								->row_array();
		$this->load->view('home/forbidden',$data);
	}

	public function Kartu_antrian()
	{	
		
		$data=[
			'nama' 		=> $this->input->post('nama'),
			'umur' 		=> $this->input->post('umur'),
			'jenkel' 	=> $this->input->post('jenkel'),
			'alamat' 	=> $this->input->post('alamat'),
			'nik' 		=> $this->input->post('nik'),
			'noRm' 		=> $this->input->post('noRm'),
			'noAtr' 	=> $this->input->post('noAtr'),
			'tglPrk' 	=> $this->input->post('tglPrk'),
		];

		$this->load->view('home/krtPsn', $data);
        
        $html = $this->output->get_output();
        $this->dompdf->set_paper('A4', 'potrait');

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream('Kartu_antrian.pdf', array('Attachment' => 0));
	}
}
