<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();

		if (!$this->session->userdata('user')) {

			redirect('auth', 'refresh');
		}

		if ($this->session->userdata('level') != 1) {

			redirect('auth', 'refresh');
		}

		$this->load->library('form_validation');
	}

	//Sidebar menu function
	private function _sidebar($data)
	{
		$data['menu'] = $this->db->get_where('menu', ['akses' => 1])->result_array();
		$this->load->view('admin/sidebar', $data);
	}

	//Header function
	private function _header()
	{
		$data['title'] = $this->db->select('judul_web')
			->get_where('kelola', ['id' => 1])
			->row_array();
		$this->load->view('template/header', $data);
	}

	//Index function
	public function index()
	{

		$data['title'] = 'Dashboard';
		$this->_header();
		$this->_sidebar($data);
		$tahun = date('Y');
		$januari = $this->db->where('tanggal >=', "$tahun-1-01")->where('tanggal <=', "$tahun-1-30")->get('statistik')->num_rows();
		$februari = $this->db->where('tanggal >=', "$tahun-2-01")->where('tanggal <=', "$tahun-2-30")->get('statistik')->num_rows();
		$maret = $this->db->where('tanggal >=', "$tahun-3-01")->where('tanggal <=', "$tahun-3-30")->get('statistik')->num_rows();
		$april = $this->db->where('tanggal >=', "$tahun-4-01")->where('tanggal <=', "$tahun-4-30")->get('statistik')->num_rows();
		$mei = $this->db->where('tanggal >=', "$tahun-5-01")->where('tanggal <=', "$tahun-5-30")->get('statistik')->num_rows();
		$juni = $this->db->where('tanggal >=', "$tahun-6-01")->where('tanggal <=', "$tahun-6-30")->get('statistik')->num_rows();
		$juli = $this->db->where('tanggal >=', "$tahun-7-01")->where('tanggal <=', "$tahun-7-30")->get('statistik')->num_rows();
		$agustus = $this->db->where('tanggal >=', "$tahun-8-01")->where('tanggal <=', "$tahun-8-30")->get('statistik')->num_rows();
		$september = $this->db->where('tanggal >=', "$tahun-9-01")->where('tanggal <=', "$tahun-9-30")->get('statistik')->num_rows();
		$oktober = $this->db->where('tanggal >=', "$tahun-10-01")->where('tanggal <=', "$tahun-10-30")->get('statistik')->num_rows();
		$november = $this->db->where('tanggal >=', "$tahun-11-01")->where('tanggal <=', "$tahun-11-30")->get('statistik')->num_rows();
		$desember = $this->db->where('tanggal >=', "$tahun-12-01")->where('tanggal <=', "$tahun-12-30")->get('statistik')->num_rows();
		$data = [
			'jan' => $januari,
			'feb' => $februari,
			'mar' => $maret,
			'apr' => $april,
			'mei' => $mei,
			'jun' => $juni,
			'jul' => $juli,
			'agus' => $agustus,
			'sep' => $september,
			'okt' => $oktober,
			'nov' => $november,
			'des' => $desember,
		];

		$data['kunjungan'] = $this->db->query("SELECT *, COUNT(date_format(tanggal, ' %Y')) as total FROM statistik GROUP BY date_format(tanggal, '%Y')")->result_array();
		$data['personal'] = $this->db->get_where('pasien', ['user' => 'personal'])->num_rows();
		$data['nakes'] = $this->db->get_where('pasien', ['user !=' => 'personal'])->num_rows();

		$this->load->view('admin/index', $data);
		$this->load->view('template/footer_admin', $data);
	}

	//landing Page 
	public function landingPage()
	{

		$kelola = $this->db->get_where('kelola', ['id' => 1])->row_array();

		$this->db->order_by('id', 'desc');
		$pesan = $this->db->get('pesan')->result_array();
		$jam   = $this->db->get('jam_buka')->row_array();

		$data = [
			'title'  => 'Landing Page',
			'kelola' => $kelola,
			'pesan'  => $pesan,
			'jam'    => $jam
		];
		//$data['title'] = 'Landing Page';
		$this->_header();
		$this->_sidebar($data);
		$this->load->view('admin/landingPage', $data);
		$this->load->view('template/footer');
	}

	//User 
	public function user()
	{

		$data['title'] = 'User';
		$data['admin'] = $this->session->userdata('user');
		//$this->db->where('level !=','1');
		$data['user'] = $this->db->order_by('id', 'DESC')
			->get('user')
			->result_array();
		$this->_header();
		$this->_sidebar($data);
		$this->load->view('admin/user', $data);
		$this->load->view('template/footer');
	}

	//Profil
	public function profil()
	{
		//$data['user'] = $this->input->get_where('user')

		$data['title'] = 'Profil';
		$this->_header();
		$this->_sidebar($data);
		$this->load->view('admin/profil');
		$this->load->view('template/footer');
	}

	//General setting
	public function general()
	{

		$nama_web = $this->input->post('nama_web');
		$judul_web = $this->input->post('judul_web');

		$data = [
			'nama_web' => $nama_web,
			'judul_web' => $judul_web
		];

		$this->db->where('id', 1)
			->update('kelola', $data);
		$this->session->set_flashdata('general', '<div class="btn text-white bg-success-gradient float-right" id="alert">Data Berhasil diubah!</div>');
		redirect('admin/landingPage', 'refresh');
	}

	//Jumbo setting
	public function jumbotron()
	{

		$nama_jumbo 		= $this->input->post('nama_jumbo');
		$tagline_jumbo 	= $this->input->post('tagline_jumbo');

		$data = [
			'nama_jumbo'  => $nama_jumbo,
			'tagline_jumbo' => $tagline_jumbo
		];

		$this->db->where('id', 1)
			->update('kelola', $data);
		$this->session->set_flashdata('jumbo', '<div class="btn text-white bg-success-gradient float-right" id="alert">Data Berhasil diubah!</div>');

		redirect('admin/landingPage', 'refresh');
	}

	//Tentang kami setting
	public function tentangKami()
	{

		$detail_tk 		= $this->input->post('detail_tk');
		$tagline_tk 	= $this->input->post('tagline_tk');

		$data = [
			'detail_tk'  => $detail_tk,
			'tagline_tk' => $tagline_tk
		];

		$this->db->where('id', 1)
			->update('kelola', $data);
		$this->session->set_flashdata('tentang', '<div class="btn text-white bg-success-gradient float-right" id="alert">Data Berhasil diubah!</div>');

		redirect('admin/landingPage', 'refresh');
	}

	//Layanan setting
	public function layanan()
	{

		$tagline_ly = $this->input->post('tagline_ly');

		$data = [
			'tagline_ly' => $tagline_ly
		];

		$this->db->where('id', 1)
			->update('kelola', $data);
		$this->session->set_flashdata('layanan', '<div class="btn text-white bg-success-gradient float-right" id="alert">Data Berhasil diubah!</div>');

		redirect('admin/landingPage', 'refresh');
	}

	//Alamat setting
	public function alamat()
	{

		$tagline_alm = $this->input->post('tagline_alm');
		$link_alm    = $this->input->post('link_alm');
		$maps    = $this->input->post('maps');

		$data = [
			'tagline_alm' => $tagline_alm,
			'link_alm' => $link_alm,
			'maps' => $maps
		];

		$this->db->where('id', 1)
			->update('kelola', $data);
		$this->session->set_flashdata('alamat', '<div class="btn text-white bg-success-gradient float-right" id="alert">Data Berhasil diubah!</div>');

		redirect('admin/landingPage', 'refresh');
	}

	//Footer setting
	public function footer()
	{

		$tagline_ft   = $this->input->post('tagline_ft');
		$instagram_ft = $this->input->post('instagram_ft');
		$twitter_ft   = $this->input->post('twitter_ft');
		$facebook_ft  = $this->input->post('facebook_ft');
		$youtube      = $this->input->post('youtube');

		$data = [
			'tagline_ft'   => $tagline_ft,
			'instagram_ft' => $instagram_ft,
			'twitter_ft'   => $twitter_ft,
			'facebook_ft'  => $facebook_ft,
			'youtube'      => $youtube
		];

		$this->db->where('id', 1)
			->update('kelola', $data);
		$this->session->set_flashdata('footer', '<div class="btn text-white bg-success-gradient float-right" id="alert">Data Berhasil diubah!</div>');

		redirect('admin/landingPage', 'refresh');
	}

	//Pesan setting
	public function pesan()
	{

		$judul   = $this->input->post('judul');
		$isi 	 = $this->input->post('isi');

		$data = [
			'judul'   => $judul,
			'isi'     => $isi,
		];

		$this->db->insert('pesan', $data);
		$this->session->set_flashdata('alert', '<div class="btn text-white bg-success-gradient float-right" id="alert">Data Berhasil ditambah!</div>');
		redirect('admin/landingPage', 'refresh');
	}

	//Ambil data pesan
	public function getData()
	{
		$id = $this->input->post('id');

		$data = $this->db->get_where('pesan', ['id' => $id])->row_array();
		echo json_encode($data);
	}

	//Ubah data pesan
	public function ubahPesan()
	{
		$id = $this->input->post('id');

		$data = [
			'judul' => $this->input->post('judul'),
			'isi'   => $this->input->post('isi'),
		];

		$this->db->where('id', $id)->update('pesan', $data);
		$pesan = 'data diubah!';
		echo json_encode($pesan);
		$this->session->set_flashdata('alert', '<div class="btn text-white bg-success-gradient float-right" id="alert">Data Berhasil diubah!</div>');
		redirect('admin/landingPage', 'refresh');
	}

	//Hapus data pesan 
	public function hapusPesan()
	{
		$id = $this->input->post('id');

		$this->db->where('id', $id)->delete('pesan');
		$pesan = 'data dihapus!';
		echo json_encode($pesan);
		$this->session->set_flashdata('alert', '<div class="btn text-white bg-success-gradient float-right" id="alert">Data Berhasil dihapus!</div>');
		redirect('admin/landingPage', 'refresh');
	}

	//Ubah tempat data pesan 
	public function awalPesan()
	{
		$id = $this->input->post('id');
		$pesan = $this->db->get_where('pesan', ['active' => 1])->row_array();
		$idPsn = $pesan['id'];
		$data = [
			'active' => 0
		];
		$this->db->where('id', $idPsn);
		$this->db->update('pesan', $data);
		$this->_ubah($id);
		$alert = "Berhasil diubah!";
		echo json_encode($alert);
		$this->session->set_flashdata('alert', '<div class="btn text-white bg-success-gradient float-right" id="alert">Pesan Berhasil diatur!</div>');
		redirect('admin/landingPage', 'refresh');
	}

	private function _ubah($id)
	{
		$data = [
			'active' => 1
		];
		$this->db->where('id', $id);
		$this->db->update('pesan', $data);
	}

	//Ubah jam buka
	public function jamBuka()
	{

		$tg_utama = $this->input->post('tg_utama');
		$jam_1b  = $this->input->post('jam_1b');
		$jam_1t  = $this->input->post('jam_1t');
		//$libur_1 = $this->input->post('libur_1');

		$jam_2b  = $this->input->post('jam_2b');
		$jam_2t  = $this->input->post('jam_2t');
		//$libur_2 = $this->input->post('libur_2');

		$jam_3b  = $this->input->post('jam_3b');
		$jam_3t  = $this->input->post('jam_3t');
		//$libur_3 = $this->input->post('libur_3');

		$judul_1 = $this->input->post('judul_1');
		$judul_2 = $this->input->post('judul_2');
		$judul_3 = $this->input->post('judul_3');
		$tagline_1 = $this->input->post('tagline_1');
		$tagline_2 = $this->input->post('tagline_2');
		$tagline_3 = $this->input->post('tagline_3');

		$data = [
			'tg_utama' => $tg_utama,
			'jam_1b'  => $jam_1b,
			'jam_1t'  => $jam_1t,
			//'libur_1' => $libur_1,
			'jam_2b'  => $jam_2b,
			'jam_2t'  => $jam_2t,
			//'libur_2' => $libur_2,
			'jam_3b'  => $jam_3b,
			'jam_3t'  => $jam_3t,
			//'libur_3' => $libur_3,
			'judul_1' => $judul_1,
			'judul_2' => $judul_2,
			'judul_3' => $judul_3,
			'tagline_1' => $tagline_1,
			'tagline_2' => $tagline_2,
			'tagline_3' => $tagline_3,
		];

		$this->db->where('id', 1)->update('jam_buka', $data);
		$this->session->set_flashdata('jam_buka', '<div class="btn text-white bg-success-gradient float-right" id="alert">Data Berhasil diubah!</div>');
		redirect('admin/landingPage', 'refresh');
	}

	//Tambah data user
	public function addUser()
	{
		$this->form_validation->set_rules('nama', 'Nama', 'trim|required');
		$this->form_validation->set_rules('username', 'Username', 'trim|required|is_unique[user.username]');
		$this->form_validation->set_rules('password', 'Password', 'required|trim');
		$this->form_validation->set_rules('level', 'Level', 'trim|required');

		if ($this->form_validation->run() == false) {

			redirect('admin/user', 'refresh');
		} else {

			$data = [
				'nama' 	   => $this->input->post('nama'),
				'username' => $this->input->post('username'),
				'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
				'level'    => $this->input->post('level'),
				"active" 	  => "0",
				"nip" 		  => "00000",
				"alamat" 	  => "default",
				"jenkel" 	  => "laki-laki",
				"foto" 		  => "default.jpg",
				"tgl_lahir"   => "0000-00-00",
				"tempat_lahir" => "default",
				"agama"       => "Islam",
			];

			$this->db->insert('user', $data);
			$this->session->set_flashdata('pesan', '<div class="btn text-white bg-success-gradient ml-auto" id="alert" style="transform : translateY(-50px);">Data user berhasil ditambah!</div>');
			redirect('admin/user', 'refresh');
		}
	}

	//Ambil data user
	public function getDataUser()
	{
		$id = $this->input->post('id');
		$data = $this->db->get_where('user', ['id' => $id])->row_array();
		echo json_encode($data);
	}

	//Edit data user
	public function editUser()
	{
		$id = $this->input->post('id');

		$data = [
			'username' => $this->input->post('username'),
			'level'    => $this->input->post('level'),
		];

		$this->db->where('id', $id)->update('user', $data);
		$this->session->set_flashdata('pesan', '<div class="btn text-white bg-success-gradient ml-auto" id="alert" style="transform : translateY(-50px);">Data user berhasil diubah!</div>');
		redirect('admin/user', 'refresh');
	}

	//Hapus data user
	public function hpsUser()
	{
		$id = $this->input->post('id');
		$this->db->delete('user', ['id' => $id]);

		$this->session->set_flashdata('pesan', '<div class="btn text-white bg-success-gradient ml-auto" id="alert" style="transform : translateY(-50px);">Data user berhasil dihapus!</div>');

		redirect('admin/user', 'refresh');
	}

	//Aktifasi user
	public function actUser($id)
	{
		$user = $this->db->get_where('user', ['id' => $id])->row_array();
		$act = $user['active'];

		if ($act == 1) {

			$data = [
				'active' => 0,
			];
			$this->db->where('id', $id)->update('user', $data);
			$this->session->set_flashdata('pesan', '<div class="btn text-white bg-success-gradient ml-auto" id="alert" style="transform : translateY(-50px);">User berhasil di non aktifkan!</div>');
			redirect('admin/user', 'refresh');
		} else {
			$data = [
				'active' => 1,
			];
			$this->db->where('id', $id)->update('user', $data);
			$this->session->set_flashdata('pesan', '<div class="btn text-white bg-success-gradient ml-auto" id="alert" style="transform : translateY(-50px);">User berhasil diaktifasi!</div>');
			redirect('admin/user', 'refresh');
		}
	}

	public function udtProfil()
	{

		$id = $this->input->post('id');
		//echo $id;
		//die;

		$data = [
			'nama' 	      => $this->input->post('nama'),
			'username'    => $this->input->post('username'),
			"nip" 		  => $this->input->post('nip'),
			"alamat" 	  => $this->input->post('alamat'),
			"jenkel" 	  => $this->input->post('jenkel'),
			"tgl_lahir"   => $this->input->post('tgl_lahir'),
			"tempat_lahir" => $this->input->post('tempat_lahir'),
			"agama"       => $this->input->post('agama'),
		];

		$upload_image = $_FILES['foto']['name'];

		if ($upload_image) {

			$config['allowed_types'] = 'gif|jpg|png';
			$config['max_size']      = '2048';
			$config['upload_path'] = './assets/';

			$this->load->library('upload', $config);

			if ($this->upload->do_upload('foto')) {
				$user = $this->db->get_where('user', ['id' => $id])->row_array();

				$old_image = $user['foto'];
				if ($old_image != 'default.jpg') {
					unlink(FCPATH . 'assets/' . $old_image);
				}
				$new_image = $this->upload->data('file_name');
				$this->db->set('foto', $new_image);
			} else {
				echo $this->upload->display_errors();
			}
		}
		$this->db->where('id', $id)->update('user', $data);
		$this->session->set_flashdata('profil', '<div class="btn text-white bg-success-gradient ml-auto mt-5 mr-4" style="transform:translateY(-70px);" id="alert">Profil berhasil diupdate!</div>');
		redirect('admin/profil', 'refresh');
	}

	public function edtKop()
	{
		$data = [
			'nama_kop' => $this->input->post('nama_kop'),
			'alamat_kop' => $this->input->post('alamat_kop'),
			'nomer_kop' => $this->input->post('nomer_kop'),
			'telp_kop' => $this->input->post('telp_kop'),
			'email_kop' => $this->input->post('email_kop'),
		];

		$upload_image = $_FILES['logo_kop']['name'];

		if ($upload_image) {

			$config['allowed_types'] = 'jpg|png';
			$config['max_size']      = '2048';
			$config['upload_path'] = './assets/';

			$this->load->library('upload', $config);

			if ($this->upload->do_upload('logo_kop')) {
				$user = $this->db->get_where('kelola', ['id' => 1])->row_array();

				$old_image = $user['logo_kop'];
				if ($old_image != 'kop.png') {
					unlink(FCPATH . 'assets/' . $old_image);
				}
				$new_image = $this->upload->data('file_name');
				$this->db->set('logo_kop', $new_image);
			} else {
				echo $this->upload->display_errors();
			}
		}

		$this->db->update('kelola', $data, ['id' => 1]);
		$this->session->set_flashdata('kop', '<div class="btn text-white bg-success-gradient float-right" id="alert">Data Berhasil diubah!</div>');
		redirect('admin/landingPage', 'refresh');
	}

	//public function visitor(){
	//	$ip    = $this->input->ip_address(); // Mendapatkan IP user
	//	$date  = date("Y-m-d"); // Mendapatkan tanggal sekarang
	//	$waktu = time(); //
	//	$timeinsert = date("Y-m-d H:i:s");

	//	// Cek berdasarkan IP, apakah user sudah pernah mengakses hari ini
	//	$s = $this->db->query("SELECT * FROM visitor WHERE ip='".$ip."' AND date='".$date."'")->num_rows();
	//	$ss = isset($s)?($s):0;


	//	// Kalau belum ada, simpan data user tersebut ke database
	//	if($ss == 0){
	//	$this->db->query("INSERT INTO visitor(ip, date, hits, online, time) VALUES('".$ip."','".$date."','1','".$waktu."','".$timeinsert."')");
	//	}

	//	// Jika sudah ada, update
	//	else{
	//	$this->db->query("UPDATE visitor SET hits=hits+1, online='".$waktu."' WHERE ip='".$ip."' AND date='".$date."'");
	//	}


	//	$pengunjunghariini  = $this->db->query("SELECT * FROM visitor WHERE date='".$date."' GROUP BY ip")->num_rows(); // Hitung jumlah pengunjung

	//	$dbpengunjung = $this->db->query("SELECT COUNT(hits) as hits FROM visitor")->row(); 

	//	$totalpengunjung = isset($dbpengunjung->hits)?($dbpengunjung->hits):0; // hitung total pengunjung

	//	$bataswaktu = time() - 300;

	//	$pengunjungonline  = $this->db->query("SELECT * FROM visitor WHERE online > '".$bataswaktu."'")->num_rows(); // hitung pengunjung online


	//	$data['pengunjunghariini']=$pengunjunghariini;
	//	$data['totalpengunjung']=$totalpengunjung;
	//	$data['pengunjungonline']=$pengunjungonline;
	//}

}
