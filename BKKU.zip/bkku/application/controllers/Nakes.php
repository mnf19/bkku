<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Nakes extends CI_Controller {

	public function __construct(){
        parent:: __construct();
        
		if(!$this->session->userdata('user')){
			
			redirect('auth','refresh');
			
		}

		if($this->session->userdata('level') != 3){
			
			redirect('auth','refresh');
			
		}

        $this->load->library('form_validation');
        $this->load->library('dompdf_gen');

    }

	//Sidebar menu function
	private function _sidebar($data){
		$data['menu'] = $this->db->get_where('menu',['akses'=>3])->result_array();
		$this->load->view('nakes/sidebar' , $data);
	}

	//Header function
	private function _header(){
		$data['title'] = $this->db->select('judul_web')
								->get_where('kelola',['id'=>1])
								->row_array();
		$this->load->view('template/header', $data);
	}

	//Index function
	public function index(){
		
		$data['title'] = 'Dashboard';
		$data['pasien'] = $this->db->group_by('noRm')->get('pasien')->num_rows();
		$data['antrian'] = $this->db->get_where('pasien', ['sts'=>0])->result_array();
		$data['ant'] = $this->db->get_where('pasien', ['sts'=>0])->row_array();

		$this->_header();
		$this->_sidebar($data);
		$this->load->view('nakes/index', $data);
		$this->load->view('template/footer');
		
	}

	public function addPsn(){
		$nama = $this->input->post('namaPsn');
		$nik = $this->input->post('nikPsn');
		$umur = $this->input->post('umurPsn');
		$jenkel = $this->input->post('jenkelPsn');
		$alamat = $this->input->post('alamatPsn');
		$noAnt = $this->input->post('noAnt');
		$noRm = $this->input->post('noRm');
		$tglPrk = $this->input->post('tglPrk');
		$jamPrk = $this->input->post('jamPrk');
		$user = $this->input->post('user');
		$this->_antrian($this->input->post('noAnt'));

		$data=[
			'nama' => $nama,
			'nik' => $nik,
			'umur' => $umur,
			'jenkel' => $jenkel,
			'alamat' => $alamat,
			'noAtr' 	=> $noAnt,
			'noRm' 		=> $noRm,
			'tglPrk' 	=> $tglPrk,
			'jamPrk' 	=> $jamPrk,
			'sts' 	=> "0",
			'user' 	=> $user,
		];
		$this->db->insert('pasien',$data);
		$pesan ="data sudah masuk bos!";
		echo json_encode($data);
	}


	//////// Tampil data pasien ///////
	private function _ambil(){
			$this->db->from("pasien");

            if(isset($_POST['search']['value'])){
                $this->db->like('noAtr',$_POST['search']['value']);
                $this->db->or_like('nik',$_POST['search']['value']);
                $this->db->or_like('nama',$_POST['search']['value']);
                $this->db->or_like('noRm',$_POST['search']['value']);
                $this->db->or_like('alamat',$_POST['search']['value']);
            }

            $this->db->order_by('id', 'DESC');
	}

	private function _getPasien(){
        $this->_ambil();
        if($_POST['length']!=1){
            $this->db->limit($_POST['length'], $_POST['start']);
        }
        return $this->db->get()->result(); 
    }

	private function totalDataFilter(){
        $this->_ambil();
        return $this->db->get()->num_rows(); 
    }

    private function totalData(){
        return $this->db->from('pasien')->count_all_results();
    }

	public function viewData(){
		//$this->load->helper('url');
		$result = $this->_getPasien();
		
		$data = [];
		//$no = $_POST['start'];
		foreach ( $result as $hasil ){
			if($hasil->sts == 1){
				$sts = '<div class="badge badge-success">Sudah</div>';
			} else {
				$sts = '<div class="badge badge-danger">Belum</div>';
			}
			$row = [
				$hasil->noAtr,
				$hasil->noRm,
				$hasil->nik,
				$hasil->nama,
				$hasil->alamat,
				$sts,
				'<td class="dropdown" width="50">
					<a class="dropdown-toggle badge-primary badge py-auto" href="#" id="navbarDropdown" role="button" data-toggle="dropdown">Aksi</a>
					<div class="dropdown-menu">
						<li class="dropdown-item" href="#">
							<a href="javascript:void(0);" class="badge badge-primary tmbPsn" onclick="psnEdit('.$hasil->id.')">Edit</a>
						</li>
						<li class="dropdown-item" href="#">
							<a href="javascript:void(0);" class="badge badge-danger tmbPsn" onclick="psnHapus('.$hasil->id.')">Hapus</a>
						</li>
						<li class="dropdown-item" href="#">
							<a href="javascript:void(0);" class="badge badge-success tmbPsn" onclick="psnDetail('.$hasil->id.')">Detail</a>
						</li>
						<li class="dropdown-item" href="#">
							<a href="javascript:void(0);" class="badge badge-secondary tmbPsn" onclick="psnDu('.$hasil->id.')">Daftar ulang</a>
						</li>
					</div>
				</td>',
			]; 
			$data[] = $row;
		}

		$output = [
			"draw" => $_POST['draw'],
			"recordsTotal" => $this->totalData(),
			"recordsFiltered" => $this->totalDataFilter(),
			"data" => $data, 
		];
		
		echo json_encode($output);
	}
	//////// Akhir baris /////

	public function noAnt()
	{
		$a = $this->db->select_max('noAtr')->get('pasien')->row_array();
		$b = $a['noAtr']+1;
		$c = $this->db->select_max('noRm')->get('pasien')->row_array();
		$d = $c['noRm']+1;
			$row = [
				'noAtr' => $b,
				'noRm'  => $d,
			]; 
		echo json_encode($row);
	}

	public function getPSn()
	{	
		$id = $this->input->post('id');
		$data = $this->db->get_where('pasien', ['id'=>$id])->row_array();
		echo json_encode($data);
	}

	public function edtPasien()
	{
		$id = $this->input->post('id');
		$nama = $this->input->post('namaPsn');
		$nik = $this->input->post('nikPsn');
		$umur = $this->input->post('umurPsn');
		$jenkel = $this->input->post('jenkelPsn');
		$alamat = $this->input->post('alamatPsn');
		//$noAnt = $this->input->post('noAnt');
		//$noRm = $this->input->post('noRm');
		//$tglPrk = $this->input->post('tglPrk');
		//$jamPrk = $this->input->post('jamPrk');
		//$user = $this->input->post('user');
		$data=[
			'nama' => $nama,
			'nik' => $nik,
			'umur' => $umur,
			'jenkel' => $jenkel,
			'alamat' => $alamat,
			//'noAtr' 	=> $noAnt,
			//'noRm' 		=> $noRm,
			//'tglPrk' 	=> $tglPrk,
			//'jamPrk' 	=> $jamPrk,
			//'sts' 	=> "0",
			//'user' 	=> $user,
		];
		$this->db->where('id', $id);
		$this->db->update('pasien', $data);
		$pesan='Data sudah diubah bos!';
		echo json_encode($pesan);

	}

	public function hpsPasien ()
	{
		$id = $this->input->post('id');
		$this->db->delete('pasien', ['id'=>$id]);
		$pesan='Data sudah dihapus bos!';
		echo json_encode($pesan);
	}

	public function detPasien ()
	{
		$id = $this->input->post('id');
		$data = $this->db->get_where('pasien', ['id'=>$id])->row_array();
		echo json_encode($data);
	}

	//Profil
	public function profil(){
		
		$data['title'] = 'Profil';
		$this->_header();
		$this->_sidebar($data);
		$this->load->view('nakes/profil');
		$this->load->view('template/footer');
		
	}

	public function udtProfil(){

		$id = $this->input->post('id');
		//echo $id;
		//die;
		
		$data = [
			'nama' 	      => $this->input->post('nama'),
			'username'    => $this->input->post('username'),
			"nip" 		  => $this->input->post('nip'), 
			"alamat" 	  => $this->input->post('alamat'), 
			"jenkel" 	  => $this->input->post('jenkel'),
			"tgl_lahir"   => $this->input->post('tgl_lahir'), 
			"tempat_lahir"=> $this->input->post('tempat_lahir'), 
			"agama"       => $this->input->post('agama'), 
		];

		$upload_image = $_FILES['foto']['name'];
		
            if ($upload_image) {

                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size']      = '2048';
                $config['upload_path'] = './assets/';

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('foto')) {
				$user = $this->db->get_where('user', ['id'=>$id])->row_array();

                    $old_image = $user['foto'];
                    if ($old_image != 'default.jpg') {
                        unlink(FCPATH . 'assets/' . $old_image);
                    }
                    $new_image = $this->upload->data('file_name');
                    $this->db->set('foto', $new_image);
                } else {
                    echo $this->upload->display_errors();
                }
            }
		$this->db->where('id', $id)->update('user',$data);
		$this->session->set_flashdata('profil', '<div class="btn text-white bg-success-gradient ml-auto mt-5 mr-4" style="transform:translateY(-70px);" id="alert">Profil berhasil diupdate!</div>');
		redirect('nakes/profil','refresh');
		
	}

	public function cetakPsn()
	{
		$data['kelola'] = $this->db->get('kelola')->row_array();
		$data['pasien'] = $this->db->group_by('noRm')->get('pasien')->result_array();
		
        $this->load->view('nakes/cetakPsn', $data);
        

        $html = $this->output->get_output();
        $this->dompdf->set_paper('A4', 'potrait');

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream('Data_pasien.pdf', array('Attachment' => 0));
	}

	public function krtPsn()
	{	
		$nama = $this->input->post('nama');
		$nik = $this->input->post('nik');
		$umur = $this->input->post('umur');
		$jenkel = $this->input->post('jenkel');
		$alamat = $this->input->post('alamat');
		$noAtr = $this->input->post('noAtr');
		$noRm = $this->input->post('noRm');
		$data=[
			'noAtr'  => $noAtr,
			'nama'   => $nama,
			'umur'   => $umur,
			'jenkel' => $jenkel,
			'alamat' => $alamat,
			'nik'    => $nik,
		];
		$data['pasien']=$data;
        $this->load->view('nakes/krtPsn', $data);
        
        $html = $this->output->get_output();
        $this->dompdf->set_paper('A4', 'potrait');

        $this->dompdf->load_html($html);
        $this->dompdf->render();
        $this->dompdf->stream('Data_pasien.pdf', array('Attachment' => 0));
	}

	public function udtAnt()
	{
		$data=[
			'no_antrian' => 1
		];

		$this->db->update('antrian', $data, ['id'=>1]);
		$pesan = 'udah diupdate nih bos!';
		echo json_encode($pesan);
		
	}

	private function _antrian($antrian){

		$data = [
				'no_antrian' => $antrian + 1,
			];

		$this->db->update('antrian', $data, ['id'=>1]);
	}

	public function getAnt()		
	{
		//Ambil nomer antrian secara otomatis
		$a = $this->db->select_max('no_antrian')->get('antrian')->row_array();
		$c = $this->db->get_where('antrian',['id'=>1])->row_array();
		
		$data = [
			'antrian' => $a['no_antrian'],
			'kuota' => $c['kuota'],
		];

		echo json_encode($data);
	}

	public function jam()
	{
		$a = $this->db->get('jam_buka')->row_array();
		$data['jam'] = $a;
		echo json_encode($data);
	}
}

